# Red Rev 0 Pokédex

A self-contained Pokédex for the 151 Pokémon in **Pokémon Red (USA/Europe), Rev 0**, built only from the ROM.

Open `Pokedex.html` in any browser. It works offline except for the UI web fonts, which fall back to system fonts.

## Rebuild

```bash
python3 tools/extract.py "path/to/Pokemon - Red Version (USA, Europe) (SGB Enhanced).gb"
python3 tools/build.py
```

- `tools/extract.py` reads the ROM and writes `data/pokedex.json`. It needs only the Python standard library, with no PIL, because sprites are decompressed and packed by hand. It checks the ROM's SHA-1 against Red Rev 0 (`ea9bcae6…`).
- `tools/build.py` inlines that JSON into `app/template.html` and writes `Pokedex.html`.

## What comes from where

| Data | Source in ROM |
|---|---|
| Names, internal IDs, Pokédex order | `MonsterNames`, `PokedexOrder` |
| Stats, types, catch rate, exp., growth, TM/HM bits, sprite pointers | `BaseStats` (Mew separately in bank 1) |
| Evolutions and level-up moves | `EvosMovesPointerTable` |
| Species, height, weight, Pokédex text | `PokedexEntryPointers` → far text |
| Moves, move names, TM/HM list, high-crit list | `Moves`, `MoveNames`, `TechnicalMachines`, `HighCriticalMoves` |
| Type names and type chart | `TypeNames`, `TypeEffects` |
| Effect chances (e.g. 26/256 burn) | Compare instructions in the battle engine |
| Front and back sprites | Decompressed with the game's pic algorithm; the bank is chosen by re-running `UncompressMonSprite`'s own compare ladder |
| Sprite colours | `MonsterPalettes` → `SuperPalettes` (Super Game Boy) |
| In-game text font | `FontGraphics` (1bpp) |
| Wild grass, cave and surf encounters | `WildDataPointers` + `WildMonEncounterSlotChances` |
| Fishing | `SuperRodData`; Old/Good Rod Pokémon and bite odds from the rod code |
| Trainer parties and locations | `TrainerDataPointers` + each map's object list; rival battles traced from scripts |
| Gifts, trades, one-off battles, fossils, starters, prizes | Calls to `GivePokemon` / trade predef / opponent writes, traced to the owning map; `TradeMons`, prize tables |
| Area names | Town-map entries |

The one thing not read from the ROM is the floor and building labels (`1F`, `B2F`, `Gym`, …). The ROM names areas only by town-map region, so these labels are added on top of the ROM's area names in `MAP_LABELS` in `extract.py`.
