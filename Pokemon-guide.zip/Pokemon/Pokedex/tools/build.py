#!/usr/bin/env python3
"""Inline data/pokedex.json into app/template.html -> Pokedex.html (one self-contained file)."""
import os
here = os.path.dirname(os.path.abspath(__file__))
root = os.path.join(here, "..")
tpl = open(os.path.join(root, "app", "template.html"), encoding="utf-8").read()
data = open(os.path.join(root, "data", "pokedex.json"), encoding="utf-8").read().replace("</", "<\\/")
html = '<!doctype html>\n<html lang="en">\n' + tpl.replace("/*DATA*/", data, 1) + "\n</html>\n"
out = os.path.join(root, "Pokedex.html")
open(out, "w", encoding="utf-8").write(html)
print("wrote Pokedex.html (%.0f KB)" % (os.path.getsize(out) / 1024))
