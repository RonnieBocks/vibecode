#!/usr/bin/env python3
"""
Extracts every piece of Pokédex data for the 151 Pokémon directly from a
Pokémon Red (USA/Europe, Rev 0) ROM. No external data sources are used —
all numbers, names, text, sprites and palettes are read out of the ROM.

Usage: python3 tools/extract.py path/to/pokered.gb  ->  writes data/pokedex.json
"""
import sys, os, json, struct, zlib, base64, hashlib

ROM_SHA1 = "ea9bcae617fdf159b045185467ae58b2e4a48b9a"  # Pokemon Red (UE) Rev 0

# ---------------------------------------------------------------- ROM access
class Rom:
    def __init__(self, path):
        self.b = open(path, "rb").read()

    def u8(self, o): return self.b[o]
    def u16(self, o): return self.b[o] | (self.b[o + 1] << 8)
    def s8(self, o): v = self.b[o]; return v - 256 if v > 127 else v

    @staticmethod
    def off(bank, addr):
        """GB bank:address -> file offset."""
        if addr < 0x4000: return addr
        return bank * 0x4000 + (addr - 0x4000)

    def ptr(self, bank, o):
        """Read a 2-byte pointer at file offset o, resolve it in `bank`."""
        return self.off(bank, self.u16(o))

    @staticmethod
    def bank_of(o): return o // 0x4000


# ---------------------------------------------------------------- text codec
CHARS = {0x7F: " ", 0x9A: "(", 0x9B: ")", 0x9C: ":", 0x9D: ";", 0x9E: "[", 0x9F: "]",
         0xBA: "é", 0xBB: "'d", 0xBC: "'l", 0xBD: "'s", 0xBE: "'t", 0xBF: "'v",
         0xE0: "'", 0xE1: "PK", 0xE2: "MN", 0xE3: "-", 0xE4: "'r", 0xE5: "'m",
         0xE6: "?", 0xE7: "!", 0xE8: ".", 0xEF: "♂", 0xF0: "¥", 0xF1: "×",
         0xF2: ".", 0xF3: "/", 0xF4: ",", 0xF5: "♀", 0x54: "POKé", 0x4A: "PKMN",
         0x56: "……", 0x5B: "PC", 0x5C: "TM", 0x5D: "TRAINER", 0x5E: "ROCKET",
         0x70: "‘", 0x71: "’", 0x72: "“", 0x73: "”", 0x75: "…"}
for i in range(26):
    CHARS[0x80 + i] = chr(65 + i)
    CHARS[0xA0 + i] = chr(97 + i)
for i in range(10):
    CHARS[0xF6 + i] = str(i)

def decode(rom, o, maxlen=None, stops=(0x50,)):
    """Decode game text starting at o. Returns (string, end offset)."""
    out = []
    n = 0
    while True:
        c = rom.b[o]
        if c in stops or (maxlen is not None and n >= maxlen): break
        if c in (0x4E, 0x4F, 0x55): out.append("\n")      # next line / line / cont
        elif c in (0x49, 0x51): out.append("\n\n")        # page / paragraph
        elif c == 0x00: pass                              # text-command start
        else: out.append(CHARS.get(c, "?"))
        o += 1; n += 1
    return "".join(out), o

def fixed_name(rom, o, length):
    s, _ = decode(rom, o, maxlen=length)
    return s


# ---------------------------------------------------------------- ROM layout
# Offsets of tables in the Rev 0 Red ROM. Each was located by signature search
# against the ROM itself (see README) and is sanity-checked below.
MON_NAMES        = 0x1C21E   # 190 x 10 bytes, indexed by internal ID
POKEDEX_ORDER    = 0x41024   # 190 bytes: internal ID -> Pokédex number
BASE_STATS       = 0x383DE   # 150 x 28 bytes, Pokédex order (Bulbasaur..Mewtwo)
MEW_BASE_STATS   = 0x425B    # Mew's 28 bytes live separately in bank 1
EVOS_MOVES_PTRS  = 0x3B05C   # 190 pointers (bank $0E), internal order
DEX_ENTRY_PTRS   = 0x4047E   # 190 pointers (bank $10), internal order
MOVES            = 0x38000   # 165 x 6 bytes
MOVE_NAMES       = 0xB0000   # 165 terminated strings
ITEM_NAMES       = 0x472B    # terminated strings, item IDs start at 1
TYPE_NAME_PTRS   = 0x27DAE   # 27 pointers (bank $09)
TYPE_EFFECTS     = 0x3E474   # (atk, def, x10) triples, $FF terminated
TM_MOVES         = 0x13773   # 50 TMs + 5 HMs
GROWTH_RATES     = 0x5901D   # 6 x 4-byte growth formulae
WILD_SLOT_CHANCE = 0x13918   # 10 x (cumulative/256, slot*2)
MAP_HEADER_PTRS  = 0x01AE    # pointers into each map's bank
MAP_HEADER_BANKS = 0xC23D    # bank per map ID
WILD_PTRS_BANK   = 0x03
SUPER_ROD_DATA   = 0xE97D    # first fishing group (table found by pointer scan)
TRAINER_NAMES    = 0x399FF   # trainer class names
MON_PALETTES     = 0x725C8   # Pokédex number -> SGB palette ID
SGB_PALETTES     = 0x72660   # 4 x RGB555 per SGB palette ID

FONT_GFX         = 0x11A80   # 128 x 8 bytes, 1bpp, chars $80-$FF

NUM_MOVES = 165

def check_rom(rom):
    h = hashlib.sha1(rom.b).hexdigest()
    title = rom.b[0x134:0x13F].decode("ascii", "replace")
    version = rom.b[0x14C]
    return {"sha1": h, "title": title, "mask_rom_version": version,
            "is_rev0_red": h == ROM_SHA1}


# ---------------------------------------------------------------- basic tables
def read_strings(rom, o, count):
    out = []
    for _ in range(count):
        s, o = decode(rom, o)
        out.append(s); o += 1
    return out

def type_names(rom):
    bank = Rom.bank_of(TYPE_NAME_PTRS)
    names = {}
    for t in range(27):
        o = rom.ptr(bank, TYPE_NAME_PTRS + 2 * t)
        names[t] = decode(rom, o)[0]
    return names

def type_chart(rom):
    o = TYPE_EFFECTS; out = []
    while rom.u8(o) != 0xFF:
        out.append((rom.u8(o), rom.u8(o + 1), rom.u8(o + 2) / 10)); o += 3
    return out

def moves(rom):
    names = read_strings(rom, MOVE_NAMES, NUM_MOVES)
    out = {}
    for i in range(NUM_MOVES):
        o = MOVES + 6 * i
        mid, eff, pw, typ, acc, pp = rom.b[o:o + 6]
        assert mid == i + 1
        out[mid] = {"id": mid, "name": names[i], "effect": eff, "power": pw,
                    "type": typ, "accuracy_raw": acc,
                    "accuracy": round(acc * 100 / 255), "pp": pp}
    return out

def item_names(rom):
    return {i + 1: n for i, n in enumerate(read_strings(rom, ITEM_NAMES, 83))}

def growth_rates(rom):
    rates = []
    for g in range(6):
        o = GROWTH_RATES + 4 * g
        ab, c, d, e = rom.b[o:o + 4]
        a, b = ab >> 4, ab & 0xF
        if c & 0x80: c = -(c & 0x7F)
        rates.append((a, b, c, d, e))
    return rates

def exp_for_level(rate, n):
    a, b, c, d, e = rate
    # Same order of operations as CalcExperience: (a*n^3)/b + c*n^2 + d*n - e
    return (a * n ** 3) // b + c * n * n + d * n - e


# ---------------------------------------------------------------- species
def species_tables(rom):
    names = {i + 1: fixed_name(rom, MON_NAMES + 10 * i, 10) for i in range(190)}
    dexno = {i + 1: rom.u8(POKEDEX_ORDER + i) for i in range(190)}
    internal_of = {d: i for i, d in dexno.items() if d}
    return names, dexno, internal_of

def base_stats(rom, dex):
    o = MEW_BASE_STATS if dex == 151 else BASE_STATS + 28 * (dex - 1)
    b = rom.b[o:o + 28]
    assert b[0] == dex
    tmbits = int.from_bytes(b[20:27], "little")
    return {
        "hp": b[1], "attack": b[2], "defense": b[3], "speed": b[4], "special": b[5],
        "types": [b[6], b[7]], "catch_rate": b[8], "base_exp": b[9],
        "sprite_dim": b[10], "front_ptr": b[11] | b[12] << 8, "back_ptr": b[13] | b[14] << 8,
        "start_moves": [m for m in b[15:19] if m], "growth_rate": b[19],
        "tmhm_bits": [i + 1 for i in range(55) if tmbits >> i & 1],
        "offset": o,
    }

def evos_moves(rom, internal):
    bank = Rom.bank_of(EVOS_MOVES_PTRS)
    o = rom.ptr(bank, EVOS_MOVES_PTRS + 2 * (internal - 1))
    evos = []
    while rom.u8(o):
        kind = rom.u8(o)
        if kind == 1:   evos.append({"method": "level", "level": rom.u8(o + 1), "to": rom.u8(o + 2)}); o += 3
        elif kind == 2: evos.append({"method": "item", "item": rom.u8(o + 1), "level": rom.u8(o + 2), "to": rom.u8(o + 3)}); o += 4
        elif kind == 3: evos.append({"method": "trade", "level": rom.u8(o + 1), "to": rom.u8(o + 2)}); o += 3
        else: raise ValueError("bad evo type %d" % kind)
    o += 1
    learn = []
    while rom.u8(o):
        learn.append((rom.u8(o), rom.u8(o + 1))); o += 2
    return evos, learn

def dex_entry(rom, internal):
    bank = Rom.bank_of(DEX_ENTRY_PTRS)
    o = rom.ptr(bank, DEX_ENTRY_PTRS + 2 * (internal - 1))
    species, o = decode(rom, o); o += 1
    ft, inch = rom.u8(o), rom.u8(o + 1)
    weight = rom.u16(o + 2)
    o += 4
    assert rom.u8(o) == 0x17, "expected text_far"          # TX_FAR
    taddr, tbank = rom.u16(o + 1), rom.u8(o + 3)
    t = Rom.off(tbank, taddr)
    text, _ = decode(rom, t, stops=(0x50, 0x5F))
    return {"species": species, "height_ft": ft, "height_in": inch,
            "weight_lb": weight / 10, "text": text.strip()}


# ---------------------------------------------------------------- sprites
PIC_BANK_CODE = 0x1637   # UncompressMonSprite's "which bank is this pic in" ladder

def pic_bank(rom, internal):
    """Re-run the ROM's own bank-selection logic (read from the code bytes)."""
    b = rom.b; o = PIC_BANK_CODE
    # cp MEW / ld a,bank / jr z
    assert b[o] == 0xFE and b[o + 2] == 0x3E
    if internal == b[o + 1]: return b[o + 3]
    o += 7                                  # ld a,b ; cp FOSSIL_KABUTOPS ...
    if internal == b[o + 1]: return b[o + 3]
    o += 7
    while b[o] == 0xFE:                     # cp N / ld a,bank / jr c [/ ld a,b]
        if internal < b[o + 1]: return b[o + 3]
        o += 6
        if b[o] == 0x78: o += 1
    assert b[o] == 0x3E
    return b[o + 1]                         # fallthrough bank

class BitReader:
    def __init__(self, data, o):
        self.d = data; self.o = o; self.bit = 7
    def bit1(self):
        v = (self.d[self.o] >> self.bit) & 1
        self.bit -= 1
        if self.bit < 0: self.bit = 7; self.o += 1
        return v
    def bits(self, n):
        v = 0
        for _ in range(n): v = (v << 1) | self.bit1()
        return v

def decompress_pic(rom, o):
    """Gen 1 sprite decompression (same algorithm as the game's UncompressSpriteData).
    Returns (width_tiles, height_tiles, pixels[y][x] with 2-bit colour indices)."""
    br = BitReader(rom.b, o)
    wt = br.bits(4); ht = br.bits(4)
    W, H = wt * 8, ht * 8
    npairs = W * H // 2

    def fill():
        pairs = []
        mode = br.bit1()                     # 0 = start with RLE, 1 = start with data
        while len(pairs) < npairs:
            if mode == 0:
                i = 0
                while br.bit1(): i += 1
                n = ((2 << i) - 1) + br.bits(i + 1)
                pairs.extend([0] * n)
            else:
                while len(pairs) < npairs:
                    p = br.bits(2)
                    if p == 0: break
                    pairs.append(p)
            mode ^= 1
        assert len(pairs) == npairs, "pic overrun"
        # bit-pairs fill the plane in columns 2px wide, top to bottom
        plane = [[0] * W for _ in range(H)]
        k = 0
        for col in range(W // 2):
            for y in range(H):
                p = pairs[k]; k += 1
                plane[y][col * 2] = p >> 1
                plane[y][col * 2 + 1] = p & 1
        return plane

    def delta(plane):
        for row in plane:
            state = 0
            for x in range(W):
                if row[x]: state ^= 1
                row[x] = state

    def xor(dst, src):
        for y in range(H):
            for x in range(W): dst[y][x] ^= src[y][x]

    order = br.bit1()
    planes = [None, None]
    r1, r2 = order, order ^ 1
    planes[r1] = fill()
    mode = br.bit1()
    if mode: mode += br.bit1()
    planes[r2] = fill()
    if mode == 0:
        delta(planes[0]); delta(planes[1])
    elif mode == 1:
        delta(planes[r1]); xor(planes[r2], planes[r1])
    else:
        delta(planes[r2]); delta(planes[r1]); xor(planes[r2], planes[r1])
    # buffer 1 holds the low bit plane, buffer 2 the high bit plane
    px = [[planes[0][y][x] | (planes[1][y][x] << 1) for x in range(W)] for y in range(H)]
    return wt, ht, px

def place_front(wt, ht, px):
    """Front pics sit bottom-aligned and centred in a 7x7-tile box, as in battle."""
    out = [[0] * 56 for _ in range(56)]
    oy = (7 - ht) * 8
    ox = ((8 - wt) // 2) * 8
    for y in range(ht * 8):
        for x in range(wt * 8):
            out[oy + y][ox + x] = px[y][x]
    return out


# ---------------------------------------------------------------- PNG output
def png(pixels, palette, scale=1, transparent0=False):
    """Minimal indexed-colour PNG writer (no PIL needed)."""
    h = len(pixels); w = len(pixels[0])
    raw = bytearray()
    for row in pixels:
        for _ in range(scale):
            raw.append(0)
            for v in row: raw.extend([v] * scale)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    ihdr = struct.pack(">IIBBBBB", w * scale, h * scale, 8, 3, 0, 0, 0)
    plte = b"".join(bytes(c) for c in palette)
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"PLTE", plte)
    if transparent0: data += chunk(b"tRNS", b"\x00" + b"\xff" * (len(palette) - 1))
    return data + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")

def sgb_palette(rom, pal_id):
    o = SGB_PALETTES + 8 * pal_id
    cols = []
    for i in range(4):
        v = rom.u16(o + 2 * i)
        r, g, b = v & 31, (v >> 5) & 31, (v >> 10) & 31
        cols.append(tuple(c * 255 // 31 for c in (r, g, b)))
    return cols
CHARS[0x52] = "<PLAYER>"; CHARS[0x53] = "<RIVAL>"


# ---------------------------------------------------------------- maps
TOWN_MAP_EXTERNAL = 0x71313   # 3 bytes/map for maps $00-$24: coords, name ptr
TOWN_MAP_INTERNAL = 0x71382   # 4 bytes: first map ID *above* range, coords, name ptr
NUM_MAPS = 248

# The ROM only names *areas* (via the town map). These sub-labels tell floors
# and buildings apart within an area; they follow the map ID order in the ROM.
MAP_LABELS = {
    0x25: "Red's House 1F", 0x26: "Red's House 2F", 0x27: "Blue's House", 0x28: "Oak's Lab",
    0x29: "Pokémon Center", 0x2A: "Poké Mart", 0x2B: "School", 0x2C: "House", 0x2D: "Gym",
    0x2E: "Diglett's Cave Entrance", 0x2F: "Viridian Forest North Gate", 0x30: "Trade House",
    0x31: "Gate", 0x32: "Viridian Forest South Gate", 0x33: None,
    0x34: "Museum 1F", 0x35: "Museum 2F", 0x36: "Gym", 0x37: "House", 0x38: "Poké Mart",
    0x39: "House", 0x3A: "Pokémon Center", 0x3B: "1F", 0x3C: "B1F", 0x3D: "B2F",
    0x3E: "Trashed House", 0x3F: "Trade House", 0x40: "Pokémon Center", 0x41: "Gym",
    0x42: "Bike Shop", 0x43: "Poké Mart", 0x44: "Pokémon Center", 0x46: "Gate",
    0x47: "Underground Path Entrance", 0x48: "Day Care", 0x49: "Gate",
    0x4A: "Underground Path Entrance", 0x4C: "Gate", 0x4D: "Underground Path Entrance",
    0x4F: "Gate", 0x50: "Underground Path Entrance", 0x51: "Pokémon Center",
    0x52: "1F", 0x53: None, 0x54: "Gate 1F", 0x55: "Diglett's Cave Entrance", 0x56: "Gate 2F",
    0x57: "Gate 1F", 0x58: "Bill's House", 0x59: "Pokémon Center", 0x5A: "Pokémon Fan Club",
    0x5B: "Poké Mart", 0x5C: "Gym", 0x5D: "House", 0x5E: "Dock", 0x5F: "1F", 0x60: "2F",
    0x61: "3F", 0x62: "B1F", 0x63: "Bow", 0x64: "Kitchen", 0x65: "Captain's Room",
    0x66: "1F Rooms", 0x67: "2F Rooms", 0x68: "B1F Rooms", 0x6C: "1F", 0x71: "Lance's Room",
    0x76: "Hall of Fame", 0x77: "North-South", 0x78: "Champion's Room", 0x79: "West-East",
    0x7A: "Dept. Store 1F", 0x7B: "Dept. Store 2F", 0x7C: "Dept. Store 3F", 0x7D: "Dept. Store 4F",
    0x7E: "Dept. Store Roof", 0x7F: "Dept. Store Elevator", 0x80: "Celadon Mansion 1F",
    0x81: "Celadon Mansion 2F", 0x82: "Celadon Mansion 3F", 0x83: "Celadon Mansion Roof",
    0x84: "Celadon Mansion Roof House", 0x85: "Pokémon Center", 0x86: "Gym", 0x87: "Game Corner",
    0x88: "Dept. Store 5F", 0x89: "Game Corner Prize Room", 0x8A: "Diner", 0x8B: "House",
    0x8C: "Hotel", 0x8D: "Pokémon Center", 0x8E: "1F", 0x8F: "2F", 0x90: "3F", 0x91: "4F",
    0x92: "5F", 0x93: "6F", 0x94: "7F", 0x95: "Mr. Fuji's House", 0x96: "Poké Mart",
    0x97: "House", 0x98: "Poké Mart", 0x99: "House", 0x9A: "Pokémon Center",
    0x9B: "Warden's House", 0x9C: "Gate", 0x9D: "Gym", 0x9E: "Meeting Room", 0x9F: "B1F",
    0xA0: "B2F", 0xA1: "B3F", 0xA2: "B4F", 0xA3: "Fishing Guru's House", 0xA4: "Fishing Guru's House",
    0xA5: "1F", 0xA6: "Gym", 0xA7: "Pokémon Lab", 0xA8: "Pokémon Lab Trade Room",
    0xA9: "Pokémon Lab Metronome Room", 0xAA: "Pokémon Lab Fossil Room", 0xAB: "Pokémon Center",
    0xAC: "Poké Mart", 0xAE: "Lobby", 0xAF: "Copycat's House 1F", 0xB0: "Copycat's House 2F",
    0xB1: "Fighting Dojo", 0xB2: "Gym", 0xB3: "House", 0xB4: "Poké Mart", 0xB5: "1F",
    0xB6: "Pokémon Center", 0xB7: "Mr. Psychic's House", 0xB8: "Gate 1F", 0xB9: "Gate 2F",
    0xBA: "Gate 1F", 0xBB: "Gate 2F", 0xBC: "House", 0xBD: "Fishing Guru's House",
    0xBE: "Gate 1F", 0xBF: "Gate 2F", 0xC0: "1F", 0xC1: "Gate", 0xC2: "2F", 0xC3: "Gate 2F",
    0xC4: "Trade House", 0xC5: None, 0xC6: "3F", 0xC7: "B1F", 0xC8: "B2F", 0xC9: "B3F",
    0xCA: "B4F", 0xCB: "Elevator", 0xCF: "2F", 0xD0: "3F", 0xD1: "4F", 0xD2: "5F", 0xD3: "6F",
    0xD4: "7F", 0xD5: "8F", 0xD6: "2F", 0xD7: "3F", 0xD8: "B1F", 0xD9: "East", 0xDA: "North",
    0xDB: "West", 0xDC: "Center", 0xDD: "Center Rest House", 0xDE: "Secret House",
    0xDF: "West Rest House", 0xE0: "East Rest House", 0xE1: "North Rest House", 0xE2: "2F",
    0xE3: "B1F", 0xE4: "1F", 0xE5: "Name Rater's House", 0xE6: "Badge House", 0xE8: "B1F",
    0xE9: "9F", 0xEA: "10F", 0xEB: "11F", 0xEC: "Elevator", 0xF5: "Lorelei's Room",
    0xF6: "Bruno's Room", 0xF7: "Agatha's Room", 0x45: "Trashed House (unused copy)",
    0x4B: "Underground Path Entrance (unused copy)", 0x4E: "Underground Path Entrance (unused copy)",
    0xEF: "Cable Club Trade Center", 0xF0: "Cable Club Colosseum",
}
# Map IDs that exist in the header tables but hold no real map (their header
# pointers alias other data): everything not listed above, plus $0B.
def is_real_map(m):
    return (m < 0x25 and m != 0x0B) or m in MAP_LABELS

def titlecase(s):
    out = []
    for w in s.split(" "):
        if w in ("S.S.ANNE",): out.append("S.S. Anne")
        elif w.startswith("MT."): out.append("Mt. " + w[3:].capitalize())
        elif w == "PKMN": out.append("Pokémon")
        elif w == "POKéMON": out.append("Pokémon")
        elif w == "CO.": out.append("Co.")
        elif w == "HQ": out.append("HQ")
        else: out.append(w[:1] + w[1:].lower())
    return " ".join(out).replace("Diglett's", "Diglett's")

def map_names(rom):
    area = {}
    for m in range(0x25):
        area[m] = decode(rom, rom.ptr(0x1C, TOWN_MAP_EXTERNAL + 3 * m + 1))[0]
    o = TOWN_MAP_INTERNAL; lo = 0x25
    while rom.u8(o) != 0xFF:
        hi = rom.u8(o); name = decode(rom, rom.ptr(0x1C, o + 2))[0]
        for m in range(lo, hi): area[m] = name
        lo = hi; o += 4
    out = {}
    for m in range(NUM_MAPS):
        if m not in area or not is_real_map(m): continue
        a = titlecase(area[m])
        lab = MAP_LABELS.get(m)
        if a in ("Underground Path",) and lab: a = a + " (" + lab + ")"; lab = None
        out[m] = {"area": a, "place": lab, "name": a + (" — " + lab if lab else "")}
    return out

def map_header(rom, m):
    bank = rom.u8(MAP_HEADER_BANKS + m)
    o = rom.ptr(bank, MAP_HEADER_PTRS + 2 * m)
    conn = rom.u8(o + 9)
    p = o + 10 + 11 * bin(conn & 0xF).count("1")
    return bank, o, rom.ptr(bank, p)

def map_objects(rom, m):
    """Returns list of NPC objects: dict(text, trainer_class|species, level|set, item)."""
    bank, hdr, o = map_header(rom, m)
    o += 1                                   # border block
    o += 1 + 4 * rom.u8(o)                   # warps
    o += 1 + 3 * rom.u8(o)                   # signs
    n = rom.u8(o); o += 1
    objs = []
    for _ in range(n):
        spr, y, x, m1, m2, t = rom.b[o:o + 6]; o += 6
        ob = {"sprite": spr, "x": x - 4, "y": y - 4, "text": t & 0x3F}
        if t & 0x40:
            ob["battle"] = (rom.u8(o), rom.u8(o + 1)); o += 2
        elif t & 0x80:
            ob["item"] = rom.u8(o); o += 1
        objs.append(ob)
    return objs

def map_anchors(rom, m):
    """ROM offsets of a map's own script and text routines (all in its header bank)."""
    bank, hdr, obj = map_header(rom, m)
    anchors = [rom.ptr(bank, hdr + 7)]                     # map script
    texts = rom.u16(hdr + 5)
    ids = set(ob["text"] for ob in map_objects(rom, m))
    o = obj + 1; o += 1 + 4 * rom.u8(o)                    # signs' text ids
    for k in range(rom.u8(o)): ids.add(rom.u8(o + 1 + 3 * k + 2))
    for t in range(1, max(ids | {0}) + 1):
        p = Rom.off(bank, texts) + 2 * (t - 1)
        anchors.append(rom.ptr(bank, p))
    return bank, anchors

def map_owning(anchor_index, off):
    """Which map's script/text code contains ROM offset `off`? Take the map
    owning the closest script/text entry point at or below it."""
    best, bo = None, -1
    for m, (bank, anchors) in anchor_index.items():
        if bank != Rom.bank_of(off): continue
        for a in anchors:
            if bo < a <= off: best, bo = m, a
    return best


# ---------------------------------------------------------------- encounters
WILD_PTRS = 0xCEEB
SUPER_ROD_TABLE = 0xE919
OLD_ROD_CODE = 0xE252     # lb bc, 5, MAGIKARP
GOOD_ROD_MONS = 0xE27F    # 2 x (level, species)

def slot_chances(rom):
    out = []; prev = 0
    for k in range(10):
        cum = rom.u8(WILD_SLOT_CHANCE + 2 * k)
        out.append(cum + 1 - prev); prev = cum + 1
    return out            # out of 256

def wild_tables(rom):
    res = {}
    for m in range(NUM_MAPS):
        if rom.u16(WILD_PTRS + 2 * m) == 0xFFFF: break
        o = rom.ptr(WILD_PTRS_BANK, WILD_PTRS + 2 * m)
        g = rom.u8(o); o += 1
        grass = [(rom.u8(o + 2 * k), rom.u8(o + 2 * k + 1)) for k in range(10)] if g else []
        if g: o += 20
        w = rom.u8(o); o += 1
        water = [(rom.u8(o + 2 * k), rom.u8(o + 2 * k + 1)) for k in range(10)] if w else []
        if g or w: res[m] = {"grass_rate": g, "grass": grass, "water_rate": w, "water": water}
    return res

def super_rod(rom):
    res = {}; o = SUPER_ROD_TABLE
    while rom.u8(o) != 0xFF:
        m = rom.u8(o); p = rom.ptr(WILD_PTRS_BANK, o + 1)
        n = rom.u8(p)
        res[m] = [(rom.u8(p + 1 + 2 * k), rom.u8(p + 2 + 2 * k)) for k in range(n)]
        o += 3
    return res

def old_good_rod(rom):
    assert rom.u8(OLD_ROD_CODE) == 0x01
    old = [(rom.u8(OLD_ROD_CODE + 2), rom.u8(OLD_ROD_CODE + 1))]
    good = [(rom.u8(GOOD_ROD_MONS + 2 * k), rom.u8(GOOD_ROD_MONS + 2 * k + 1)) for k in range(2)]
    return old, good


# ---------------------------------------------------------------- trainers
TRAINER_PTRS = 0x39D3B
NUM_TRAINER_CLASSES = 47

def trainers(rom):
    names = read_strings(rom, TRAINER_NAMES, NUM_TRAINER_CLASSES)
    bank = Rom.bank_of(TRAINER_PTRS)
    ptrs = [rom.ptr(bank, TRAINER_PTRS + 2 * k) for k in range(NUM_TRAINER_CLASSES)]
    allp = sorted(set(ptrs))
    classes = {}
    for k, start in enumerate(ptrs):
        if k + 1 < len(ptrs) and ptrs[k + 1] == start:
            # empty label directly in front of the next class's data (unused
            # classes such as the first JUGGLER and CHIEF): it owns no parties
            classes[k + 1] = {"name": names[k], "parties": []}
            continue
        later = [p for p in allp if p > start]
        end = later[0] if later else None
        o = start; parties = []
        while (end is None and not parties) or (end is not None and o < end):
            first = rom.u8(o); o += 1
            mons = []
            if first == 0xFF:
                while rom.u8(o): mons.append((rom.u8(o), rom.u8(o + 1))); o += 2
            else:
                while rom.u8(o): mons.append((first, rom.u8(o))); o += 1
            o += 1
            parties.append(mons)
        classes[k + 1] = {"name": names[k], "parties": parties}
    return classes


# ---------------------------------------------------------------- script scans
GIVE_POKEMON = 0x3E48
W_CUR_OPPONENT = 0xD059
W_CUR_ENEMY_LVL = 0xD127
W_WHICH_TRADE = 0xCD3D
PREDEF_TRADE = 0x54
TRADE_MONS = 0x71B7B
NUM_TRADES = 10
FOSSIL_CODE = 0x61071
PRIZE_MONS = 0x52859
PRIZE_LEVELS = 0x5298A
HIGH_CRIT_MOVES = None

def find_all(rom, pat):
    import re
    return [m.start() for m in re.finditer(re.escape(bytes(pat)), rom.b)]

def gift_calls(rom):
    """Every `call GivePokemon` and what species/level it hands out."""
    import re
    out = []
    for s in find_all(rom, [0xCD, GIVE_POKEMON & 0xFF, GIVE_POKEMON >> 8]):
        pre = rom.b[s - 3:s]
        if pre[0] == 0x01:                                   # lb bc, species, level
            out.append({"at": s, "species": pre[2], "level": pre[1]})
        elif pre[1] == 0x0E:                                 # ld b,a / ld c,level
            out.append({"at": s, "species": None, "level": pre[2]})
        else:
            out.append({"at": s, "species": None, "level": None})
    return out

def scripted_battles(rom):
    import re
    out = []
    for m in re.finditer(rb"\x3e(.)\xea" + bytes([W_CUR_OPPONENT & 0xFF, W_CUR_OPPONENT >> 8]), rom.b, re.S):
        s = m.start(); v = rom.u8(s + 1)
        lv = re.search(rb"\x3e(.)\xea" + bytes([W_CUR_ENEMY_LVL & 0xFF, W_CUR_ENEMY_LVL >> 8]), rom.b[s:s + 24], re.S)
        out.append({"at": s, "value": v, "level": lv.group(1)[0] if lv else None})
    return out

def trade_calls(rom):
    """`ld a, TRADE_n / ld [wWhichTrade], a / ... predef DoInGameTradeDialogue`."""
    import re
    out = []
    tgt = bytes([0xEA, W_WHICH_TRADE & 0xFF, W_WHICH_TRADE >> 8])
    for m in re.finditer(re.escape(bytes([0x3E, PREDEF_TRADE, 0xCD])), rom.b):
        s = m.start()
        # look back for the trade index being set (either `ld a,n` or `xor a`)
        # every store to wWhichTrade just before the predef (two traders can
        # share one call through a branch)
        k = s
        while True:
            k = rom.b.rfind(tgt, s - 16, k)
            if k < 0: break
            if rom.b[k - 2] == 0x3E: out.append((rom.b[k - 1], s))
            elif rom.b[k - 1] == 0xAF: out.append((0, s))
    return out

def trade_mons(rom):
    out = []
    for k in range(NUM_TRADES):
        o = TRADE_MONS + 14 * k
        out.append({"give": rom.u8(o), "get": rom.u8(o + 1), "dialog": rom.u8(o + 2),
                    "nickname": fixed_name(rom, o + 3, 11)})
    return out

def fossils(rom):
    """cp DOME_FOSSIL / jr z,.dome / cp HELIX_FOSSIL / jr z,.helix /
       ld b,AMBER_MON / jr / .helix: ld b,HELIX_MON / jr / .dome: ld b,DOME_MON
       then ld [wFossilItem],a / ld a,b / ld [wFossilMon],a"""
    b = rom.b
    o = b.rfind(b"\x28\x0c", FOSSIL_CODE - 40, FOSSIL_CODE) - 2
    assert b[o] == 0xFE and b[o + 4] == 0xFE and b[o + 8] == 0x06 and b[o + 16] == 0x06
    dome, helix = b[o + 1], b[o + 5]
    amber_mon, helix_mon, dome_mon = b[o + 9], b[o + 13], b[o + 17]
    return [(dome, dome_mon), (helix, helix_mon), (None, amber_mon)]

def prize_mons(rom):
    o = PRIZE_MONS; lists = []
    for _ in range(2):
        mons = []
        while rom.u8(o) != 0x50: mons.append(rom.u8(o)); o += 1
        o += 1
        costs = []
        for _ in mons:
            v = rom.b[o:o + 2].hex(); costs.append(int(v)); o += 2
        o += 1
        lists.append(list(zip(mons, costs)))
    levels = {}
    o = PRIZE_LEVELS
    while True:
        sp, lv = rom.u8(o), rom.u8(o + 1)
        if sp > 190: break
        levels[sp] = lv; o += 2
    return [(sp, cost, levels.get(sp)) for l in lists for sp, cost in l]

def high_crit_moves(rom):
    # KARATE CHOP, RAZOR LEAF, CRABHAMMER, SLASH ... $FF  (found by scanning for list shape)
    for s in find_all(rom, [0x02, 0x4B, 0x98, 0xA3, 0xFF]):
        return s, [0x02, 0x4B, 0x98, 0xA3]
    return None, []


# ---------------------------------------------------------------- move effects
# Battle-engine thresholds (random byte must be below N), read from the engine:
CHANCE_AT = {"poison1": 0x3F278, "poison2": 0x3F27E, "status1": 0x3F335, "status2": 0x3F339,
             "flinch1": 0x3F874, "flinch2": 0x3F878, "statdown": 0x3F581, "confuse": 0x3F95D}

def effect_texts(rom):
    c = {k: rom.u8(o) for k, o in CHANCE_AT.items()}
    pct = lambda n: "%d/256 (%.1f%%)" % (n, n * 100 / 256)
    return {
        0x00: "Deals damage.",
        0x02: "May poison the target: " + pct(c["poison1"]) + ".",
        0x03: "Restores HP to the user equal to half the damage dealt.",
        0x04: "May burn the target: " + pct(c["status1"]) + ".",
        0x05: "May freeze the target: " + pct(c["status1"]) + ".",
        0x06: "May paralyze the target: " + pct(c["status1"]) + ".",
        0x07: "The user faints. Halves the target's Defense for the damage calculation.",
        0x08: "Only works on a sleeping target; restores HP equal to half the damage dealt.",
        0x09: "Uses the move the opponent used last.",
        0x0A: "Raises the user's Attack by 1 stage.",
        0x0B: "Raises the user's Defense by 1 stage.",
        0x0C: "Raises the user's Speed by 1 stage.",
        0x0D: "Raises the user's Special by 1 stage.",
        0x0E: "Raises the user's accuracy by 1 stage.",
        0x0F: "Raises the user's evasion by 1 stage.",
        0x10: "Scatters money: you pick up 2× the user's level after battle.",
        0x11: "Never misses (ignores accuracy and evasion checks).",
        0x12: "Lowers the target's Attack by 1 stage.",
        0x13: "Lowers the target's Defense by 1 stage.",
        0x14: "Lowers the target's Speed by 1 stage.",
        0x15: "Lowers the target's Special by 1 stage.",
        0x16: "Lowers the target's accuracy by 1 stage.",
        0x17: "Lowers the target's evasion by 1 stage.",
        0x18: "Changes the user's type to match the target's.",
        0x19: "Resets all stat changes and ends status conditions for both sides.",
        0x1A: "Waits 2–3 turns, then deals back twice the damage taken.",
        0x1B: "Attacks for 2–3 turns, then the user becomes confused.",
        0x1C: "Ends wild battles (flees or blows the wild Pokémon away). Fails against trainers.",
        0x1D: "Hits 2–5 times in one turn.",
        0x1F: "May make the target flinch: " + pct(c["flinch1"]) + ".",
        0x20: "Puts the target to sleep.",
        0x21: "May poison the target: " + pct(c["poison2"]) + ".",
        0x22: "May burn the target: " + pct(c["status2"]) + ".",
        0x24: "May paralyze the target: " + pct(c["status2"]) + ".",
        0x25: "May make the target flinch: " + pct(c["flinch2"]) + ".",
        0x26: "One-hit KO. Fails if the target is faster than the user.",
        0x27: "Charges on the first turn, attacks on the second.",
        0x28: "Halves the target's current HP.",
        0x29: "Deals fixed damage (Sonic Boom 20, Dragon Rage 40, Seismic Toss / Night Shade = user's level, Psywave = random up to 1.5× level).",
        0x2A: "Traps the target for 2–5 turns; the target cannot act.",
        0x2B: "Flies up on turn 1 (untouchable), attacks on turn 2.",
        0x2C: "Hits twice in one turn.",
        0x2D: "If it misses, the user takes 1 HP of crash damage.",
        0x2E: "Protects the user's stats from being lowered.",
        0x2F: "Meant to raise the critical-hit rate — the Gen 1 engine divides it by 4 instead (bug).",
        0x30: "The user takes recoil equal to 1/4 of the damage dealt (Struggle: 1/2).",
        0x31: "Confuses the target.",
        0x32: "Raises the user's Attack by 2 stages.",
        0x33: "Raises the user's Defense by 2 stages.",
        0x34: "Raises the user's Speed by 2 stages.",
        0x35: "Raises the user's Special by 2 stages.",
        0x38: "Restores up to half of max HP (Rest: fully heals and sleeps for 2 turns). Fails if HP is 255/511 below max (engine bug).",
        0x39: "Transforms into a copy of the target.",
        0x3B: "Lowers the target's Defense by 2 stages.",
        0x40: "Halves Special damage taken while active.",
        0x41: "Halves physical damage taken while active.",
        0x42: "Poisons the target (Toxic: badly poisons).",
        0x43: "Paralyzes the target.",
        0x44: "May lower the target's Attack by 1 stage: " + pct(c["statdown"]) + ".",
        0x45: "May lower the target's Defense by 1 stage: " + pct(c["statdown"]) + ".",
        0x46: "May lower the target's Speed by 1 stage: " + pct(c["statdown"]) + ".",
        0x47: "May lower the target's Special by 1 stage: " + pct(c["statdown"]) + ".",
        0x4C: "May confuse the target: " + pct(c["confuse"]) + ".",
        0x4D: "Hits twice; each hit may poison the target: " + pct(c["poison1"]) + ".",
        0x4F: "Uses 1/4 of max HP to create a decoy that takes damage.",
        0x50: "Must recharge next turn — unless it knocks out the target.",
        0x51: "Keeps attacking; Attack rises each time the user is hit.",
        0x52: "Copies one of the target's moves for the rest of battle.",
        0x53: "Uses a random move.",
        0x54: "Drains 1/16 of the target's max HP each turn. Grass types are immune.",
        0x55: "No effect.",
        0x56: "Disables one of the target's moves for a few turns.",
    }

GROWTH_NAMES = ["Medium Fast", "Slightly Fast", "Slightly Slow", "Medium Slow", "Fast", "Slow"]
GAME_CORNER_PRIZE_ROOM = 0x89
NOT_A_MAP_ROUTINE_BANKS = {0x00, 0x01}   # home + engine bank: never map scripts


# ---------------------------------------------------------------- assemble
def pack2bpp(px):
    """Pack 2-bit colour indices, 4 pixels per byte, row-major."""
    flat = [v for row in px for v in row]
    out = bytearray()
    for i in range(0, len(flat), 4):
        a = flat[i:i + 4] + [0] * (4 - len(flat[i:i + 4]))
        out.append(a[0] << 6 | a[1] << 4 | a[2] << 2 | a[3])
    return base64.b64encode(bytes(out)).decode()

def build(rom_path):
    rom = Rom(rom_path)
    info = check_rom(rom)
    if not info["is_rev0_red"]:
        print("warning: ROM does not match Pokémon Red Rev 0 (sha1 %s)" % info["sha1"], file=sys.stderr)

    names, dexno, internal_of = species_tables(rom)
    TN = type_names(rom)
    MV = moves(rom)
    ITEMS = item_names(rom)
    GR = growth_rates(rom)
    EFF = effect_texts(rom)
    tms = list(rom.b[TM_MOVES:TM_MOVES + 55])
    hc_at, hc = high_crit_moves(rom)
    mnames = map_names(rom)
    dex = lambda internal: dexno.get(internal, 0)

    # ---- moves
    move_out = {}
    for mid, m in MV.items():
        d = dict(m)
        d["type_name"] = TN[m["type"]]
        d["effect_text"] = EFF.get(m["effect"], "")
        if mid in hc: d["high_crit"] = True
        if mid in tms:
            n = tms.index(mid) + 1
            d["machine"] = ("TM%02d" % n) if n <= 50 else ("HM%02d" % (n - 50))
        move_out[mid] = d

    # ---- type chart
    chart = [{"atk": a, "def": b, "mult": x} for a, b, x in type_chart(rom)]

    # ---- per-map lookups
    anchors = {}
    for m in mnames:
        if m == 0x0B: continue                   # unused map ID
        try: anchors[m] = map_anchors(rom, m)
        except Exception: pass
    where = lambda off: map_owning(anchors, off)

    enc = {}          # dex -> list of encounter dicts
    def add(internal, e):
        d = dex(internal)
        if 1 <= d <= 151: enc.setdefault(d, []).append(e)

    chances = slot_chances(rom)
    for m, t in wild_tables(rom).items():
        for kind, rate in (("grass", "grass_rate"), ("water", "water_rate")):
            agg = {}
            for slot, (lv, sp) in enumerate(t[kind]):
                a = agg.setdefault(sp, {"chance": 0, "levels": set(), "slots": []})
                a["chance"] += chances[slot]; a["levels"].add(lv); a["slots"].append(slot + 1)
            for sp, a in agg.items():
                add(sp, {"kind": "walk" if kind == "grass" else "surf", "map": m, "map_name": mnames[m]["name"],
                         "area": mnames[m]["area"], "chance": a["chance"], "levels": sorted(a["levels"]),
                         "slots": a["slots"], "rate": t[rate]})
    old, good = old_good_rod(rom)
    for lv, sp in old: add(sp, {"kind": "old_rod", "levels": [lv], "chance": 256, "bite": 256})
    for lv, sp in good: add(sp, {"kind": "good_rod", "levels": [lv], "chance": 128, "bite": 128})
    for m, group in super_rod(rom).items():
        agg = {}
        for lv, sp in group:
            a = agg.setdefault(sp, {"n": 0, "levels": set()}); a["n"] += 1; a["levels"].add(lv)
        for sp, a in agg.items():
            add(sp, {"kind": "super_rod", "map": m, "map_name": mnames[m]["name"], "area": mnames[m]["area"],
                     "levels": sorted(a["levels"]), "chance": round(256 * a["n"] / len(group)), "bite": 128,
                     "group": len(group)})

    # ---- map objects: static Pokémon + trainer placement
    trainer_locs = {}
    for m in mnames:
        if m == 0x0B: continue
        try: objs = map_objects(rom, m)
        except Exception: continue
        for ob in objs:
            if "battle" not in ob: continue
            a, b = ob["battle"]
            if a >= 200: trainer_locs.setdefault((a - 200, b), []).append(m)
            else:
                add(a, {"kind": "static", "map": m, "map_name": mnames[m]["name"], "area": mnames[m]["area"], "levels": [b]})

    for sb in scripted_battles(rom):
        if Rom.bank_of(sb["at"]) in NOT_A_MAP_ROUTINE_BANKS: continue
        m = where(sb["at"])
        if m is None: continue
        if sb["value"] < 200 and sb["level"]:
            add(sb["value"], {"kind": "static", "map": m, "map_name": mnames[m]["name"], "area": mnames[m]["area"],
                              "levels": [sb["level"]], "scripted": True})

    # rival battles are started from scripts; each sets wTrainerNo to the last
    # member of a trio of parties (one per rival starter)
    rival_battles = {}
    for sb in scripted_battles(rom):
        v = sb["value"]
        if v < 200 or Rom.bank_of(sb["at"]) in NOT_A_MAP_ROUTINE_BANKS: continue
        cls = v - 200
        m = where(sb["at"])
        win = rom.b[sb["at"]:sb["at"] + 60]
        nums = [win[i + 1] for i in range(len(win) - 4) if win[i] == 0x3E and win[i + 2:i + 5] == bytes([0xEA, 0x5D, 0xD0])]
        rival_battles.setdefault(cls, []).append((m, max(nums) if nums else None))
    for cls in rival_battles:
        # rival NPC objects carry a placeholder party that the script overrides
        for key in [k for k in trainer_locs if k[0] == cls]: del trainer_locs[key]
    for cls, lst in rival_battles.items():
        tr_count = len(trainers(rom)[cls]["parties"])
        known = {n for _, n in lst if n}
        missing = [n for n in range(3, tr_count + 1, 3) if n not in known]
        for m, n in lst:
            if n is None and missing: n = missing.pop(0)
            if n is None: continue
            for k in range(n - 2, n + 1):
                trainer_locs.setdefault((cls, k), []).append(m)

    TR = trainers(rom)
    for cls, t in TR.items():
        for k, party in enumerate(t["parties"], 1):
            locs = sorted(set(trainer_locs.get((cls, k), [])))
            seen = set()
            for lv, sp in party:
                if sp in seen: continue
                seen.add(sp)
                add(sp, {"kind": "trainer", "class": cls, "class_name": t["name"], "party": k,
                         "levels": sorted(l for l, s in party if s == sp),
                         "team": [[l, dex(s)] for l, s in party],
                         "maps": [mnames[m]["name"] for m in locs]})

    # gifts
    for g in gift_calls(rom):
        m = where(g["at"])
        if g["species"]:
            add(g["species"], {"kind": "gift", "map": m, "map_name": mnames[m]["name"], "area": mnames[m]["area"], "levels": [g["level"]]})
        elif g["level"] and m is not None:
            # `ld a, SPECIES / call DisplayPokedex` precedes the offer (Fighting Dojo)
            s = g["at"]; back = rom.b[s - 40:s]
            k = back.rfind(b"\xcd\x9b\x34")
            if k >= 2 and back[k - 2] == 0x3E:
                add(back[k - 1], {"kind": "gift", "map": m, "map_name": mnames[m]["name"], "area": mnames[m]["area"],
                                  "levels": [g["level"]], "choice": True})
            else:
                fossil_lv = g["level"]
                for item, sp in fossils(rom):
                    add(sp, {"kind": "fossil", "map": m, "map_name": mnames[m]["name"], "area": mnames[m]["area"],
                             "levels": [fossil_lv], "item": ITEMS[item] if item else "OLD AMBER"})
    # starters: Oak's Lab `ld a,SPECIES / ld [wcd3d],a / ld a,N / ld [wcd3e],a`
    oak = 0x28
    starter_lv = None
    for s in find_all(rom, [0x3E, 0x05, 0xEA, W_CUR_ENEMY_LVL & 0xFF, W_CUR_ENEMY_LVL >> 8]):
        if where(s) == oak: starter_lv = rom.u8(s + 1)
    for s in find_all(rom, [0xEA, 0x3D, 0xCD, 0x3E]):
        if rom.u8(s - 2) == 0x3E and rom.b[s + 5:s + 8] == b"\xea\x3e\xcd" and where(s) == oak:
            add(rom.u8(s - 1), {"kind": "starter", "map": oak, "map_name": mnames[oak]["name"], "area": mnames[oak]["area"],
                                "levels": [starter_lv] if starter_lv else []})
    # in-game trades
    TM_ = trade_mons(rom)
    for idx, s in trade_calls(rom):
        m = where(s); t = TM_[idx]
        add(t["get"], {"kind": "trade", "map": m, "map_name": mnames[m]["name"], "area": mnames[m]["area"],
                       "give": dex(t["give"]), "nickname": t["nickname"]})
    # Game Corner prizes
    for sp, cost, lv in prize_mons(rom):
        m = GAME_CORNER_PRIZE_ROOM
        add(sp, {"kind": "prize", "map": m, "map_name": mnames[m]["name"], "area": mnames[m]["area"],
                 "levels": [lv], "coins": cost})

    # ---- species
    mons = []
    evolves_from = {}
    evo_cache = {}
    for d in range(1, 152):
        i = internal_of[d]
        evo_cache[d] = evos_moves(rom, i)
        for e in evo_cache[d][0]:
            evolves_from[dex(e["to"])] = d
    for d in range(1, 152):
        i = internal_of[d]
        bs = base_stats(rom, d)
        evos, learn = evo_cache[d]
        de = dex_entry(rom, i)
        bank = pic_bank(rom, i)
        wt, ht, fpx = decompress_pic(rom, Rom.off(bank, bs["front_ptr"]))
        bwt, bht, bpx = decompress_pic(rom, Rom.off(bank, bs["back_ptr"]))
        pal = sgb_palette(rom, rom.u8(MON_PALETTES + d))
        rate = GR[bs["growth_rate"]]
        types = [TN[t] for t in dict.fromkeys(bs["types"])]
        mons.append({
            "dex": d, "internal": i, "name": names[i],
            "species": de["species"], "height_ft": de["height_ft"], "height_in": de["height_in"],
            "weight_lb": de["weight_lb"], "entry": de["text"] + ".",
            "entry_pages": [p.split("\n") for p in (de["text"] + ".").split("\n\n")],
            "types": types, "type_ids": list(dict.fromkeys(bs["types"])),
            "stats": {k: bs[k] for k in ("hp", "attack", "defense", "speed", "special")},
            "catch_rate": bs["catch_rate"], "base_exp": bs["base_exp"],
            "growth_rate": GROWTH_NAMES[bs["growth_rate"]], "growth_id": bs["growth_rate"],
            "exp_100": exp_for_level(rate, 100),
            "start_moves": bs["start_moves"],
            "learnset": [[lv, mv] for lv, mv in learn],
            "tmhm": [tms[n - 1] for n in bs["tmhm_bits"]],
            "tmhm_numbers": bs["tmhm_bits"],
            "evolutions": [dict(e, to=dex(e["to"]), item_name=ITEMS.get(e.get("item"))) for e in evos],
            "evolves_from": evolves_from.get(d),
            "encounters": enc.get(d, []),
            "sprite": {"w": wt, "h": ht, "front": pack2bpp(place_front(wt, ht, fpx)),
                       "back": pack2bpp(bpx), "back_w": bwt, "back_h": bht},
            "palette": pal, "palette_id": rom.u8(MON_PALETTES + d),
            "rom": {"base_stats": "0x%05X" % bs["offset"], "pic_bank": "0x%02X" % bank,
                    "front_pic": "%02X:%04X" % (bank, bs["front_ptr"]), "back_pic": "%02X:%04X" % (bank, bs["back_ptr"])},
        })

    # evolution families
    def root(d):
        while evolves_from.get(d): d = evolves_from[d]
        return d
    for mon in mons: mon["family"] = root(mon["dex"])

    # the game's own 8x8 1bpp font, char codes $80-$FF
    font = base64.b64encode(rom.b[FONT_GFX:FONT_GFX + 128 * 8]).decode()
    charmap = {v: k for k, v in CHARS.items() if len(v) == 1 and k >= 0x80}

    exp_tables = [[exp_for_level(r, n) for n in range(1, 101)] for r in GR]
    return {
        "meta": {"rom": info, "slot_chances": chances, "growth_names": GROWTH_NAMES,
                 "growth_formulas": [list(r) for r in GR], "exp_tables": exp_tables,
                 "high_crit_moves": hc, "tm_moves": tms,
                 "offsets": {k: "0x%05X" % v for k, v in {
                     "MonsterNames": MON_NAMES, "PokedexOrder": POKEDEX_ORDER, "BaseStats": BASE_STATS,
                     "MewBaseStats": MEW_BASE_STATS, "EvosMovesPointerTable": EVOS_MOVES_PTRS,
                     "PokedexEntryPointers": DEX_ENTRY_PTRS, "Moves": MOVES, "MoveNames": MOVE_NAMES,
                     "ItemNames": ITEM_NAMES, "TypeNames": TYPE_NAME_PTRS, "TypeEffects": TYPE_EFFECTS,
                     "TechnicalMachines": TM_MOVES, "GrowthRateTable": GROWTH_RATES,
                     "WildMonEncounterSlotChances": WILD_SLOT_CHANCE, "WildDataPointers": WILD_PTRS,
                     "SuperRodData": SUPER_ROD_TABLE, "TrainerDataPointers": TRAINER_PTRS,
                     "TrainerNames": TRAINER_NAMES, "TradeMons": TRADE_MONS, "MonsterPalettes": MON_PALETTES,
                     "SuperPalettes": SGB_PALETTES, "FontGraphics": FONT_GFX, "HighCriticalMoves": hc_at or 0,
                     "MapHeaderPointers": MAP_HEADER_PTRS, "MapHeaderBanks": MAP_HEADER_BANKS,
                     "ExternalMapEntries": TOWN_MAP_EXTERNAL, "InternalMapEntries": TOWN_MAP_INTERNAL}.items()}},
        "types": {k: v for k, v in TN.items() if k in {t for m in MV.values() for t in [m["type"]]} | {t for d in range(1, 152) for t in base_stats(rom, d)["types"]}},
        "type_chart": chart,
        "font": {"glyphs": font, "first": 0x80, "charmap": charmap},
        "moves": move_out,
        "pokemon": mons,
    }

if __name__ == "__main__":
    rom_path = sys.argv[1] if len(sys.argv) > 1 else None
    if not rom_path: sys.exit(__doc__)
    here = os.path.dirname(os.path.abspath(__file__))
    out = os.path.join(here, "..", "data", "pokedex.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    data = build(rom_path)
    with open(out, "w") as f: json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    print("wrote %s (%d Pokémon, %d moves, %.0f KB)" % (os.path.relpath(out), len(data["pokemon"]), len(data["moves"]), os.path.getsize(out) / 1024))
