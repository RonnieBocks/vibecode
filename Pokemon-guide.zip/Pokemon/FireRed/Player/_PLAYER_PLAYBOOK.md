# 🛠️ Player Folder — Build & Maintenance Playbook

How the four **Player** notes work, which are **regenerated from data** vs **live hand-kept state**, and the exact recipe to rebuild the regenerable ones fast. Sits beside the [[00 - Index & Basics|Walkthrough]] (whose own recipe is in `Walkthrough/_BUILD_PLAYBOOK.md`).

> [!info] The 4 files at a glance
> | File | Kind | Source of truth |
> |---|---|---|
> | [[Pokemon FireRed]] | **Hub** (mostly static + a few live numbers) | hand-kept; numbers mirror the trackers |
> | [[Pokedex Reference]] | **Generated** (100% from decomp) | `builddex.py` → pret/pokefirered |
> | [[Pokedex Tracker]] | **Template + live state** | skeleton generated from decomp/appendices; checkboxes & `×N` are live |
> | [[Team & Boxes]] | **Live player state** | hand-kept from what Ronnie reports in chat |
> | [[Progress Checklist]] | **Generated skeleton + live ticks** | steps pulled from each area's “Do this in order” + 8-badge/HM/legendary/Living-Dex milestones; checkboxes are live |

> [!important] Single source of truth (added 2026-09-23)
> **[[Team & Boxes]] is the ONE file the player edits for what they own.** Everything species-related is **derived** from its party+box tables by **`sync_dex.py`** (scratch):
> - Pokédex Tracker → checkbox + `×N` per species (counts individuals by current species, so evolving auto-unchecks the earlier stage).
> - Progress Checklist → the "Catch here" species boxes (base×N; checks = number of that family held). Walkthrough steps & milestones stay hand-ticked.
> - Hub → the Living-Dex `X / 151` count (distinct species held).
>
> **`sync_dex.py` READS Team & Boxes and WRITES only the three derived files — it must never write Team & Boxes** (the player edits it live; writing there races/clobbers). Run it after the player reports a catch/evolution. It needs `dexmap.json` (species dex order + family roots, built from the decomp).

Two of these regenerate from data; two are living logs. Keep that split in mind — never overwrite a live file from a script.

---

## 1. Pokémon FireRed.md — the Hub

**Purpose:** landing page. A links block to the other trackers + Walkthrough, a small **Status at a glance** table (badges / E4 / Living-Dex count), the solo "full 151" plan, and a short "next up" note.

**Kind:** hand-kept. The status numbers are a *convenience mirror* — the real counts live in [[Pokedex Tracker]] (held species) and progress in the Walkthrough.

**Maintain:** update the 3 status rows as badges/dex change. Do **not** duplicate the live team here — link to [[Team & Boxes]] instead (see Improvements §5).

---

## 2. Pokédex Reference.md — fully generated

**Purpose:** every Kanto line (001–151): types, base stats + BST, evolution paths, level-up moves, TM/HM, tutor & egg moves. Look-ahead reference; never tracks progress.

**Kind:** **100% generated from the decomp** — regenerate any time, it has no player state.

### Regenerate recipe
Generator: **`builddex.py`** (kept in the session scratchpad). Data = raw files from `https://raw.githubusercontent.com/pret/pokefirered/master/`:

| Data | Decomp file |
|---|---|
| Species order (151 by dex) | `src/data/pokemon/level_up_learnset_pointers.h` |
| Base stats + types | `src/data/pokemon/species_info.h` |
| Level-up moves | `src/data/pokemon/level_up_learnsets.h` |
| Evolutions | `src/data/pokemon/evolution.h` |
| TM/HM | `src/data/pokemon/tmhm_learnsets.h` |
| Tutor moves | `src/data/pokemon/tutor_learnsets.h` |
| Egg moves | `src/data/pokemon/egg_moves.h` |

Steps: (1) fetch those 7 files; (2) run `builddex.py` (parses each with per-`[SPECIES_*]`-block splits to avoid cross-bleed — same gotcha as the Walkthrough engine); (3) it emits the markdown to `Player/Pokedex Reference.md`.

**Format spec (so a rebuild matches):**
- Title `# 📗 Pokédex Reference (Kanto 001–151)`, a "Reading this" note, then one block per species separated by blank lines.
- Per species: `### NNN Name — Type1/Type2`, then `- **Stats** …— **BST n**`, `- **Evolves:** …`, `- **Level-up:** …`, `- **TM/HM:** …`, `- **Tutor:** …`, `- **Egg:** …` (dash `—` when none).
- Names normalized: `Nidoran♀/♂`, `Mr. Mime`, `Farfetch'd`. Moves/items Title-Cased from their `MOVE_`/`ITEM_` tokens.
- Gen-2 cross-evolutions (Bellossom, Espeon, Crobat, Scizor, Kingdra…) are shown for completeness but flagged as outside the 151 goal.

---

## 3. Pokédex Tracker.md — template + live checkboxes

**Purpose:** the Living-Dex checklist. All 151 with **how to obtain each** (Wild / Evolve / Stone / Trade-evo / Gift / Fossil / FR-excl / LG-excl / event), a `×N` counter on held lines, and the "can't-do-solo" summary.

**Kind:** the **skeleton is regenerable**, the **checkboxes and `×N` counts are live** — regenerating must *preserve* the checks. Treat the how-to-get text as data (verify against the decomp + appendices); treat `- [x]` and `×N` as Ronnie's state.

### Regenerate / verify the skeleton
Data sources for the "how to get" column:
- **Evolution method & level/stone** → `evolution.h` (same as the Reference).
- **Version exclusives (13 LG) & trade-evos (4)** → `[[A3 - Trades & Exclusives]]` (computed by diffing FR vs LG wild tables).
- **Stone users & counts** → `[[A2 - Evolution Item Budget]]`.
- **Statics, gifts, fossils, Master Ball, one-time picks** → `[[A1 - Missables]]`.
- **In-game NPC trades** → `src/data/ingame_trades.h` (Mr. Mime←Abra, Jynx←Poliwhirl, Farfetch'd←Spearow, **Lickitung←Golduck in FireRed** / Slowbro in LG, Tangela/Seel/Electrode at the Cinnabar Lab).

**To rebuild without losing state:** parse the existing file's `- [x]`/`×N` per dex number, regenerate the 151 lines from the sources above, then re-apply the saved checks/counts by number. Keep the section headers (`## #001–030` …) and the "can't-do-solo" checklist at the end.

### Live maintenance
When Ronnie catches/evolves/releases: toggle the `- [ ]`/`- [x]`, bump/lower the `×N`, and remember the **Living-Dex rule** — evolving your only copy *unchecks* the earlier stage until re-obtained.

---

## 4. Team & Boxes.md — pure live state

**Purpose:** the actual individual Pokémon: **Current Party** table (species, nick, level, 4 moves, held item) + **Box** table of benched/spares + a Notes block (carries, leveling projects, shopping needs).

**Kind:** **not generated** — this is Ronnie's live save state, updated only from what they report. Cross-check move legality/level against [[Pokedex Reference]]; species counts should agree with the `×N` in [[Pokedex Tracker]].

**Maintain:** update rows on level-ups, new moves, evolutions, items, box moves. This is the single source of truth for the team — the Hub should link here, not copy it.

---

## 5. Improvements (recommended)

**Applied:**
- **Tracker fix:** Lickitung's in-game trade is **Golduck → Lickitung** in FireRed (the file previously said Slowbro, which is the LeafGreen version).

**Suggested (not yet applied — ask before changing live files):**
1. **De-duplicate the team.** The Hub's "Current team" block drifts from [[Team & Boxes]] (Hub still lists the pre-Wartortle party). Drop the snapshot from the Hub; keep [[Team & Boxes]] as the only team source and link to it.
2. **Hub → Appendices links.** Add the four appendices ([[A1 - Missables]]…[[A4 - Hidden Items]]) to the Hub's Trackers block.
3. **Tracker ↔ Appendix links.** Turn the LG-excl / trade-evo / stone notes into links to [[A3 - Trades & Exclusives]] and [[A2 - Evolution Item Budget]] so a click explains the "how".
4. **Reference TOC.** Add a tiny per-range jump list (001–030 …) at the top of [[Pokedex Reference]] for faster navigation (Ctrl/Cmd-F already works).
5. **Auto-count helper.** The Hub's "Living Dex X/151" can be kept honest by counting `- [x]` lines in the Tracker whenever it's updated.

---

*Companion recipe for the maps/walkthrough: `Walkthrough/_BUILD_PLAYBOOK.md`.*
