# 📗 Pokédex Reference (Kanto 001–151)

Back to [[Pokemon FireRed]] · Companion to [[Team & Boxes]] & [[Pokedex Tracker]]
**Source: [pret/pokefirered decompilation](https://github.com/pret/pokefirered) — exact FireRed data.** Full line info for look-ahead: types, base stats, evolutions, level-up moves, TM/HM, tutor & egg moves.

> [!note] Reading this
> - **Stats** order: HP / Atk / Def / SpA / SpD / Spe (Gen-3 split special).
> - **Evolves** lists every path in the data. A few targets (Bellossom, Espeon, Umbreon, Crobat, Scizor, Steelix, Kingdra, Politoed, Slowking, Blissey, Porygon2…) are **Gen-2 forms outside the 151 goal** — shown for completeness, not required for your dex.
> - **TM/HM** uses FireRed's TM numbering. **Egg** moves matter for re-obtaining pre-evolutions via breeding (your Living-Dex trick).

*Use Ctrl/Cmd+F to jump to a species. Ask me and I'll pull a line's details or plan a moveset.*

## 🔎 Jump to
[[#001–030]] · [[#031–060]] · [[#061–090]] · [[#091–120]] · [[#121–151]]

---

## #001–030

### 001 Bulbasaur — Grass/Poison
- **Stats** HP 45 / Atk 49 / Def 49 / SpA 65 / SpD 65 / Spe 45 — **BST 318**
- **Evolves:** → Ivysaur at L16
- **Level-up:** L1 Tackle, L4 Growl, L7 Leech Seed, L10 Vine Whip, L15 Poison Powder, L15 Sleep Powder, L20 Razor Leaf, L25 Sweet Scent, L32 Growth, L39 Synthesis, L46 Solar Beam
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM01 Cut, HM04 Strength, HM05 Flash, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** Light Screen, Skull Bash, Safeguard, Charm, Petal Dance, Magical Leaf, Grass Whistle, Curse

### 002 Ivysaur — Grass/Poison
- **Stats** HP 60 / Atk 62 / Def 63 / SpA 80 / SpD 80 / Spe 60 — **BST 405**
- **Evolves:** → Venusaur at L32
- **Level-up:** L1 Tackle, L1 Growl, L1 Leech Seed, L4 Growl, L7 Leech Seed, L10 Vine Whip, L15 Poison Powder, L15 Sleep Powder, L22 Razor Leaf, L29 Sweet Scent, L38 Growth, L47 Synthesis, L56 Solar Beam
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM01 Cut, HM04 Strength, HM05 Flash, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** —

### 003 Venusaur — Grass/Poison
- **Stats** HP 80 / Atk 82 / Def 83 / SpA 100 / SpD 100 / Spe 80 — **BST 525**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Growl, L1 Leech Seed, L1 Vine Whip, L4 Growl, L7 Leech Seed, L10 Vine Whip, L15 Poison Powder, L15 Sleep Powder, L22 Razor Leaf, L29 Sweet Scent, L41 Growth, L53 Synthesis, L65 Solar Beam
- **TM/HM:** TM05 Roar, TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM26 Earthquake, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM01 Cut, HM04 Strength, HM05 Flash, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** —

### 004 Charmander — Fire
- **Stats** HP 39 / Atk 52 / Def 43 / SpA 60 / SpD 50 / Spe 65 — **BST 309**
- **Evolves:** → Charmeleon at L16
- **Level-up:** L1 Scratch, L1 Growl, L7 Ember, L13 Metal Claw, L19 Smokescreen, L25 Scary Face, L31 Flamethrower, L37 Slash, L43 Dragon Rage, L49 Fire Spin
- **TM/HM:** TM01 Focus Punch, TM02 Dragon Claw, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM50 Overheat, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Swords Dance, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** Belly Drum, Ancient Power, Rock Slide, Bite, Outrage, Beat Up, Swords Dance, Dragon Dance

### 005 Charmeleon — Fire
- **Stats** HP 58 / Atk 64 / Def 58 / SpA 80 / SpD 65 / Spe 80 — **BST 405**
- **Evolves:** → Charizard at L36
- **Level-up:** L1 Scratch, L1 Growl, L1 Ember, L7 Ember, L13 Metal Claw, L20 Smokescreen, L27 Scary Face, L34 Flamethrower, L41 Slash, L48 Dragon Rage, L55 Fire Spin
- **TM/HM:** TM01 Focus Punch, TM02 Dragon Claw, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM50 Overheat, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Swords Dance, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 006 Charizard — Fire/Flying
- **Stats** HP 78 / Atk 84 / Def 78 / SpA 109 / SpD 85 / Spe 100 — **BST 534**
- **Evolves:** does not evolve
- **Level-up:** L1 Heat Wave, L1 Scratch, L1 Growl, L1 Ember, L1 Metal Claw, L7 Ember, L13 Metal Claw, L20 Smokescreen, L27 Scary Face, L34 Flamethrower, L36 Wing Attack, L44 Slash, L54 Dragon Rage, L64 Fire Spin
- **TM/HM:** TM01 Focus Punch, TM02 Dragon Claw, TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM47 Steel Wing, TM50 Overheat, HM01 Cut, HM02 Fly, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Swords Dance, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 007 Squirtle — Water
- **Stats** HP 44 / Atk 48 / Def 65 / SpA 50 / SpD 64 / Spe 43 — **BST 314**
- **Evolves:** → Wartortle at L16
- **Level-up:** L1 Tackle, L4 Tail Whip, L7 Bubble, L10 Withdraw, L13 Water Gun, L18 Bite, L23 Rapid Spin, L28 Protect, L33 Rain Dance, L40 Skull Bash, L47 Hydro Pump
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic
- **Egg:** Mirror Coat, Haze, Mist, Foresight, Flail, Refresh, Mud Sport, Yawn

### 008 Wartortle — Water
- **Stats** HP 59 / Atk 63 / Def 80 / SpA 65 / SpD 80 / Spe 58 — **BST 405**
- **Evolves:** → Blastoise at L36
- **Level-up:** L1 Tackle, L1 Tail Whip, L1 Bubble, L4 Tail Whip, L7 Bubble, L10 Withdraw, L13 Water Gun, L19 Bite, L25 Rapid Spin, L31 Protect, L37 Rain Dance, L45 Skull Bash, L53 Hydro Pump
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic
- **Egg:** —

### 009 Blastoise — Water
- **Stats** HP 79 / Atk 83 / Def 100 / SpA 85 / SpD 105 / Spe 78 — **BST 530**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Tail Whip, L1 Bubble, L1 Withdraw, L4 Tail Whip, L7 Bubble, L10 Withdraw, L13 Water Gun, L19 Bite, L25 Rapid Spin, L31 Protect, L42 Rain Dance, L55 Skull Bash, L68 Hydro Pump
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic
- **Egg:** —

### 010 Caterpie — Bug
- **Stats** HP 45 / Atk 30 / Def 35 / SpA 20 / SpD 20 / Spe 45 — **BST 195**
- **Evolves:** → Metapod at L7
- **Level-up:** L1 Tackle, L1 String Shot
- **TM/HM:** —
- **Tutor:** —
- **Egg:** —

### 011 Metapod — Bug
- **Stats** HP 50 / Atk 20 / Def 55 / SpA 25 / SpD 25 / Spe 30 — **BST 205**
- **Evolves:** → Butterfree at L10
- **Level-up:** L1 Harden, L7 Harden
- **TM/HM:** —
- **Tutor:** —
- **Egg:** —

### 012 Butterfree — Bug/Flying
- **Stats** HP 60 / Atk 45 / Def 50 / SpA 80 / SpD 80 / Spe 70 — **BST 385**
- **Evolves:** does not evolve
- **Level-up:** L1 Confusion, L10 Confusion, L13 Poison Powder, L14 Stun Spore, L15 Sleep Powder, L18 Supersonic, L23 Whirlwind, L28 Gust, L34 Psybeam, L40 Safeguard, L47 Silver Wind
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, HM05 Flash
- **Tutor:** Double Edge, Mimic, Dream Eater
- **Egg:** —

### 013 Weedle — Bug/Poison
- **Stats** HP 40 / Atk 35 / Def 30 / SpA 20 / SpD 20 / Spe 50 — **BST 195**
- **Evolves:** → Kakuna at L7
- **Level-up:** L1 Poison Sting, L1 String Shot
- **TM/HM:** —
- **Tutor:** —
- **Egg:** —

### 014 Kakuna — Bug/Poison
- **Stats** HP 45 / Atk 25 / Def 50 / SpA 25 / SpD 25 / Spe 35 — **BST 205**
- **Evolves:** → Beedrill at L10
- **Level-up:** L1 Harden, L7 Harden
- **TM/HM:** —
- **Tutor:** —
- **Egg:** —

### 015 Beedrill — Bug/Poison
- **Stats** HP 65 / Atk 80 / Def 40 / SpA 45 / SpD 80 / Spe 75 — **BST 385**
- **Evolves:** does not evolve
- **Level-up:** L1 Fury Attack, L10 Fury Attack, L15 Focus Energy, L20 Twineedle, L25 Rage, L30 Pursuit, L35 Pin Missile, L40 Agility, L45 Endeavor
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM31 Brick Break, TM32 Double Team, TM36 Sludge Bomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM06 Rock Smash
- **Tutor:** Swords Dance, Double Edge, Mimic
- **Egg:** —

### 016 Pidgey — Normal/Flying
- **Stats** HP 40 / Atk 45 / Def 40 / SpA 35 / SpD 35 / Spe 56 — **BST 251**
- **Evolves:** → Pidgeotto at L18
- **Level-up:** L1 Tackle, L5 Sand Attack, L9 Gust, L13 Quick Attack, L19 Whirlwind, L25 Wing Attack, L31 Feather Dance, L39 Agility, L47 Mirror Move
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM02 Fly
- **Tutor:** Double Edge, Mimic
- **Egg:** Pursuit, Faint Attack, Foresight, Steel Wing, Air Cutter

### 017 Pidgeotto — Normal/Flying
- **Stats** HP 63 / Atk 60 / Def 55 / SpA 50 / SpD 50 / Spe 71 — **BST 349**
- **Evolves:** → Pidgeot at L36
- **Level-up:** L1 Tackle, L1 Sand Attack, L1 Gust, L5 Sand Attack, L9 Gust, L13 Quick Attack, L20 Whirlwind, L27 Wing Attack, L34 Feather Dance, L43 Agility, L52 Mirror Move
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM02 Fly
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 018 Pidgeot — Normal/Flying
- **Stats** HP 83 / Atk 80 / Def 75 / SpA 70 / SpD 70 / Spe 91 — **BST 469**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Sand Attack, L1 Gust, L1 Quick Attack, L5 Sand Attack, L9 Gust, L13 Quick Attack, L20 Whirlwind, L27 Wing Attack, L34 Feather Dance, L48 Agility, L62 Mirror Move
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM02 Fly
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 019 Rattata — Normal
- **Stats** HP 30 / Atk 56 / Def 35 / SpA 25 / SpD 35 / Spe 72 — **BST 253**
- **Evolves:** → Raticate at L20
- **Level-up:** L1 Tackle, L1 Tail Whip, L7 Quick Attack, L13 Hyper Fang, L20 Focus Energy, L27 Pursuit, L34 Super Fang, L41 Endeavor
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM32 Double Team, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Counter, Mimic, Thunder Wave
- **Egg:** Screech, Flame Wheel, Fury Swipes, Bite, Counter, Reversal, Uproar, Swagger

### 020 Raticate — Normal
- **Stats** HP 55 / Atk 81 / Def 60 / SpA 50 / SpD 70 / Spe 97 — **BST 413**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Tail Whip, L1 Quick Attack, L7 Quick Attack, L13 Hyper Fang, L20 Scary Face, L30 Pursuit, L40 Super Fang, L50 Endeavor
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM32 Double Team, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Counter, Mimic, Thunder Wave
- **Egg:** —

### 021 Spearow — Normal/Flying
- **Stats** HP 40 / Atk 60 / Def 30 / SpA 31 / SpD 31 / Spe 70 — **BST 262**
- **Evolves:** → Fearow at L20
- **Level-up:** L1 Peck, L1 Growl, L7 Leer, L13 Fury Attack, L19 Pursuit, L25 Aerial Ace, L31 Mirror Move, L37 Drill Peck, L43 Agility
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM02 Fly
- **Tutor:** Double Edge, Mimic
- **Egg:** Faint Attack, False Swipe, Scary Face, Quick Attack, Tri Attack, Astonish, Sky Attack

### 022 Fearow — Normal/Flying
- **Stats** HP 65 / Atk 90 / Def 65 / SpA 61 / SpD 61 / Spe 100 — **BST 442**
- **Evolves:** does not evolve
- **Level-up:** L1 Peck, L1 Growl, L1 Leer, L1 Fury Attack, L7 Leer, L13 Fury Attack, L26 Pursuit, L32 Mirror Move, L40 Drill Peck, L47 Agility
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM02 Fly
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 023 Ekans — Poison
- **Stats** HP 35 / Atk 60 / Def 44 / SpA 40 / SpD 54 / Spe 55 — **BST 288**
- **Evolves:** → Arbok at L22
- **Level-up:** L1 Wrap, L1 Leer, L8 Poison Sting, L13 Bite, L20 Glare, L25 Screech, L32 Acid, L37 Stockpile, L37 Swallow, L37 Spit Up, L44 Haze
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM32 Double Team, TM36 Sludge Bomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM49 Snatch, HM04 Strength
- **Tutor:** Body Slam, Double Edge, Mimic, Rock Slide
- **Egg:** Pursuit, Slam, Spite, Beat Up, Poison Fang

### 024 Arbok — Poison
- **Stats** HP 60 / Atk 85 / Def 69 / SpA 65 / SpD 79 / Spe 80 — **BST 438**
- **Evolves:** does not evolve
- **Level-up:** L1 Wrap, L1 Leer, L1 Poison Sting, L1 Bite, L8 Poison Sting, L13 Bite, L20 Glare, L28 Screech, L38 Acid, L46 Stockpile, L46 Swallow, L46 Spit Up, L56 Haze
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM32 Double Team, TM36 Sludge Bomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM49 Snatch, HM04 Strength
- **Tutor:** Body Slam, Double Edge, Mimic, Rock Slide
- **Egg:** —

### 025 Pikachu — Electric
- **Stats** HP 35 / Atk 55 / Def 30 / SpA 50 / SpD 40 / Spe 90 — **BST 300**
- **Evolves:** → Raichu (use Thunder Stone)
- **Level-up:** L1 Thunder Shock, L1 Growl, L6 Tail Whip, L8 Thunder Wave, L11 Quick Attack, L15 Double Team, L20 Slam, L26 Thunderbolt, L33 Agility, L41 Thunder, L50 Light Screen
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM04 Strength, HM05 Flash, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Thunder Wave
- **Egg:** —

### 026 Raichu — Electric
- **Stats** HP 60 / Atk 90 / Def 55 / SpA 90 / SpD 80 / Spe 100 — **BST 475**
- **Evolves:** does not evolve
- **Level-up:** L1 Thunder Shock, L1 Tail Whip, L1 Quick Attack, L1 Thunderbolt
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM05 Flash, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Thunder Wave
- **Egg:** —

### 027 Sandshrew — Ground
- **Stats** HP 50 / Atk 75 / Def 85 / SpA 20 / SpD 30 / Spe 40 — **BST 300**
- **Evolves:** → Sandslash at L22
- **Level-up:** L1 Scratch, L6 Defense Curl, L11 Sand Attack, L17 Poison Sting, L23 Slash, L30 Swift, L37 Fury Swipes, L45 Sand Tomb, L53 Sandstorm
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM37 Sandstorm, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** Flail, Safeguard, Counter, Rapid Spin, Rock Slide, Metal Claw, Swords Dance, Crush Claw

### 028 Sandslash — Ground
- **Stats** HP 75 / Atk 100 / Def 110 / SpA 45 / SpD 55 / Spe 65 — **BST 450**
- **Evolves:** does not evolve
- **Level-up:** L1 Scratch, L1 Defense Curl, L1 Sand Attack, L6 Defense Curl, L11 Sand Attack, L17 Poison Sting, L24 Slash, L33 Swift, L42 Fury Swipes, L52 Sand Tomb, L62 Sandstorm
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM37 Sandstorm, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 029 Nidoran♀ — Poison
- **Stats** HP 55 / Atk 47 / Def 52 / SpA 40 / SpD 40 / Spe 41 — **BST 275**
- **Evolves:** → Nidorina at L16
- **Level-up:** L1 Growl, L1 Scratch, L8 Tail Whip, L12 Double Kick, L17 Poison Sting, L20 Bite, L23 Helping Hand, L30 Fury Swipes, L38 Flatter, L47 Crunch
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM32 Double Team, TM34 Shock Wave, TM36 Sludge Bomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Counter, Mimic
- **Egg:** Supersonic, Disable, Take Down, Focus Energy, Charm, Counter, Beat Up

### 030 Nidorina — Poison
- **Stats** HP 70 / Atk 62 / Def 67 / SpA 55 / SpD 55 / Spe 56 — **BST 365**
- **Evolves:** → Nidoqueen (use Moon Stone)
- **Level-up:** L1 Growl, L1 Scratch, L8 Tail Whip, L12 Double Kick, L18 Poison Sting, L22 Bite, L26 Helping Hand, L34 Fury Swipes, L43 Flatter, L53 Crunch
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM32 Double Team, TM34 Shock Wave, TM36 Sludge Bomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Counter, Mimic
- **Egg:** —

## #031–060

### 031 Nidoqueen — Poison/Ground
- **Stats** HP 90 / Atk 82 / Def 87 / SpA 75 / SpD 85 / Spe 76 — **BST 495**
- **Evolves:** does not evolve
- **Level-up:** L1 Scratch, L1 Tail Whip, L1 Double Kick, L1 Poison Sting, L22 Body Slam, L43 Superpower
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM36 Sludge Bomb, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 032 Nidoran♂ — Poison
- **Stats** HP 46 / Atk 57 / Def 40 / SpA 40 / SpD 40 / Spe 50 — **BST 273**
- **Evolves:** → Nidorino at L16
- **Level-up:** L1 Leer, L1 Peck, L8 Focus Energy, L12 Double Kick, L17 Poison Sting, L20 Horn Attack, L23 Helping Hand, L30 Fury Attack, L38 Flatter, L47 Horn Drill
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM32 Double Team, TM34 Shock Wave, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Counter, Mimic
- **Egg:** Counter, Disable, Supersonic, Take Down, Amnesia, Confusion, Beat Up

### 033 Nidorino — Poison
- **Stats** HP 61 / Atk 72 / Def 57 / SpA 55 / SpD 55 / Spe 65 — **BST 365**
- **Evolves:** → Nidoking (use Moon Stone)
- **Level-up:** L1 Leer, L1 Peck, L8 Focus Energy, L12 Double Kick, L18 Poison Sting, L22 Horn Attack, L26 Helping Hand, L34 Fury Attack, L43 Flatter, L53 Horn Drill
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM32 Double Team, TM34 Shock Wave, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Counter, Mimic
- **Egg:** —

### 034 Nidoking — Poison/Ground
- **Stats** HP 81 / Atk 92 / Def 77 / SpA 85 / SpD 75 / Spe 85 — **BST 495**
- **Evolves:** does not evolve
- **Level-up:** L1 Peck, L1 Focus Energy, L1 Double Kick, L1 Poison Sting, L22 Thrash, L43 Megahorn
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM36 Sludge Bomb, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 035 Clefairy — Normal
- **Stats** HP 70 / Atk 45 / Def 48 / SpA 60 / SpD 65 / Spe 35 — **BST 323**
- **Evolves:** → Clefable (use Moon Stone)
- **Level-up:** L1 Pound, L1 Growl, L5 Encore, L9 Sing, L13 Double Slap, L17 Follow Me, L21 Minimize, L25 Defense Curl, L29 Metronome, L33 Cosmic Power, L37 Moonlight, L41 Light Screen, L45 Meteor Mash
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM49 Snatch, HM04 Strength, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Soft Boiled, Dream Eater, Thunder Wave
- **Egg:** —

### 036 Clefable — Normal
- **Stats** HP 95 / Atk 70 / Def 73 / SpA 85 / SpD 90 / Spe 60 — **BST 473**
- **Evolves:** does not evolve
- **Level-up:** L1 Sing, L1 Double Slap, L1 Minimize, L1 Metronome
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM49 Snatch, HM04 Strength, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Soft Boiled, Dream Eater, Thunder Wave
- **Egg:** —

### 037 Vulpix — Fire
- **Stats** HP 38 / Atk 41 / Def 40 / SpA 50 / SpD 65 / Spe 65 — **BST 299**
- **Evolves:** → Ninetales (use Fire Stone)
- **Level-up:** L1 Ember, L5 Tail Whip, L9 Roar, L13 Quick Attack, L17 Will O Wisp, L21 Confuse Ray, L25 Imprison, L29 Flamethrower, L33 Safeguard, L37 Grudge, L41 Fire Spin
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM50 Overheat
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** Faint Attack, Hypnosis, Flail, Spite, Disable, Howl, Psych Up, Heat Wave

### 038 Ninetales — Fire
- **Stats** HP 73 / Atk 76 / Def 75 / SpA 81 / SpD 100 / Spe 100 — **BST 505**
- **Evolves:** does not evolve
- **Level-up:** L1 Ember, L1 Quick Attack, L1 Confuse Ray, L1 Safeguard, L45 Fire Spin
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM50 Overheat
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** —

### 039 Jigglypuff — Normal
- **Stats** HP 115 / Atk 45 / Def 20 / SpA 45 / SpD 25 / Spe 20 — **BST 270**
- **Evolves:** → Wigglytuff (use Moon Stone)
- **Level-up:** L1 Sing, L4 Defense Curl, L9 Pound, L14 Disable, L19 Rollout, L24 Double Slap, L29 Rest, L34 Body Slam, L39 Mimic, L44 Hyper Voice, L49 Double Edge
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM49 Snatch, HM04 Strength, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Dream Eater, Thunder Wave
- **Egg:** —

### 040 Wigglytuff — Normal
- **Stats** HP 140 / Atk 70 / Def 45 / SpA 75 / SpD 50 / Spe 45 — **BST 425**
- **Evolves:** does not evolve
- **Level-up:** L1 Sing, L1 Disable, L1 Defense Curl, L1 Double Slap
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM49 Snatch, HM04 Strength, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Dream Eater, Thunder Wave
- **Egg:** —

### 041 Zubat — Poison/Flying
- **Stats** HP 40 / Atk 45 / Def 35 / SpA 30 / SpD 40 / Spe 55 — **BST 245**
- **Evolves:** → Golbat at L22
- **Level-up:** L1 Leech Life, L6 Astonish, L11 Supersonic, L16 Bite, L21 Wing Attack, L26 Confuse Ray, L31 Air Cutter, L36 Mean Look, L41 Poison Fang, L46 Haze
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM27 Return, TM30 Shadow Ball, TM32 Double Team, TM36 Sludge Bomb, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, TM49 Snatch
- **Tutor:** Double Edge, Mimic
- **Egg:** Quick Attack, Pursuit, Faint Attack, Gust, Whirlwind, Curse

### 042 Golbat — Poison/Flying
- **Stats** HP 75 / Atk 80 / Def 70 / SpA 65 / SpD 75 / Spe 90 — **BST 455**
- **Evolves:** → Crobat (high friendship)
- **Level-up:** L1 Screech, L1 Leech Life, L1 Astonish, L1 Supersonic, L6 Astonish, L11 Supersonic, L16 Bite, L21 Wing Attack, L28 Confuse Ray, L35 Air Cutter, L42 Mean Look, L49 Poison Fang, L56 Haze
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM27 Return, TM30 Shadow Ball, TM32 Double Team, TM36 Sludge Bomb, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, TM49 Snatch
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 043 Oddish — Grass/Poison
- **Stats** HP 45 / Atk 50 / Def 55 / SpA 75 / SpD 65 / Spe 30 — **BST 320**
- **Evolves:** → Gloom at L21
- **Level-up:** L1 Absorb, L7 Sweet Scent, L14 Poison Powder, L16 Stun Spore, L18 Sleep Powder, L23 Acid, L32 Moonlight, L39 Petal Dance
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM01 Cut, HM05 Flash
- **Tutor:** Swords Dance, Double Edge, Mimic
- **Egg:** Swords Dance, Razor Leaf, Flail, Synthesis, Charm, Ingrain

### 044 Gloom — Grass/Poison
- **Stats** HP 60 / Atk 65 / Def 70 / SpA 85 / SpD 75 / Spe 40 — **BST 395**
- **Evolves:** → Vileplume (use Leaf Stone) ; → Bellossom (use Sun Stone)
- **Level-up:** L1 Absorb, L1 Sweet Scent, L1 Poison Powder, L7 Sweet Scent, L14 Poison Powder, L16 Stun Spore, L18 Sleep Powder, L24 Acid, L35 Moonlight, L44 Petal Dance
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM01 Cut, HM05 Flash
- **Tutor:** Swords Dance, Double Edge, Mimic
- **Egg:** —

### 045 Vileplume — Grass/Poison
- **Stats** HP 75 / Atk 80 / Def 85 / SpA 100 / SpD 90 / Spe 50 — **BST 480**
- **Evolves:** does not evolve
- **Level-up:** L1 Absorb, L1 Aromatherapy, L1 Stun Spore, L1 Mega Drain, L44 Petal Dance
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM01 Cut, HM05 Flash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** —

### 046 Paras — Bug/Grass
- **Stats** HP 35 / Atk 70 / Def 55 / SpA 45 / SpD 55 / Spe 25 — **BST 285**
- **Evolves:** → Parasect at L24
- **Level-up:** L1 Scratch, L7 Stun Spore, L13 Poison Powder, L19 Leech Life, L25 Spore, L31 Slash, L37 Growth, L43 Giga Drain, L49 Aromatherapy
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM28 Dig, TM32 Double Team, TM36 Sludge Bomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM05 Flash, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Counter, Mimic
- **Egg:** False Swipe, Screech, Counter, Psybeam, Flail, Sweet Scent, Light Screen, Pursuit

### 047 Parasect — Bug/Grass
- **Stats** HP 60 / Atk 95 / Def 80 / SpA 60 / SpD 80 / Spe 30 — **BST 405**
- **Evolves:** does not evolve
- **Level-up:** L1 Scratch, L1 Stun Spore, L1 Poison Powder, L7 Stun Spore, L13 Poison Powder, L19 Leech Life, L27 Spore, L35 Slash, L43 Growth, L51 Giga Drain, L59 Aromatherapy
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM28 Dig, TM32 Double Team, TM36 Sludge Bomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM05 Flash, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Counter, Mimic
- **Egg:** —

### 048 Venonat — Bug/Poison
- **Stats** HP 60 / Atk 55 / Def 50 / SpA 40 / SpD 55 / Spe 45 — **BST 305**
- **Evolves:** → Venomoth at L31
- **Level-up:** L1 Tackle, L1 Disable, L1 Foresight, L9 Supersonic, L17 Confusion, L20 Poison Powder, L25 Leech Life, L28 Stun Spore, L33 Psybeam, L36 Sleep Powder, L41 Psychic
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM29 Psychic, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, HM05 Flash
- **Tutor:** Double Edge, Mimic
- **Egg:** Baton Pass, Screech, Giga Drain, Signal Beam

### 049 Venomoth — Bug/Poison
- **Stats** HP 70 / Atk 65 / Def 60 / SpA 90 / SpD 75 / Spe 90 — **BST 450**
- **Evolves:** does not evolve
- **Level-up:** L1 Silver Wind, L1 Tackle, L1 Disable, L1 Foresight, L1 Supersonic, L9 Supersonic, L17 Confusion, L20 Poison Powder, L25 Leech Life, L28 Stun Spore, L31 Gust, L36 Psybeam, L42 Sleep Powder, L52 Psychic
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM29 Psychic, TM32 Double Team, TM36 Sludge Bomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, HM05 Flash
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 050 Diglett — Ground
- **Stats** HP 10 / Atk 55 / Def 25 / SpA 35 / SpD 45 / Spe 95 — **BST 265**
- **Evolves:** → Dugtrio at L26
- **Level-up:** L1 Sand Attack, L1 Scratch, L5 Growl, L9 Magnitude, L17 Dig, L21 Fury Swipes, L25 Mud Slap, L33 Slash, L41 Earthquake, L49 Fissure
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM32 Double Team, TM36 Sludge Bomb, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Mimic, Rock Slide
- **Egg:** Faint Attack, Screech, Ancient Power, Pursuit, Beat Up, Uproar, Rock Slide

### 051 Dugtrio — Ground
- **Stats** HP 35 / Atk 80 / Def 50 / SpA 50 / SpD 70 / Spe 120 — **BST 405**
- **Evolves:** does not evolve
- **Level-up:** L1 Tri Attack, L1 Scratch, L1 Sand Attack, L1 Sand Attack, L1 Scratch, L1 Growl, L5 Growl, L9 Magnitude, L17 Dig, L21 Fury Swipes, L25 Mud Slap, L26 Sand Tomb, L38 Slash, L51 Earthquake, L64 Fissure
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM32 Double Team, TM36 Sludge Bomb, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Mimic, Rock Slide
- **Egg:** —

### 052 Meowth — Normal
- **Stats** HP 40 / Atk 45 / Def 35 / SpA 40 / SpD 40 / Spe 90 — **BST 290**
- **Evolves:** → Persian at L28
- **Level-up:** L1 Scratch, L1 Growl, L10 Bite, L18 Pay Day, L25 Faint Attack, L31 Screech, L36 Fury Swipes, L40 Slash, L43 Fake Out, L45 Swagger
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM32 Double Team, TM34 Shock Wave, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM49 Snatch, HM01 Cut, HM05 Flash
- **Tutor:** Body Slam, Double Edge, Mimic, Dream Eater
- **Egg:** Spite, Charm, Hypnosis, Amnesia, Psych Up, Assist

### 053 Persian — Normal
- **Stats** HP 65 / Atk 70 / Def 60 / SpA 65 / SpD 65 / Spe 115 — **BST 440**
- **Evolves:** does not evolve
- **Level-up:** L1 Scratch, L1 Growl, L1 Bite, L10 Bite, L18 Pay Day, L25 Faint Attack, L34 Screech, L42 Fury Swipes, L49 Slash, L55 Fake Out, L61 Swagger
- **TM/HM:** TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM32 Double Team, TM34 Shock Wave, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM49 Snatch, HM01 Cut, HM05 Flash
- **Tutor:** Body Slam, Double Edge, Mimic, Dream Eater
- **Egg:** —

### 054 Psyduck — Water
- **Stats** HP 50 / Atk 52 / Def 48 / SpA 65 / SpD 50 / Spe 55 — **BST 320**
- **Evolves:** → Golduck at L33
- **Level-up:** L1 Water Sport, L1 Scratch, L5 Tail Whip, L10 Disable, L16 Confusion, L23 Screech, L31 Psych Up, L40 Fury Swipes, L50 Hydro Pump
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength, HM05 Flash, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic
- **Egg:** Hypnosis, Psybeam, Foresight, Light Screen, Future Sight, Psychic, Cross Chop, Refresh

### 055 Golduck — Water
- **Stats** HP 80 / Atk 82 / Def 78 / SpA 95 / SpD 80 / Spe 85 — **BST 500**
- **Evolves:** does not evolve
- **Level-up:** L1 Water Sport, L1 Scratch, L1 Tail Whip, L1 Disable, L5 Tail Whip, L10 Disable, L16 Confusion, L23 Screech, L31 Psych Up, L44 Fury Swipes, L58 Hydro Pump
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength, HM05 Flash, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic
- **Egg:** —

### 056 Mankey — Fighting
- **Stats** HP 40 / Atk 80 / Def 35 / SpA 35 / SpD 45 / Spe 70 — **BST 305**
- **Evolves:** → Primeape at L28
- **Level-up:** L1 Scratch, L1 Leer, L6 Low Kick, L11 Karate Chop, L16 Fury Swipes, L21 Focus Energy, L26 Seismic Toss, L31 Cross Chop, L36 Swagger, L41 Screech, L46 Thrash
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM50 Overheat, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Rock Slide
- **Egg:** Rock Slide, Foresight, Meditate, Counter, Reversal, Beat Up, Revenge, Smelling Salt

### 057 Primeape — Fighting
- **Stats** HP 65 / Atk 105 / Def 60 / SpA 60 / SpD 70 / Spe 95 — **BST 455**
- **Evolves:** does not evolve
- **Level-up:** L1 Scratch, L1 Leer, L1 Low Kick, L1 Rage, L6 Low Kick, L11 Karate Chop, L16 Fury Swipes, L21 Focus Energy, L26 Seismic Toss, L28 Rage, L35 Cross Chop, L44 Swagger, L53 Screech, L62 Thrash
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM50 Overheat, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Rock Slide
- **Egg:** —

### 058 Growlithe — Fire
- **Stats** HP 55 / Atk 70 / Def 45 / SpA 70 / SpD 50 / Spe 60 — **BST 350**
- **Evolves:** → Arcanine (use Fire Stone)
- **Level-up:** L1 Bite, L1 Roar, L7 Ember, L13 Leer, L19 Odor Sleuth, L25 Take Down, L31 Flame Wheel, L37 Helping Hand, L43 Agility, L49 Flamethrower
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM50 Overheat, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** Body Slam, Safeguard, Crunch, Thrash, Fire Spin, Howl, Heat Wave

### 059 Arcanine — Fire
- **Stats** HP 90 / Atk 110 / Def 80 / SpA 100 / SpD 80 / Spe 95 — **BST 555**
- **Evolves:** does not evolve
- **Level-up:** L1 Bite, L1 Roar, L1 Ember, L1 Odor Sleuth, L49 Extreme Speed
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM50 Overheat, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** —

### 060 Poliwag — Water
- **Stats** HP 40 / Atk 50 / Def 40 / SpA 40 / SpD 40 / Spe 90 — **BST 300**
- **Evolves:** → Poliwhirl at L25
- **Level-up:** L1 Bubble, L7 Hypnosis, L13 Water Gun, L19 Double Slap, L25 Rain Dance, L31 Body Slam, L37 Belly Drum, L43 Hydro Pump
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM28 Dig, TM29 Psychic, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** Mist, Splash, Bubble Beam, Haze, Mind Reader, Water Sport, Ice Ball

## #061–090

### 061 Poliwhirl — Water
- **Stats** HP 65 / Atk 65 / Def 65 / SpA 50 / SpD 50 / Spe 90 — **BST 385**
- **Evolves:** → Poliwrath (use Water Stone) ; → Politoed (trade holding Kings Rock)
- **Level-up:** L1 Bubble, L1 Hypnosis, L1 Water Gun, L7 Hypnosis, L13 Water Gun, L19 Double Slap, L27 Rain Dance, L35 Body Slam, L43 Belly Drum, L51 Hydro Pump
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM29 Psychic, TM31 Brick Break, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome
- **Egg:** —

### 062 Poliwrath — Water/Fighting
- **Stats** HP 90 / Atk 85 / Def 95 / SpA 70 / SpD 90 / Spe 70 — **BST 500**
- **Evolves:** does not evolve
- **Level-up:** L1 Water Gun, L1 Hypnosis, L1 Double Slap, L1 Submission, L35 Submission, L51 Mind Reader
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM08 Bulk Up, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM29 Psychic, TM31 Brick Break, TM32 Double Team, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome
- **Egg:** —

### 063 Abra — Psychic
- **Stats** HP 25 / Atk 20 / Def 15 / SpA 105 / SpD 55 / Spe 90 — **BST 310**
- **Evolves:** → Kadabra at L16
- **Level-up:** L1 Teleport
- **TM/HM:** TM01 Focus Punch, TM04 Calm Mind, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater, Thunder Wave
- **Egg:** Encore, Barrier, Knock Off, Fire Punch, Thunder Punch, Ice Punch

### 064 Kadabra — Psychic
- **Stats** HP 40 / Atk 35 / Def 30 / SpA 120 / SpD 70 / Spe 105 — **BST 400**
- **Evolves:** → Alakazam (trade)
- **Level-up:** L1 Teleport, L1 Kinesis, L1 Confusion, L16 Confusion, L18 Disable, L21 Psybeam, L23 Reflect, L25 Recover, L30 Future Sight, L33 Role Play, L36 Psychic, L43 Trick
- **TM/HM:** TM01 Focus Punch, TM04 Calm Mind, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater, Thunder Wave
- **Egg:** —

### 065 Alakazam — Psychic
- **Stats** HP 55 / Atk 50 / Def 45 / SpA 135 / SpD 85 / Spe 120 — **BST 490**
- **Evolves:** does not evolve
- **Level-up:** L1 Teleport, L1 Kinesis, L1 Confusion, L16 Confusion, L18 Disable, L21 Psybeam, L23 Reflect, L25 Recover, L30 Future Sight, L33 Calm Mind, L36 Psychic, L43 Trick
- **TM/HM:** TM01 Focus Punch, TM04 Calm Mind, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater, Thunder Wave
- **Egg:** —

### 066 Machop — Fighting
- **Stats** HP 70 / Atk 80 / Def 50 / SpA 35 / SpD 35 / Spe 35 — **BST 305**
- **Evolves:** → Machoke at L28
- **Level-up:** L1 Low Kick, L1 Leer, L7 Focus Energy, L13 Karate Chop, L19 Seismic Toss, L22 Foresight, L25 Revenge, L31 Vital Throw, L37 Submission, L40 Cross Chop, L43 Scary Face, L49 Dynamic Punch
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Rock Slide
- **Egg:** Light Screen, Meditate, Rolling Kick, Encore, Smelling Salt, Counter, Rock Slide

### 067 Machoke — Fighting
- **Stats** HP 80 / Atk 100 / Def 70 / SpA 50 / SpD 60 / Spe 45 — **BST 405**
- **Evolves:** → Machamp (trade)
- **Level-up:** L1 Low Kick, L1 Leer, L1 Focus Energy, L7 Focus Energy, L13 Karate Chop, L19 Seismic Toss, L22 Foresight, L25 Revenge, L33 Vital Throw, L41 Submission, L46 Cross Chop, L51 Scary Face, L59 Dynamic Punch
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Rock Slide
- **Egg:** —

### 068 Machamp — Fighting
- **Stats** HP 90 / Atk 130 / Def 80 / SpA 65 / SpD 85 / Spe 55 — **BST 505**
- **Evolves:** does not evolve
- **Level-up:** L1 Low Kick, L1 Leer, L1 Focus Energy, L7 Focus Energy, L13 Karate Chop, L19 Seismic Toss, L22 Foresight, L25 Revenge, L33 Vital Throw, L41 Submission, L46 Cross Chop, L51 Scary Face, L59 Dynamic Punch
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Rock Slide
- **Egg:** —

### 069 Bellsprout — Grass/Poison
- **Stats** HP 50 / Atk 75 / Def 35 / SpA 70 / SpD 30 / Spe 40 — **BST 300**
- **Evolves:** → Weepinbell at L21
- **Level-up:** L1 Vine Whip, L6 Growth, L11 Wrap, L15 Sleep Powder, L17 Poison Powder, L19 Stun Spore, L23 Acid, L30 Sweet Scent, L37 Razor Leaf, L45 Slam
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM05 Flash
- **Tutor:** Swords Dance, Double Edge, Mimic
- **Egg:** Swords Dance, Encore, Reflect, Synthesis, Leech Life, Ingrain, Magical Leaf

### 070 Weepinbell — Grass/Poison
- **Stats** HP 65 / Atk 90 / Def 50 / SpA 85 / SpD 45 / Spe 55 — **BST 390**
- **Evolves:** → Victreebel (use Leaf Stone)
- **Level-up:** L1 Vine Whip, L1 Growth, L1 Wrap, L6 Growth, L11 Wrap, L15 Sleep Powder, L17 Poison Powder, L19 Stun Spore, L24 Acid, L33 Sweet Scent, L42 Razor Leaf, L54 Slam
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM05 Flash
- **Tutor:** Swords Dance, Double Edge, Mimic
- **Egg:** —

### 071 Victreebel — Grass/Poison
- **Stats** HP 80 / Atk 105 / Def 65 / SpA 100 / SpD 60 / Spe 70 — **BST 480**
- **Evolves:** does not evolve
- **Level-up:** L1 Stockpile, L1 Spit Up, L1 Swallow, L1 Vine Whip, L1 Sleep Powder, L1 Sweet Scent, L1 Razor Leaf
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM05 Flash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** —

### 072 Tentacool — Water/Poison
- **Stats** HP 40 / Atk 40 / Def 35 / SpA 50 / SpD 100 / Spe 70 — **BST 335**
- **Evolves:** → Tentacruel at L30
- **Level-up:** L1 Poison Sting, L6 Supersonic, L12 Constrict, L19 Acid, L25 Bubble Beam, L30 Wrap, L36 Barrier, L43 Screech, L49 Hydro Pump
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Swords Dance, Double Edge, Mimic
- **Egg:** Aurora Beam, Mirror Coat, Rapid Spin, Haze, Safeguard, Confuse Ray

### 073 Tentacruel — Water/Poison
- **Stats** HP 80 / Atk 70 / Def 65 / SpA 80 / SpD 120 / Spe 100 — **BST 515**
- **Evolves:** does not evolve
- **Level-up:** L1 Poison Sting, L1 Supersonic, L1 Constrict, L6 Supersonic, L12 Constrict, L19 Acid, L25 Bubble Beam, L30 Wrap, L38 Barrier, L47 Screech, L55 Hydro Pump
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Swords Dance, Double Edge, Mimic
- **Egg:** —

### 074 Geodude — Rock/Ground
- **Stats** HP 40 / Atk 80 / Def 100 / SpA 30 / SpD 30 / Spe 20 — **BST 300**
- **Evolves:** → Graveler at L25
- **Level-up:** L1 Tackle, L1 Defense Curl, L6 Mud Sport, L11 Rock Throw, L16 Magnitude, L21 Self Destruct, L26 Rollout, L31 Rock Blast, L36 Earthquake, L41 Explosion, L46 Double Edge
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Explosion, Rock Slide
- **Egg:** Mega Punch, Rock Slide, Block

### 075 Graveler — Rock/Ground
- **Stats** HP 55 / Atk 95 / Def 115 / SpA 45 / SpD 45 / Spe 35 — **BST 390**
- **Evolves:** → Golem (trade)
- **Level-up:** L1 Tackle, L1 Defense Curl, L1 Mud Sport, L1 Rock Throw, L6 Mud Sport, L11 Rock Throw, L16 Magnitude, L21 Self Destruct, L29 Rollout, L37 Rock Blast, L45 Earthquake, L53 Explosion, L62 Double Edge
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Explosion, Rock Slide
- **Egg:** —

### 076 Golem — Rock/Ground
- **Stats** HP 80 / Atk 110 / Def 130 / SpA 55 / SpD 65 / Spe 45 — **BST 485**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Defense Curl, L1 Mud Sport, L1 Rock Throw, L6 Mud Sport, L11 Rock Throw, L16 Magnitude, L21 Self Destruct, L29 Rollout, L37 Rock Blast, L45 Earthquake, L53 Explosion, L62 Double Edge
- **TM/HM:** TM01 Focus Punch, TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Explosion, Rock Slide
- **Egg:** —

### 077 Ponyta — Fire
- **Stats** HP 50 / Atk 85 / Def 55 / SpA 65 / SpD 65 / Spe 90 — **BST 410**
- **Evolves:** → Rapidash at L40
- **Level-up:** L1 Quick Attack, L5 Growl, L9 Tail Whip, L14 Ember, L19 Stomp, L25 Fire Spin, L31 Take Down, L38 Agility, L45 Bounce, L53 Fire Blast
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM27 Return, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM50 Overheat, HM04 Strength
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** Flame Wheel, Thrash, Double Kick, Hypnosis, Charm, Double Edge

### 078 Rapidash — Fire
- **Stats** HP 65 / Atk 100 / Def 70 / SpA 80 / SpD 80 / Spe 105 — **BST 500**
- **Evolves:** does not evolve
- **Level-up:** L1 Quick Attack, L1 Growl, L1 Tail Whip, L1 Ember, L5 Growl, L9 Tail Whip, L14 Ember, L19 Stomp, L25 Fire Spin, L31 Take Down, L38 Agility, L40 Fury Attack, L50 Bounce, L63 Fire Blast
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM27 Return, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM50 Overheat, HM04 Strength
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** —

### 079 Slowpoke — Water/Psychic
- **Stats** HP 90 / Atk 65 / Def 65 / SpA 40 / SpD 40 / Spe 15 — **BST 315**
- **Evolves:** → Slowbro at L37 ; → Slowking (trade holding Kings Rock)
- **Level-up:** L1 Curse, L1 Yawn, L1 Tackle, L6 Growl, L13 Water Gun, L17 Confusion, L24 Disable, L29 Headbutt, L36 Amnesia, L40 Psychic, L47 Psych Up
- **TM/HM:** TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM29 Psychic, TM30 Shadow Ball, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM48 Skill Swap, HM03 Surf, HM04 Strength, HM05 Flash, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic, Dream Eater, Thunder Wave
- **Egg:** Safeguard, Belly Drum, Future Sight, Stomp, Mud Sport, Sleep Talk, Snore

### 080 Slowbro — Water/Psychic
- **Stats** HP 95 / Atk 75 / Def 110 / SpA 100 / SpD 80 / Spe 30 — **BST 490**
- **Evolves:** does not evolve
- **Level-up:** L1 Curse, L1 Yawn, L1 Tackle, L1 Growl, L6 Growl, L13 Water Gun, L17 Confusion, L24 Disable, L29 Headbutt, L36 Amnesia, L37 Withdraw, L44 Psychic, L55 Psych Up
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM48 Skill Swap, HM03 Surf, HM04 Strength, HM05 Flash, HM06 Rock Smash, HM08 Dive
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Dream Eater, Thunder Wave
- **Egg:** —

### 081 Magnemite — Electric/Steel
- **Stats** HP 25 / Atk 35 / Def 70 / SpA 95 / SpD 55 / Spe 45 — **BST 325**
- **Evolves:** → Magneton at L30
- **Level-up:** L1 Metal Sound, L1 Tackle, L6 Thunder Shock, L11 Supersonic, L16 Sonic Boom, L21 Thunder Wave, L26 Spark, L32 Lock On, L38 Swift, L44 Screech, L50 Zap Cannon
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, HM05 Flash
- **Tutor:** Double Edge, Mimic, Thunder Wave
- **Egg:** —

### 082 Magneton — Electric/Steel
- **Stats** HP 50 / Atk 60 / Def 95 / SpA 120 / SpD 70 / Spe 70 — **BST 465**
- **Evolves:** does not evolve
- **Level-up:** L1 Metal Sound, L1 Tackle, L1 Thunder Shock, L1 Supersonic, L6 Thunder Shock, L11 Supersonic, L16 Sonic Boom, L21 Thunder Wave, L26 Spark, L35 Lock On, L44 Tri Attack, L53 Screech, L62 Zap Cannon
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, HM05 Flash
- **Tutor:** Double Edge, Mimic, Thunder Wave
- **Egg:** —

### 083 Farfetch'd — Normal/Flying
- **Stats** HP 52 / Atk 65 / Def 55 / SpA 58 / SpD 62 / Spe 60 — **BST 352**
- **Evolves:** does not evolve
- **Level-up:** L1 Peck, L6 Sand Attack, L11 Leer, L16 Fury Attack, L21 Knock Off, L26 Fury Cutter, L31 Swords Dance, L36 Agility, L41 Slash, L46 False Swipe
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM01 Cut, HM02 Fly
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** Steel Wing, Foresight, Mirror Move, Gust, Quick Attack, Flail, Feather Dance, Curse

### 084 Doduo — Normal/Flying
- **Stats** HP 35 / Atk 85 / Def 45 / SpA 35 / SpD 35 / Spe 75 — **BST 310**
- **Evolves:** → Dodrio at L31
- **Level-up:** L1 Peck, L1 Growl, L9 Pursuit, L13 Fury Attack, L21 Tri Attack, L25 Rage, L33 Uproar, L37 Drill Peck, L45 Agility
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM21 Frustration, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM02 Fly
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** Quick Attack, Supersonic, Haze, Faint Attack, Flail, Endeavor

### 085 Dodrio — Normal/Flying
- **Stats** HP 60 / Atk 110 / Def 70 / SpA 60 / SpD 60 / Spe 100 — **BST 460**
- **Evolves:** does not evolve
- **Level-up:** L1 Peck, L1 Growl, L1 Pursuit, L1 Fury Attack, L9 Pursuit, L13 Fury Attack, L21 Tri Attack, L25 Rage, L38 Uproar, L47 Drill Peck, L60 Agility
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM02 Fly
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** —

### 086 Seel — Water
- **Stats** HP 65 / Atk 45 / Def 55 / SpA 45 / SpD 70 / Spe 45 — **BST 325**
- **Evolves:** → Dewgong at L34
- **Level-up:** L1 Headbutt, L9 Growl, L17 Icy Wind, L21 Aurora Beam, L29 Rest, L37 Take Down, L41 Ice Beam, L49 Safeguard
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM27 Return, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** Lick, Perish Song, Disable, Horn Drill, Slam, Encore, Fake Out, Icicle Spear

### 087 Dewgong — Water/Ice
- **Stats** HP 90 / Atk 70 / Def 80 / SpA 70 / SpD 95 / Spe 70 — **BST 475**
- **Evolves:** does not evolve
- **Level-up:** L1 Signal Beam, L1 Headbutt, L1 Growl, L1 Icy Wind, L1 Aurora Beam, L9 Growl, L17 Icy Wind, L21 Aurora Beam, L29 Rest, L34 Sheer Cold, L42 Take Down, L51 Ice Beam, L64 Safeguard
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM27 Return, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** —

### 088 Grimer — Poison
- **Stats** HP 80 / Atk 80 / Def 50 / SpA 40 / SpD 50 / Spe 25 — **BST 325**
- **Evolves:** → Muk at L38
- **Level-up:** L1 Poison Gas, L1 Pound, L4 Harden, L8 Disable, L13 Sludge, L19 Minimize, L26 Screech, L34 Acid Armor, L43 Sludge Bomb, L53 Memento
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM36 Sludge Bomb, TM38 Fire Blast, TM39 Rock Tomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief
- **Tutor:** Body Slam, Mimic, Explosion
- **Egg:** Haze, Mean Look, Lick, Imprison, Curse, Shadow Punch, Explosion

### 089 Muk — Poison
- **Stats** HP 105 / Atk 105 / Def 75 / SpA 65 / SpD 100 / Spe 50 — **BST 500**
- **Evolves:** does not evolve
- **Level-up:** L1 Poison Gas, L1 Pound, L1 Harden, L4 Harden, L8 Disable, L13 Sludge, L19 Minimize, L26 Screech, L34 Acid Armor, L47 Sludge Bomb, L61 Memento
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM36 Sludge Bomb, TM38 Fire Blast, TM39 Rock Tomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Mimic, Explosion
- **Egg:** —

### 090 Shellder — Water
- **Stats** HP 30 / Atk 65 / Def 100 / SpA 45 / SpD 25 / Spe 40 — **BST 305**
- **Evolves:** → Cloyster (use Water Stone)
- **Level-up:** L1 Tackle, L1 Withdraw, L8 Icicle Spear, L15 Supersonic, L22 Aurora Beam, L29 Protect, L36 Leer, L43 Clamp, L50 Ice Beam
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM08 Dive
- **Tutor:** Double Edge, Mimic, Explosion
- **Egg:** Bubble Beam, Take Down, Barrier, Rapid Spin, Screech, Icicle Spear

## #091–120

### 091 Cloyster — Water/Ice
- **Stats** HP 50 / Atk 95 / Def 180 / SpA 85 / SpD 45 / Spe 70 — **BST 525**
- **Evolves:** does not evolve
- **Level-up:** L1 Withdraw, L1 Supersonic, L1 Aurora Beam, L1 Protect, L36 Spikes, L43 Spike Cannon
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM08 Dive
- **Tutor:** Double Edge, Mimic, Explosion
- **Egg:** —

### 092 Gastly — Ghost/Poison
- **Stats** HP 30 / Atk 35 / Def 30 / SpA 100 / SpD 35 / Spe 80 — **BST 310**
- **Evolves:** → Haunter at L25
- **Level-up:** L1 Hypnosis, L1 Lick, L8 Spite, L13 Curse, L16 Night Shade, L21 Confuse Ray, L28 Dream Eater, L33 Destiny Bond, L36 Shadow Ball, L41 Nightmare, L48 Mean Look
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM24 Thunderbolt, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM32 Double Team, TM36 Sludge Bomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch
- **Tutor:** Mimic, Dream Eater, Explosion
- **Egg:** Psywave, Perish Song, Haze, Astonish, Will O Wisp, Grudge, Explosion

### 093 Haunter — Ghost/Poison
- **Stats** HP 45 / Atk 50 / Def 45 / SpA 115 / SpD 55 / Spe 95 — **BST 405**
- **Evolves:** → Gengar (trade)
- **Level-up:** L1 Hypnosis, L1 Lick, L1 Spite, L8 Spite, L13 Curse, L16 Night Shade, L21 Confuse Ray, L25 Shadow Punch, L31 Dream Eater, L39 Destiny Bond, L45 Shadow Ball, L53 Nightmare, L64 Mean Look
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM24 Thunderbolt, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM32 Double Team, TM36 Sludge Bomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch
- **Tutor:** Mimic, Dream Eater, Explosion
- **Egg:** —

### 094 Gengar — Ghost/Poison
- **Stats** HP 60 / Atk 65 / Def 60 / SpA 130 / SpD 75 / Spe 110 — **BST 500**
- **Evolves:** does not evolve
- **Level-up:** L1 Hypnosis, L1 Lick, L1 Spite, L8 Spite, L13 Curse, L16 Night Shade, L21 Confuse Ray, L25 Shadow Punch, L31 Dream Eater, L39 Destiny Bond, L45 Shadow Ball, L53 Nightmare, L64 Mean Look
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM36 Sludge Bomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater, Explosion
- **Egg:** —

### 095 Onix — Rock/Ground
- **Stats** HP 35 / Atk 45 / Def 160 / SpA 30 / SpD 45 / Spe 70 — **BST 385**
- **Evolves:** → Steelix (trade holding Metal Coat)
- **Level-up:** L1 Tackle, L1 Screech, L8 Bind, L12 Rock Throw, L19 Harden, L23 Rage, L30 Dragon Breath, L34 Sandstorm, L41 Slam, L45 Iron Tail, L52 Sand Tomb, L56 Double Edge
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM32 Double Team, TM37 Sandstorm, TM39 Rock Tomb, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Mimic, Explosion, Rock Slide
- **Egg:** Rock Slide, Flail, Explosion, Block

### 096 Drowzee — Psychic
- **Stats** HP 60 / Atk 48 / Def 45 / SpA 43 / SpD 90 / Spe 42 — **BST 328**
- **Evolves:** → Hypno at L26
- **Level-up:** L1 Pound, L1 Hypnosis, L7 Disable, L11 Confusion, L17 Headbutt, L21 Poison Gas, L27 Meditate, L31 Psychic, L37 Psych Up, L41 Swagger, L47 Future Sight
- **TM/HM:** TM01 Focus Punch, TM04 Calm Mind, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater, Thunder Wave
- **Egg:** Barrier, Assist, Role Play, Fire Punch, Thunder Punch, Ice Punch

### 097 Hypno — Psychic
- **Stats** HP 85 / Atk 73 / Def 70 / SpA 73 / SpD 115 / Spe 67 — **BST 483**
- **Evolves:** does not evolve
- **Level-up:** L1 Nightmare, L1 Pound, L1 Hypnosis, L1 Disable, L1 Confusion, L7 Disable, L11 Confusion, L17 Headbutt, L21 Poison Gas, L29 Meditate, L35 Psychic, L43 Psych Up, L49 Swagger, L57 Future Sight
- **TM/HM:** TM01 Focus Punch, TM04 Calm Mind, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater, Thunder Wave
- **Egg:** —

### 098 Krabby — Water
- **Stats** HP 30 / Atk 105 / Def 90 / SpA 25 / SpD 25 / Spe 50 — **BST 325**
- **Evolves:** → Kingler at L28
- **Level-up:** L1 Bubble, L5 Leer, L12 Vice Grip, L16 Harden, L23 Mud Shot, L27 Stomp, L34 Guillotine, L38 Protect, L45 Crabhammer, L49 Flail
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM28 Dig, TM32 Double Team, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM08 Dive
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** Dig, Haze, Amnesia, Flail, Slam, Knock Off, Swords Dance

### 099 Kingler — Water
- **Stats** HP 55 / Atk 130 / Def 115 / SpA 50 / SpD 50 / Spe 75 — **BST 475**
- **Evolves:** does not evolve
- **Level-up:** L1 Metal Claw, L1 Bubble, L1 Leer, L1 Vice Grip, L1 Harden, L5 Leer, L12 Vice Grip, L16 Harden, L23 Mud Shot, L27 Stomp, L38 Guillotine, L42 Protect, L57 Crabhammer, L65 Flail
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM28 Dig, TM32 Double Team, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM08 Dive
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** —

### 100 Voltorb — Electric
- **Stats** HP 40 / Atk 30 / Def 50 / SpA 55 / SpD 55 / Spe 100 — **BST 330**
- **Evolves:** → Electrode at L30
- **Level-up:** L1 Charge, L1 Tackle, L8 Screech, L15 Sonic Boom, L21 Spark, L27 Self Destruct, L32 Rollout, L37 Light Screen, L42 Swift, L46 Explosion, L49 Mirror Coat
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM12 Taunt, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM32 Double Team, TM34 Shock Wave, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM46 Thief, HM05 Flash
- **Tutor:** Mimic, Thunder Wave, Explosion
- **Egg:** —

### 101 Electrode — Electric
- **Stats** HP 60 / Atk 50 / Def 70 / SpA 80 / SpD 80 / Spe 140 — **BST 480**
- **Evolves:** does not evolve
- **Level-up:** L1 Charge, L1 Tackle, L1 Screech, L1 Sonic Boom, L8 Screech, L15 Sonic Boom, L21 Spark, L27 Self Destruct, L34 Rollout, L41 Light Screen, L48 Swift, L54 Explosion, L59 Mirror Coat
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM12 Taunt, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM32 Double Team, TM34 Shock Wave, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM46 Thief, HM05 Flash
- **Tutor:** Mimic, Thunder Wave, Explosion
- **Egg:** —

### 102 Exeggcute — Grass/Psychic
- **Stats** HP 60 / Atk 40 / Def 80 / SpA 60 / SpD 45 / Spe 40 — **BST 325**
- **Evolves:** → Exeggutor (use Leaf Stone)
- **Level-up:** L1 Barrage, L1 Uproar, L1 Hypnosis, L7 Reflect, L13 Leech Seed, L19 Confusion, L25 Stun Spore, L31 Poison Powder, L37 Sleep Powder, L43 Solar Beam
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM16 Light Screen, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM29 Psychic, TM32 Double Team, TM33 Reflect, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, HM04 Strength, HM05 Flash
- **Tutor:** Double Edge, Mimic, Dream Eater, Explosion
- **Egg:** Synthesis, Moonlight, Reflect, Ancient Power, Psych Up, Ingrain, Curse

### 103 Exeggutor — Grass/Psychic
- **Stats** HP 95 / Atk 95 / Def 85 / SpA 125 / SpD 65 / Spe 55 — **BST 520**
- **Evolves:** does not evolve
- **Level-up:** L1 Barrage, L1 Hypnosis, L1 Confusion, L19 Stomp, L31 Egg Bomb
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM29 Psychic, TM32 Double Team, TM33 Reflect, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, HM04 Strength, HM05 Flash
- **Tutor:** Double Edge, Mimic, Dream Eater, Explosion
- **Egg:** —

### 104 Cubone — Ground
- **Stats** HP 50 / Atk 50 / Def 95 / SpA 40 / SpD 50 / Spe 35 — **BST 320**
- **Evolves:** → Marowak at L28
- **Level-up:** L1 Growl, L5 Tail Whip, L9 Bone Club, L13 Headbutt, L17 Leer, L21 Focus Energy, L25 Bonemerang, L29 Rage, L33 False Swipe, L37 Thrash, L41 Bone Rush, L45 Double Edge
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Swords Dance, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** Rock Slide, Ancient Power, Belly Drum, Screech, Skull Bash, Perish Song, Swords Dance

### 105 Marowak — Ground
- **Stats** HP 60 / Atk 80 / Def 110 / SpA 50 / SpD 80 / Spe 45 — **BST 425**
- **Evolves:** does not evolve
- **Level-up:** L1 Growl, L1 Tail Whip, L1 Bone Club, L1 Headbutt, L5 Tail Whip, L9 Bone Club, L13 Headbutt, L17 Leer, L21 Focus Energy, L25 Bonemerang, L32 Rage, L39 False Swipe, L46 Thrash, L53 Bone Rush, L61 Double Edge
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Swords Dance, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 106 Hitmonlee — Fighting
- **Stats** HP 50 / Atk 120 / Def 53 / SpA 35 / SpD 110 / Spe 87 — **BST 455**
- **Evolves:** does not evolve
- **Level-up:** L1 Revenge, L1 Double Kick, L6 Meditate, L11 Rolling Kick, L16 Jump Kick, L20 Brick Break, L21 Focus Energy, L26 Hi Jump Kick, L31 Mind Reader, L36 Foresight, L41 Endure, L46 Mega Kick, L51 Reversal
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM26 Earthquake, TM27 Return, TM31 Brick Break, TM32 Double Team, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Rock Slide
- **Egg:** —

### 107 Hitmonchan — Fighting
- **Stats** HP 50 / Atk 105 / Def 79 / SpA 35 / SpD 110 / Spe 76 — **BST 455**
- **Evolves:** does not evolve
- **Level-up:** L1 Revenge, L1 Comet Punch, L7 Agility, L13 Pursuit, L20 Mach Punch, L26 Thunder Punch, L26 Ice Punch, L26 Fire Punch, L32 Sky Uppercut, L38 Mega Punch, L44 Detect, L50 Counter
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM26 Earthquake, TM27 Return, TM31 Brick Break, TM32 Double Team, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Rock Slide
- **Egg:** —

### 108 Lickitung — Normal
- **Stats** HP 90 / Atk 55 / Def 75 / SpA 60 / SpD 75 / Spe 30 — **BST 385**
- **Evolves:** does not evolve
- **Level-up:** L1 Lick, L7 Supersonic, L12 Defense Curl, L18 Knock Off, L23 Stomp, L29 Wrap, L34 Disable, L40 Slam, L45 Screech, L51 Refresh
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Swords Dance, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Dream Eater, Rock Slide
- **Egg:** Belly Drum, Magnitude, Body Slam, Curse, Smelling Salt, Sleep Talk, Snore, Substitute

### 109 Koffing — Poison
- **Stats** HP 40 / Atk 65 / Def 95 / SpA 60 / SpD 45 / Spe 35 — **BST 340**
- **Evolves:** → Weezing at L35
- **Level-up:** L1 Poison Gas, L1 Tackle, L9 Smog, L17 Self Destruct, L21 Sludge, L25 Smokescreen, L33 Haze, L41 Explosion, L45 Destiny Bond, L49 Memento
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM30 Shadow Ball, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM36 Sludge Bomb, TM38 Fire Blast, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM05 Flash
- **Tutor:** Mimic, Explosion
- **Egg:** Screech, Psywave, Psybeam, Destiny Bond, Pain Split, Will O Wisp

### 110 Weezing — Poison
- **Stats** HP 65 / Atk 90 / Def 120 / SpA 85 / SpD 70 / Spe 60 — **BST 490**
- **Evolves:** does not evolve
- **Level-up:** L1 Poison Gas, L1 Tackle, L1 Smog, L1 Self Destruct, L9 Smog, L17 Self Destruct, L21 Sludge, L25 Smokescreen, L33 Haze, L44 Explosion, L51 Destiny Bond, L58 Memento
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM30 Shadow Ball, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM36 Sludge Bomb, TM38 Fire Blast, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM05 Flash
- **Tutor:** Mimic, Explosion
- **Egg:** —

### 111 Rhyhorn — Ground/Rock
- **Stats** HP 80 / Atk 85 / Def 95 / SpA 30 / SpD 30 / Spe 25 — **BST 345**
- **Evolves:** → Rhydon at L42
- **Level-up:** L1 Horn Attack, L1 Tail Whip, L10 Stomp, L15 Fury Attack, L24 Scary Face, L29 Rock Blast, L38 Horn Drill, L43 Take Down, L52 Earthquake, L57 Megahorn
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Counter, Mimic, Rock Slide
- **Egg:** Crunch, Reversal, Rock Slide, Counter, Magnitude, Swords Dance, Curse, Crush Claw

### 112 Rhydon — Ground/Rock
- **Stats** HP 105 / Atk 130 / Def 120 / SpA 45 / SpD 45 / Spe 40 — **BST 485**
- **Evolves:** does not evolve
- **Level-up:** L1 Horn Attack, L1 Tail Whip, L1 Stomp, L1 Fury Attack, L10 Stomp, L15 Fury Attack, L24 Scary Face, L29 Rock Blast, L38 Horn Drill, L46 Take Down, L58 Earthquake, L66 Megahorn
- **TM/HM:** TM01 Focus Punch, TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Swords Dance, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 113 Chansey — Normal
- **Stats** HP 250 / Atk 5 / Def 5 / SpA 35 / SpD 105 / Spe 50 — **BST 450**
- **Evolves:** → Blissey (high friendship)
- **Level-up:** L1 Pound, L1 Growl, L5 Tail Whip, L9 Refresh, L13 Soft Boiled, L17 Double Slap, L23 Minimize, L29 Sing, L35 Egg Bomb, L41 Defense Curl, L49 Light Screen, L57 Double Edge
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM48 Skill Swap, TM49 Snatch, HM04 Strength, HM05 Flash, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Soft Boiled, Dream Eater, Thunder Wave
- **Egg:** Present, Metronome, Heal Bell, Aromatherapy, Substitute

### 114 Tangela — Grass
- **Stats** HP 65 / Atk 55 / Def 115 / SpA 100 / SpD 40 / Spe 60 — **BST 435**
- **Evolves:** does not evolve
- **Level-up:** L1 Ingrain, L1 Constrict, L4 Sleep Powder, L10 Absorb, L13 Growth, L19 Poison Powder, L22 Vine Whip, L28 Bind, L31 Mega Drain, L37 Stun Spore, L40 Slam, L46 Tickle
- **TM/HM:** TM06 Toxic, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM19 Giga Drain, TM21 Frustration, TM22 Solar Beam, TM27 Return, TM32 Double Team, TM36 Sludge Bomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM05 Flash, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Mimic
- **Egg:** Flail, Confusion, Mega Drain, Reflect, Amnesia, Leech Seed, Nature Power

### 115 Kangaskhan — Normal
- **Stats** HP 105 / Atk 95 / Def 80 / SpA 40 / SpD 80 / Spe 90 — **BST 490**
- **Evolves:** does not evolve
- **Level-up:** L1 Comet Punch, L1 Leer, L7 Bite, L13 Tail Whip, L19 Fake Out, L25 Mega Punch, L31 Rage, L37 Endure, L43 Dizzy Punch, L49 Reversal
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Rock Slide
- **Egg:** Stomp, Foresight, Focus Energy, Safeguard, Disable, Counter, Crush Claw, Substitute

### 116 Horsea — Water
- **Stats** HP 30 / Atk 40 / Def 70 / SpA 70 / SpD 25 / Spe 60 — **BST 295**
- **Evolves:** → Seadra at L32
- **Level-up:** L1 Bubble, L8 Smokescreen, L15 Leer, L22 Water Gun, L29 Twister, L36 Agility, L43 Hydro Pump, L50 Dragon Dance
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Double Edge, Mimic
- **Egg:** Flail, Aurora Beam, Octazooka, Disable, Splash, Dragon Rage, Dragon Breath

### 117 Seadra — Water
- **Stats** HP 55 / Atk 65 / Def 95 / SpA 95 / SpD 45 / Spe 85 — **BST 440**
- **Evolves:** → Kingdra (trade holding Dragon Scale)
- **Level-up:** L1 Bubble, L1 Smokescreen, L1 Leer, L1 Water Gun, L8 Smokescreen, L15 Leer, L22 Water Gun, L29 Twister, L40 Agility, L51 Hydro Pump, L62 Dragon Dance
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 118 Goldeen — Water
- **Stats** HP 45 / Atk 67 / Def 60 / SpA 35 / SpD 50 / Spe 63 — **BST 320**
- **Evolves:** → Seaking at L33
- **Level-up:** L1 Peck, L1 Tail Whip, L1 Water Sport, L10 Supersonic, L15 Horn Attack, L24 Flail, L29 Fury Attack, L38 Waterfall, L43 Horn Drill, L52 Agility, L57 Megahorn
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Double Edge, Mimic
- **Egg:** Psybeam, Haze, Hydro Pump, Sleep Talk, Mud Sport

### 119 Seaking — Water
- **Stats** HP 80 / Atk 92 / Def 65 / SpA 65 / SpD 80 / Spe 68 — **BST 450**
- **Evolves:** does not evolve
- **Level-up:** L1 Peck, L1 Tail Whip, L1 Water Sport, L1 Supersonic, L10 Supersonic, L15 Horn Attack, L24 Flail, L29 Fury Attack, L41 Waterfall, L49 Horn Drill, L61 Agility, L69 Megahorn
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 120 Staryu — Water
- **Stats** HP 30 / Atk 45 / Def 55 / SpA 70 / SpD 55 / Spe 85 — **BST 340**
- **Evolves:** → Starmie (use Water Stone)
- **Level-up:** L1 Tackle, L1 Harden, L6 Water Gun, L10 Rapid Spin, L15 Recover, L19 Camouflage, L24 Swift, L28 Bubble Beam, L33 Minimize, L37 Light Screen, L42 Cosmic Power, L46 Hydro Pump
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM29 Psychic, TM32 Double Team, TM33 Reflect, TM42 Facade, TM43 Secret Power, TM44 Rest, HM03 Surf, HM05 Flash, HM07 Waterfall, HM08 Dive
- **Tutor:** Double Edge, Mimic, Thunder Wave
- **Egg:** —

## #121–151

### 121 Starmie — Water/Psychic
- **Stats** HP 60 / Atk 75 / Def 85 / SpA 100 / SpD 85 / Spe 115 — **BST 520**
- **Evolves:** does not evolve
- **Level-up:** L1 Water Gun, L1 Rapid Spin, L1 Recover, L1 Swift, L33 Confuse Ray
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM29 Psychic, TM32 Double Team, TM33 Reflect, TM42 Facade, TM43 Secret Power, TM44 Rest, TM48 Skill Swap, HM03 Surf, HM05 Flash, HM07 Waterfall, HM08 Dive
- **Tutor:** Double Edge, Mimic, Dream Eater, Thunder Wave
- **Egg:** —

### 122 Mr. Mime — Psychic
- **Stats** HP 40 / Atk 45 / Def 65 / SpA 100 / SpD 120 / Spe 90 — **BST 460**
- **Evolves:** does not evolve
- **Level-up:** L1 Barrier, L5 Confusion, L8 Substitute, L12 Meditate, L15 Double Slap, L19 Light Screen, L19 Reflect, L22 Magical Leaf, L26 Encore, L29 Psybeam, L33 Recycle, L36 Trick, L40 Role Play, L43 Psychic, L47 Baton Pass, L50 Safeguard
- **TM/HM:** TM01 Focus Punch, TM04 Calm Mind, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, TM49 Snatch, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater, Thunder Wave
- **Egg:** Future Sight, Hypnosis, Mimic, Psych Up, Fake Out, Trick

### 123 Scyther — Bug/Flying
- **Stats** HP 70 / Atk 110 / Def 80 / SpA 55 / SpD 80 / Spe 105 — **BST 500**
- **Evolves:** → Scizor (trade holding Metal Coat)
- **Level-up:** L1 Quick Attack, L1 Leer, L6 Focus Energy, L11 Pursuit, L16 False Swipe, L21 Agility, L26 Wing Attack, L31 Slash, L36 Swords Dance, L41 Double Team, L46 Fury Cutter
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM01 Cut, HM06 Rock Smash
- **Tutor:** Swords Dance, Double Edge, Counter, Mimic
- **Egg:** Counter, Safeguard, Baton Pass, Razor Wind, Reversal, Light Screen, Endure, Silver Wind

### 124 Jynx — Ice/Psychic
- **Stats** HP 65 / Atk 50 / Def 35 / SpA 115 / SpD 95 / Spe 95 — **BST 455**
- **Evolves:** does not evolve
- **Level-up:** L1 Pound, L1 Lick, L1 Lovely Kiss, L1 Powder Snow, L9 Lovely Kiss, L13 Powder Snow, L21 Double Slap, L25 Ice Punch, L35 Mean Look, L41 Fake Tears, L51 Body Slam, L57 Perish Song, L67 Blizzard
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM12 Taunt, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM48 Skill Swap, HM05 Flash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater
- **Egg:** —

### 125 Electabuzz — Electric
- **Stats** HP 65 / Atk 83 / Def 57 / SpA 95 / SpD 85 / Spe 105 — **BST 490**
- **Evolves:** does not evolve
- **Level-up:** L1 Quick Attack, L1 Leer, L1 Thunder Punch, L9 Thunder Punch, L17 Light Screen, L25 Swift, L36 Screech, L47 Thunderbolt, L58 Thunder
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM29 Psychic, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM05 Flash, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Thunder Wave
- **Egg:** —

### 126 Magmar — Fire
- **Stats** HP 65 / Atk 95 / Def 57 / SpA 100 / SpD 85 / Spe 93 — **BST 495**
- **Evolves:** does not evolve
- **Level-up:** L1 Ember, L1 Leer, L1 Smog, L1 Fire Punch, L7 Leer, L13 Smog, L19 Fire Punch, L25 Smokescreen, L33 Sunny Day, L41 Flamethrower, L49 Confuse Ray, L57 Fire Blast
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM29 Psychic, TM31 Brick Break, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM04 Strength, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic
- **Egg:** —

### 127 Pinsir — Bug
- **Stats** HP 65 / Atk 125 / Def 100 / SpA 55 / SpD 70 / Spe 85 — **BST 500**
- **Evolves:** does not evolve
- **Level-up:** L1 Vice Grip, L1 Focus Energy, L7 Bind, L13 Seismic Toss, L19 Harden, L25 Revenge, L31 Brick Break, L37 Guillotine, L43 Submission, L49 Swords Dance
- **TM/HM:** TM01 Focus Punch, TM06 Toxic, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM26 Earthquake, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM04 Strength, HM06 Rock Smash
- **Tutor:** Swords Dance, Body Slam, Double Edge, Seismic Toss, Mimic, Rock Slide
- **Egg:** Fury Attack, Flail, False Swipe, Faint Attack

### 128 Tauros — Normal
- **Stats** HP 75 / Atk 100 / Def 95 / SpA 40 / SpD 70 / Spe 110 — **BST 490**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Tail Whip, L4 Rage, L8 Horn Attack, L13 Scary Face, L19 Pursuit, L26 Swagger, L34 Rest, L43 Thrash, L53 Take Down
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength, HM06 Rock Smash
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** —

### 129 Magikarp — Water
- **Stats** HP 20 / Atk 10 / Def 55 / SpA 15 / SpD 20 / Spe 80 — **BST 200**
- **Evolves:** → Gyarados at L20
- **Level-up:** L1 Splash, L15 Tackle, L30 Flail
- **TM/HM:** —
- **Tutor:** —
- **Egg:** —

### 130 Gyarados — Water/Flying
- **Stats** HP 95 / Atk 125 / Def 79 / SpA 60 / SpD 100 / Spe 81 — **BST 540**
- **Evolves:** does not evolve
- **Level-up:** L1 Thrash, L20 Bite, L25 Dragon Rage, L30 Leer, L35 Twister, L40 Hydro Pump, L45 Rain Dance, L50 Dragon Dance, L55 Hyper Beam
- **TM/HM:** TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM12 Taunt, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM32 Double Team, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic, Thunder Wave
- **Egg:** —

### 131 Lapras — Water/Ice
- **Stats** HP 130 / Atk 85 / Def 80 / SpA 85 / SpD 95 / Spe 60 — **BST 535**
- **Evolves:** does not evolve
- **Level-up:** L1 Water Gun, L1 Growl, L1 Sing, L7 Mist, L13 Body Slam, L19 Confuse Ray, L25 Perish Song, L31 Ice Beam, L37 Rain Dance, L43 Safeguard, L49 Hydro Pump, L55 Sheer Cold
- **TM/HM:** TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM29 Psychic, TM32 Double Team, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic, Dream Eater
- **Egg:** Foresight, Substitute, Tickle, Refresh, Dragon Dance, Curse, Sleep Talk, Horn Drill

### 132 Ditto — Normal
- **Stats** HP 48 / Atk 48 / Def 48 / SpA 48 / SpD 48 / Spe 48 — **BST 288**
- **Evolves:** does not evolve
- **Level-up:** L1 Transform
- **TM/HM:** —
- **Tutor:** —
- **Egg:** —

### 133 Eevee — Normal
- **Stats** HP 55 / Atk 55 / Def 50 / SpA 45 / SpD 65 / Spe 55 — **BST 325**
- **Evolves:** → Jolteon (use Thunder Stone) ; → Vaporeon (use Water Stone) ; → Flareon (use Fire Stone) ; → Espeon (high friendship (day)) ; → Umbreon (high friendship (night))
- **Level-up:** L1 Tackle, L1 Tail Whip, L1 Helping Hand, L8 Sand Attack, L16 Growl, L23 Quick Attack, L30 Bite, L36 Baton Pass, L42 Take Down
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** Charm, Flail, Endure, Curse, Tickle, Wish

### 134 Vaporeon — Water
- **Stats** HP 130 / Atk 65 / Def 60 / SpA 110 / SpD 95 / Spe 65 — **BST 525**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Tail Whip, L1 Helping Hand, L8 Sand Attack, L16 Water Gun, L23 Quick Attack, L30 Bite, L36 Aurora Beam, L42 Haze, L47 Acid Armor, L52 Hydro Pump
- **TM/HM:** TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM32 Double Team, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** —

### 135 Jolteon — Electric
- **Stats** HP 65 / Atk 65 / Def 60 / SpA 110 / SpD 95 / Spe 130 — **BST 525**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Tail Whip, L1 Helping Hand, L8 Sand Attack, L16 Thunder Shock, L23 Quick Attack, L30 Double Kick, L36 Pin Missile, L42 Thunder Wave, L47 Agility, L52 Thunder
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM32 Double Team, TM34 Shock Wave, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM05 Flash
- **Tutor:** Body Slam, Double Edge, Mimic, Thunder Wave
- **Egg:** —

### 136 Flareon — Fire
- **Stats** HP 65 / Atk 130 / Def 60 / SpA 95 / SpD 110 / Spe 65 — **BST 525**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L1 Tail Whip, L1 Helping Hand, L8 Sand Attack, L16 Ember, L23 Quick Attack, L30 Bite, L36 Fire Spin, L42 Smog, L47 Leer, L52 Flamethrower
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM27 Return, TM28 Dig, TM30 Shadow Ball, TM32 Double Team, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM50 Overheat
- **Tutor:** Body Slam, Double Edge, Mimic
- **Egg:** —

### 137 Porygon — Normal
- **Stats** HP 65 / Atk 60 / Def 70 / SpA 85 / SpD 75 / Spe 40 — **BST 395**
- **Evolves:** → Porygon2 (trade holding Up Grade)
- **Level-up:** L1 Conversion 2, L1 Tackle, L1 Conversion, L9 Agility, L12 Psybeam, L20 Recover, L24 Sharpen, L32 Lock On, L36 Tri Attack, L44 Recycle, L48 Zap Cannon
- **TM/HM:** TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM32 Double Team, TM34 Shock Wave, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM46 Thief, HM05 Flash
- **Tutor:** Double Edge, Mimic, Dream Eater, Thunder Wave
- **Egg:** —

### 138 Omanyte — Rock/Water
- **Stats** HP 35 / Atk 40 / Def 100 / SpA 90 / SpD 55 / Spe 35 — **BST 355**
- **Evolves:** → Omastar at L40
- **Level-up:** L1 Constrict, L1 Withdraw, L13 Bite, L19 Water Gun, L25 Mud Shot, L31 Leer, L37 Protect, L43 Tickle, L49 Ancient Power, L55 Hydro Pump
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM37 Sandstorm, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM03 Surf, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic, Rock Slide
- **Egg:** Bubble Beam, Aurora Beam, Slam, Supersonic, Haze, Rock Slide, Spikes

### 139 Omastar — Rock/Water
- **Stats** HP 70 / Atk 60 / Def 125 / SpA 115 / SpD 70 / Spe 55 — **BST 495**
- **Evolves:** does not evolve
- **Level-up:** L1 Constrict, L1 Withdraw, L1 Bite, L1 Water Gun, L13 Bite, L19 Water Gun, L25 Mud Shot, L31 Leer, L37 Protect, L40 Spike Cannon, L46 Tickle, L55 Ancient Power, L65 Hydro Pump
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM37 Sandstorm, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM03 Surf, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 140 Kabuto — Rock/Water
- **Stats** HP 30 / Atk 80 / Def 90 / SpA 55 / SpD 45 / Spe 55 — **BST 355**
- **Evolves:** → Kabutops at L40
- **Level-up:** L1 Scratch, L1 Harden, L13 Absorb, L19 Leer, L25 Mud Shot, L31 Sand Attack, L37 Endure, L43 Metal Sound, L49 Mega Drain, L55 Ancient Power
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM27 Return, TM28 Dig, TM32 Double Team, TM37 Sandstorm, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM03 Surf, HM06 Rock Smash, HM07 Waterfall
- **Tutor:** Body Slam, Double Edge, Mimic, Rock Slide
- **Egg:** Bubble Beam, Aurora Beam, Rapid Spin, Dig, Flail, Knock Off, Confuse Ray

### 141 Kabutops — Rock/Water
- **Stats** HP 60 / Atk 115 / Def 105 / SpA 65 / SpD 70 / Spe 80 — **BST 495**
- **Evolves:** does not evolve
- **Level-up:** L1 Fury Cutter, L1 Scratch, L1 Harden, L1 Absorb, L1 Leer, L13 Absorb, L19 Leer, L25 Mud Shot, L31 Sand Attack, L37 Endure, L40 Slash, L46 Metal Sound, L55 Mega Drain, L65 Ancient Power
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM21 Frustration, TM27 Return, TM28 Dig, TM31 Brick Break, TM32 Double Team, TM37 Sandstorm, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, HM01 Cut, HM03 Surf, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Swords Dance, Mega Kick, Body Slam, Double Edge, Seismic Toss, Mimic, Rock Slide
- **Egg:** —

### 142 Aerodactyl — Rock/Flying
- **Stats** HP 80 / Atk 105 / Def 65 / SpA 60 / SpD 75 / Spe 130 — **BST 515**
- **Evolves:** does not evolve
- **Level-up:** L1 Wing Attack, L8 Agility, L15 Bite, L22 Supersonic, L29 Ancient Power, L36 Scary Face, L43 Take Down, L50 Hyper Beam
- **TM/HM:** TM02 Dragon Claw, TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM23 Iron Tail, TM26 Earthquake, TM27 Return, TM32 Double Team, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, HM02 Fly, HM04 Strength, HM06 Rock Smash
- **Tutor:** Double Edge, Mimic, Rock Slide
- **Egg:** Whirlwind, Pursuit, Foresight, Steel Wing, Dragon Breath, Curse

### 143 Snorlax — Normal
- **Stats** HP 160 / Atk 110 / Def 65 / SpA 65 / SpD 110 / Spe 30 — **BST 540**
- **Evolves:** does not evolve
- **Level-up:** L1 Tackle, L5 Amnesia, L9 Defense Curl, L13 Belly Drum, L17 Headbutt, L21 Yawn, L25 Rest, L29 Snore, L33 Body Slam, L37 Sleep Talk, L41 Block, L45 Covet, L49 Rollout, L53 Hyper Beam
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM22 Solar Beam, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM04 Strength
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Rock Slide
- **Egg:** Lick, Charm, Double Edge, Curse, Fissure, Substitute

### 144 Articuno — Ice/Flying
- **Stats** HP 90 / Atk 85 / Def 100 / SpA 95 / SpD 125 / Spe 85 — **BST 580**
- **Evolves:** does not evolve
- **Level-up:** L1 Gust, L1 Powder Snow, L13 Mist, L25 Agility, L37 Mind Reader, L49 Ice Beam, L61 Reflect, L73 Blizzard, L85 Sheer Cold
- **TM/HM:** TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM27 Return, TM32 Double Team, TM33 Reflect, TM37 Sandstorm, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM47 Steel Wing, HM02 Fly, HM06 Rock Smash
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 145 Zapdos — Electric/Flying
- **Stats** HP 90 / Atk 90 / Def 85 / SpA 125 / SpD 90 / Spe 100 — **BST 580**
- **Evolves:** does not evolve
- **Level-up:** L1 Peck, L1 Thunder Shock, L13 Thunder Wave, L25 Agility, L37 Detect, L49 Drill Peck, L61 Charge, L73 Light Screen, L85 Thunder
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM21 Frustration, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM32 Double Team, TM34 Shock Wave, TM37 Sandstorm, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM47 Steel Wing, HM02 Fly, HM05 Flash, HM06 Rock Smash
- **Tutor:** Double Edge, Mimic, Thunder Wave
- **Egg:** —

### 146 Moltres — Fire/Flying
- **Stats** HP 90 / Atk 100 / Def 90 / SpA 125 / SpD 85 / Spe 90 — **BST 580**
- **Evolves:** does not evolve
- **Level-up:** L1 Wing Attack, L1 Ember, L13 Fire Spin, L25 Agility, L37 Endure, L49 Flamethrower, L61 Safeguard, L73 Heat Wave, L85 Sky Attack
- **TM/HM:** TM05 Roar, TM06 Toxic, TM10 Hidden Power, TM11 Sunny Day, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM27 Return, TM32 Double Team, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM47 Steel Wing, TM50 Overheat, HM02 Fly, HM06 Rock Smash
- **Tutor:** Double Edge, Mimic
- **Egg:** —

### 147 Dratini — Dragon
- **Stats** HP 41 / Atk 64 / Def 45 / SpA 50 / SpD 50 / Spe 50 — **BST 300**
- **Evolves:** → Dragonair at L30
- **Level-up:** L1 Wrap, L1 Leer, L8 Thunder Wave, L15 Twister, L22 Dragon Rage, L29 Slam, L36 Agility, L43 Safeguard, L50 Outrage, L57 Hyper Beam
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM07 Waterfall
- **Tutor:** Body Slam, Double Edge, Mimic, Thunder Wave
- **Egg:** Light Screen, Mist, Haze, Supersonic, Dragon Breath, Dragon Dance

### 148 Dragonair — Dragon
- **Stats** HP 61 / Atk 84 / Def 65 / SpA 70 / SpD 70 / Spe 70 — **BST 420**
- **Evolves:** → Dragonite at L55
- **Level-up:** L1 Wrap, L1 Leer, L1 Thunder Wave, L1 Twister, L8 Thunder Wave, L15 Twister, L22 Dragon Rage, L29 Slam, L38 Agility, L47 Safeguard, L56 Outrage, L65 Hyper Beam
- **TM/HM:** TM03 Water Pulse, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM27 Return, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM38 Fire Blast, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, HM03 Surf, HM07 Waterfall
- **Tutor:** Body Slam, Double Edge, Mimic, Thunder Wave
- **Egg:** —

### 149 Dragonite — Dragon/Flying
- **Stats** HP 91 / Atk 134 / Def 95 / SpA 100 / SpD 100 / Spe 80 — **BST 600**
- **Evolves:** does not evolve
- **Level-up:** L1 Wrap, L1 Leer, L1 Thunder Wave, L1 Twister, L8 Thunder Wave, L15 Twister, L22 Dragon Rage, L29 Slam, L38 Agility, L47 Safeguard, L55 Wing Attack, L61 Outrage, L75 Hyper Beam
- **TM/HM:** TM01 Focus Punch, TM02 Dragon Claw, TM03 Water Pulse, TM05 Roar, TM06 Toxic, TM07 Hail, TM10 Hidden Power, TM11 Sunny Day, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM31 Brick Break, TM32 Double Team, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM40 Aerial Ace, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM47 Steel Wing, HM01 Cut, HM02 Fly, HM03 Surf, HM04 Strength, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Body Slam, Double Edge, Mimic, Thunder Wave
- **Egg:** —

### 150 Mewtwo — Psychic
- **Stats** HP 106 / Atk 110 / Def 90 / SpA 154 / SpD 90 / Spe 130 — **BST 680**
- **Evolves:** does not evolve
- **Level-up:** L1 Confusion, L1 Disable, L11 Barrier, L22 Mist, L33 Swift, L44 Recover, L55 Safeguard, L66 Psychic, L77 Psych Up, L88 Future Sight, L99 Amnesia
- **TM/HM:** TM01 Focus Punch, TM03 Water Pulse, TM04 Calm Mind, TM06 Toxic, TM07 Hail, TM08 Bulk Up, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM35 Flamethrower, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM48 Skill Swap, TM49 Snatch, HM04 Strength, HM05 Flash, HM06 Rock Smash
- **Tutor:** Mega Punch, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Dream Eater, Thunder Wave
- **Egg:** —

### 151 Mew — Psychic
- **Stats** HP 100 / Atk 100 / Def 100 / SpA 100 / SpD 100 / Spe 100 — **BST 600**
- **Evolves:** does not evolve
- **Level-up:** L1 Pound, L10 Transform, L20 Mega Punch, L30 Metronome, L40 Psychic, L50 Ancient Power
- **TM/HM:** TM01 Focus Punch, TM02 Dragon Claw, TM03 Water Pulse, TM04 Calm Mind, TM05 Roar, TM06 Toxic, TM07 Hail, TM08 Bulk Up, TM09 Bullet Seed, TM10 Hidden Power, TM11 Sunny Day, TM12 Taunt, TM13 Ice Beam, TM14 Blizzard, TM15 Hyper Beam, TM16 Light Screen, TM17 Protect, TM18 Rain Dance, TM19 Giga Drain, TM20 Safeguard, TM21 Frustration, TM22 Solar Beam, TM23 Iron Tail, TM24 Thunderbolt, TM25 Thunder, TM26 Earthquake, TM27 Return, TM28 Dig, TM29 Psychic, TM30 Shadow Ball, TM31 Brick Break, TM32 Double Team, TM33 Reflect, TM34 Shock Wave, TM35 Flamethrower, TM36 Sludge Bomb, TM37 Sandstorm, TM38 Fire Blast, TM39 Rock Tomb, TM40 Aerial Ace, TM41 Torment, TM42 Facade, TM43 Secret Power, TM44 Rest, TM45 Attract, TM46 Thief, TM47 Steel Wing, TM48 Skill Swap, TM49 Snatch, TM50 Overheat, HM01 Cut, HM02 Fly, HM03 Surf, HM04 Strength, HM05 Flash, HM06 Rock Smash, HM07 Waterfall, HM08 Dive
- **Tutor:** Mega Punch, Swords Dance, Mega Kick, Body Slam, Double Edge, Counter, Seismic Toss, Mimic, Metronome, Soft Boiled, Dream Eater, Thunder Wave, Explosion, Rock Slide
- **Egg:** —
