# 🔥 Pokémon FireRed — Progress Hub

My playthrough log. Goals: **beat every Gym (+ Elite Four)** and build a **full Living Dex** — own all 151 at once (every evolution stage held simultaneously, not just registered).

> [!info] Trackers
> - [[00 - Index & Basics]] — **Complete Walkthrough** (per-area files: maps, connections, wild tables, items, trainers, gyms & Elite Four)
> - [[Pokedex Reference]] — every line's types, stats, evolutions, moves (look-ahead reference)
> - [[Pokedex Tracker]] — all 151, with how to get each one
> - [[Team & Boxes]] — individual Pokémon: level, moves, items
> - [[Progress Checklist]] — tick off every walkthrough objective + the 8 badges
>
> **Appendices:** [[A1 - Missables]] ⚠️ · [[A2 - Evolution Item Budget]] 💎 · [[A3 - Trades & Exclusives]] 🔄 · [[A4 - Hidden Items]] 🔍

## 📊 Status at a glance

| Goal                        | Progress    |
| --------------------------- | ----------- |
| 📍 Location                 | Pewter City → Route 3 (Brock beaten) |
| Badges                      | 1 / 8 (Boulder) |
| Elite Four + Champion       | Not started |
| Living Dex (currently held) | 11 / 151     |

*Live party/boxes + exact location live in [[Team & Boxes]]. The Living-Dex number = the count of checked `- [x]` boxes in [[Pokedex Tracker]] (currently **11 / 151**). Re-count from the Tracker whenever it changes so this stays honest.*

## 🎯 The "full 151" plan

**Setup:** FireRed Rev 0 on Delta (iOS). Solo — no trade partner or second cartridge, so trades will be handled by **editing the save data** to inject the untradeable species.

Everything on FireRed can be caught/evolved normally. The save-edit pass covers the gaps (see the **can't-do-solo checklist** in [[Pokedex Tracker]]):
- **13 LeafGreen exclusives** — inject each species.
- **4 trade evolutions** — Alakazam, Machamp, Golem, Gengar (either inject, or set the traded flag and evolve).
- **The alternate picks** — the 2 starters, the fossil, and the Hitmon you didn't keep.
- **Mew** — event-only in a real cartridge, so inject it too.

With save editing, **all 151 are reachable.**

## 🗺️ Team & next steps

Your live party and boxes (levels, moves, items) live in one place: **[[Team & Boxes]]** — that's the single source of truth, so it never drifts from this hub.

**Next up:** Eg. head for Pewter City → Brock (Rock). Squirtle's Water moves handle the gym; a Mankey (Low Kick / Fighting) is also strong vs Rock.
