# 🎒 Team & Boxes

Back to [[Pokemon FireRed]] · Individual Pokémon: level, moves, item. Keep this current so guidance stays accurate.

> 📍 **Current location:** Pewter City → Route 3 *(Brock beaten · 1 badge — Boulder)*
> 🕓 *Last synced: 2026-09-23*

> [!note] ⭐ Update ONLY this file
> This is the **one place to edit** as you play — add a row when you catch, change the species when you evolve, delete when you release. The **Pokédex Tracker (×N), Progress Checklist boxes, and Hub count are all generated from these tables**, so you never touch those by hand. Tell me (or re-run the sync) after changes and they refresh. Move data cross-checked with [[Pokedex Reference]].

## 👥 Current Party (max 6)

| Slot | Species   | Nick | Lv  | Move 1        | Move 2    | Move 3       | Move 4       | Held item |
| ---- | --------- | ---- | --- | ------------- | --------- | ------------ | ------------ | --------- |
| 1    | Pikachu   | —    | 12  | Thunder Shock | Growl     | Quick Attack | Thunder Wave | —         |
| 2    | Spearow   | —    | 19  | Peck          | Growl     | Leer         | Fury Attack  | —         |
| 3    | Wartortle | —    | 18  | Tackle        | Tail Whip | Water Gun    | Withdraw     | —         |
| 4    | Mankey    | —    | 4   | Scratch       | Leer      | —            | —            | —         |
| 5    | *(empty)* |      |     |               |           |              |              |           |
| 6    | *(empty)* |      |     |               |           |              |              |           |

## 📦 Box 1 (benched & Living-Dex spares)

| #   | Species    | Nick | Lv  | Move 1        | Move 2      | Move 3 | Move 4 | Held item |
| --- | ---------- | ---- | --- | ------------- | ----------- | ------ | ------ | --------- |
| 1   | Mankey     | —    | 4   | Scratch       | Leer        | —      | —      | —         |
| 2   | Weedle     | —    | 4   | Poison Sting  | String Shot | —      | —      | —         |
| 3   | Spearow    | —    | 3   | Peck          | Growl       | —      | —      | —         |
| 4   | Weedle     | —    | 4   | Poison Sting  | String Shot | —      | —      | —         |
| 5   | Pidgey     | —    | 5   | Tackle        | Sand-Attack | —      | —      | —         |
| 6   | Pidgey     | —    | 2   | Tackle        | —           | —      | —      | —         |
| 7   | Pidgey     | —    | 4   | Tackle        | —           | —      | —      | —         |
| 8   | Rattata    | —    | 3   | Tackle        | Tail Whip   | —      | —      | —         |
| 9   | Rattata    | —    | 4   | Tackle        | Tail Whip   | —      | —      | —         |
| 10  | Weedle     | —    | 3   | Poison Sting  | String Shot | —      | —      | —         |
| 11  | Caterpie   | —    | 5   | Tackle        | String Shot | —      | —      | —         |
| 12  | Caterpie   | —    | 4   | Tackle        | String Shot | —      | —      | —         |
| 13  | Nidoran♂   | —    | 6   | Leer          | Peck        | —      | —      | —         |
| 14  | Pikachu    | —    | 3   | Thunder Shock | Growl       | —      | —      | —         |
| 15  | Caterpie   | —    | 5   | Tackle        | String Shot | —      | —      | —         |
| 16  | Nidoran♂   | —    | 6   | Leer          | Peck        | —      | —      | —         |
| 17  | Nidoran♂   | —    | 6   | Leer          | Peck        | —      | —      | —         |
| 18  | Jigglypuff |      | 3   |               |             |        |        |           |
| 19  | Nidoran♀   |      | 6   |               |             |        |        |           |
| 20  | Jigglypuff |      | 5   |               |             |        |        |           |

## 📝 Notes
- FOR CLAUDE: When I catch new pokemon, assume it goes into my team, unless team is full, then put it in the Box, each of which can only hold 30 pokemon at a time.
- **This file is the single source of truth for what you own.** Living-Dex counts, the Pokédex Tracker, and the Progress Checklist are all **auto-derived from these tables** — just add/remove/evolve rows here (or tell me) and everything else updates. Live count is on the [[Pokemon FireRed|Hub]].
- **Brock plan:** lead **Mankey** (Low Kick / Scratch — Fighting is strong vs his Rock/Ground) or **Wartortle** (Water Gun). Grind Mankey a few levels first; at L4 it's fragile. Pikachu's Electric does nothing to Onix/Geodude (Ground).
