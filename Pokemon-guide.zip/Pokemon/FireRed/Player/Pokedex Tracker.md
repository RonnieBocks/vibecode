# 📕 Pokédex Tracker — All 151

Back to [[Pokemon FireRed]] · **Goal = Living Dex:** hold one of every species (all evolution stages) at once.

> [!abstract] 🔄 Auto-generated — don't hand-edit
> The checkboxes and `×N` counts here are **derived from [[Team & Boxes]]** (your actual roster). Add/evolve rows there and this refreshes on the next sync — evolving your only copy automatically unchecks the earlier stage. `×N` = how many you currently hold; no `×N` = not held. The "how to get" text on each line is the reference part.

> [!tip] Legend
> 🔄 = **can't get on FireRed alone** (trade required) · ⭐ = event-only
> *Wild* = catch it · *Evolve* = raise/stone an owned one · *Trade-evo* = evolves only by trading · *FR-excl* = FireRed exclusive · *LG-excl* = trade from LeafGreen · *Gift/Fossil/Trade* = one-off
> **Details:** stones → [[A2 - Evolution Item Budget]] · LG-exclusives, trade-evos & in-game trades → [[A3 - Trades & Exclusives]] · statics/gifts/fossils/one-time picks → [[A1 - Missables]]

## #001–030
- [ ] 001 Bulbasaur — *Starter* (pick 1 of 3; else 🔄 trade)
- [ ] 002 Ivysaur — *Evolve* (Bulbasaur L16)
- [ ] 003 Venusaur — *Evolve* (Ivysaur L32)
- [ ] 004 Charmander — *Starter* (pick 1 of 3; else 🔄 trade)
- [ ] 005 Charmeleon — *Evolve*
- [ ] 006 Charizard — *Evolve*
- [ ] 007 Squirtle — *Starter*
- [x] 008 Wartortle — *Evolve* (my starter line) `×1`
- [ ] 009 Blastoise — *Evolve*
- [x] 010 Caterpie — *Wild* (Viridian Forest) `×3`
- [ ] 011 Metapod — *Wild / Evolve*
- [ ] 012 Butterfree — *Evolve*
- [x] 013 Weedle — *Wild* `×3`
- [ ] 014 Kakuna — *Wild / Evolve*
- [ ] 015 Beedrill — *Evolve*
- [x] 016 Pidgey — *Wild* `×3`
- [ ] 017 Pidgeotto — *Wild / Evolve*
- [ ] 018 Pidgeot — *Evolve*
- [x] 019 Rattata — *Wild* `×2`
- [ ] 020 Raticate — *Wild / Evolve*
- [x] 021 Spearow — *Wild* `×2`
- [ ] 022 Fearow — *Evolve*
- [ ] 023 Ekans — *Wild* · **FR-excl**
- [ ] 024 Arbok — *Evolve* · **FR-excl**
- [x] 025 Pikachu — *Wild* (Viridian Forest, Power Plant) `×2`
- [ ] 026 Raichu — *Evolve* (Thunder Stone)
- [ ] 027 Sandshrew — 🔄 **LG-excl** (trade)
- [ ] 028 Sandslash — 🔄 **LG-excl**
- [x] 029 Nidoran♀ — *Wild* `×1`
- [ ] 030 Nidorina — *Evolve*

## #031–060
- [ ] 031 Nidoqueen — *Evolve* (Moon Stone)
- [x] 032 Nidoran♂ — *Wild* `×3`
- [ ] 033 Nidorino — *Evolve*
- [ ] 034 Nidoking — *Evolve* (Moon Stone)
- [ ] 035 Clefairy — *Wild* (Mt. Moon)
- [ ] 036 Clefable — *Evolve* (Moon Stone)
- [ ] 037 Vulpix — 🔄 **LG-excl** (trade)
- [ ] 038 Ninetales — 🔄 **LG-excl**
- [x] 039 Jigglypuff — *Wild* `×2`
- [ ] 040 Wigglytuff — *Evolve* (Moon Stone)
- [ ] 041 Zubat — *Wild*
- [ ] 042 Golbat — *Wild / Evolve*
- [ ] 043 Oddish — *Wild* · **FR-excl**
- [ ] 044 Gloom — *Evolve* · **FR-excl**
- [ ] 045 Vileplume — *Evolve* (Leaf Stone) · **FR-excl**
- [ ] 046 Paras — *Wild*
- [ ] 047 Parasect — *Wild / Evolve*
- [ ] 048 Venonat — *Wild*
- [ ] 049 Venomoth — *Evolve*
- [ ] 050 Diglett — *Wild* (Diglett's Cave)
- [ ] 051 Dugtrio — *Wild / Evolve*
- [ ] 052 Meowth — *Wild*
- [ ] 053 Persian — *Evolve*
- [ ] 054 Psyduck — *Wild* · **FR-excl**
- [ ] 055 Golduck — *Evolve* · **FR-excl**
- [x] 056 Mankey — *Wild* `×2`
- [ ] 057 Primeape — *Evolve*
- [ ] 058 Growlithe — *Wild* · **FR-excl**
- [ ] 059 Arcanine — *Evolve* (Fire Stone) · **FR-excl**
- [ ] 060 Poliwag — *Wild* (fishing)

## #061–090
- [ ] 061 Poliwhirl — *Wild / Evolve*
- [ ] 062 Poliwrath — *Evolve* (Water Stone)
- [ ] 063 Abra — *Wild*
- [ ] 064 Kadabra — *Evolve*
- [ ] 065 Alakazam — 🔄 *Trade-evo*
- [ ] 066 Machop — *Wild*
- [ ] 067 Machoke — *Wild / Evolve*
- [ ] 068 Machamp — 🔄 *Trade-evo*
- [ ] 069 Bellsprout — 🔄 **LG-excl** (trade)
- [ ] 070 Weepinbell — 🔄 **LG-excl**
- [ ] 071 Victreebel — 🔄 **LG-excl**
- [ ] 072 Tentacool — *Wild* (Surf/fishing)
- [ ] 073 Tentacruel — *Wild / Evolve*
- [ ] 074 Geodude — *Wild*
- [ ] 075 Graveler — *Wild / Evolve*
- [ ] 076 Golem — 🔄 *Trade-evo*
- [ ] 077 Ponyta — *Wild*
- [ ] 078 Rapidash — *Evolve*
- [ ] 079 Slowpoke — 🔄 **LG-excl** (trade)
- [ ] 080 Slowbro — 🔄 **LG-excl**
- [ ] 081 Magnemite — *Wild* (Power Plant)
- [ ] 082 Magneton — *Evolve*
- [ ] 083 Farfetch'd — *In-game trade* (Vermilion: Spearow → Farfetch'd)
- [ ] 084 Doduo — *Wild*
- [ ] 085 Dodrio — *Wild / Evolve*
- [ ] 086 Seel — *Wild* (Seafoam Islands)
- [ ] 087 Dewgong — *Evolve*
- [ ] 088 Grimer — *Wild* (Pokémon Mansion / Power Plant)
- [ ] 089 Muk — *Wild / Evolve*
- [ ] 090 Shellder — *Wild* (fishing) · **FR-excl**

## #091–120
- [ ] 091 Cloyster — *Evolve* (Water Stone) · **FR-excl**
- [ ] 092 Gastly — *Wild* (Pokémon Tower)
- [ ] 093 Haunter — *Wild / Evolve*
- [ ] 094 Gengar — 🔄 *Trade-evo*
- [ ] 095 Onix — *Wild*
- [ ] 096 Drowzee — *Wild*
- [ ] 097 Hypno — *Evolve*
- [ ] 098 Krabby — *Wild* (fishing)
- [ ] 099 Kingler — *Evolve*
- [ ] 100 Voltorb — *Wild*
- [ ] 101 Electrode — *Wild / Evolve*
- [ ] 102 Exeggcute — *Wild*
- [ ] 103 Exeggutor — *Evolve* (Leaf Stone)
- [ ] 104 Cubone — *Wild* (Pokémon Tower)
- [ ] 105 Marowak — *Evolve*
- [ ] 106 Hitmonlee — *Gift* (Fighting Dojo, pick 1; else 🔄 trade)
- [ ] 107 Hitmonchan — *Gift* (Fighting Dojo, pick 1; else 🔄 trade)
- [ ] 108 Lickitung — *In-game trade* (Route 18: Golduck → Lickitung)
- [ ] 109 Koffing — *Wild* (Pokémon Mansion)
- [ ] 110 Weezing — *Evolve*
- [ ] 111 Rhyhorn — *Wild* (Safari Zone)
- [ ] 112 Rhydon — *Evolve*
- [ ] 113 Chansey — *Wild* (Safari Zone, rare)
- [ ] 114 Tangela — *Wild*
- [ ] 115 Kangaskhan — *Wild* (Safari Zone)
- [ ] 116 Horsea — *Wild* (fishing)
- [ ] 117 Seadra — *Evolve*
- [ ] 118 Goldeen — *Wild* (fishing)
- [ ] 119 Seaking — *Evolve*
- [ ] 120 Staryu — 🔄 **LG-excl** (trade)

## #121–151
- [ ] 121 Starmie — 🔄 **LG-excl**
- [ ] 122 Mr. Mime — *In-game trade* (Route 2: Abra → Mr. Mime)
- [ ] 123 Scyther — *Wild* (Safari Zone) · **FR-excl**
- [ ] 124 Jynx — *In-game trade* (Cerulean: Poliwhirl → Jynx)
- [ ] 125 Electabuzz — *Wild* (Power Plant) · **FR-excl**
- [ ] 126 Magmar — 🔄 **LG-excl** (trade)
- [ ] 127 Pinsir — 🔄 **LG-excl** (trade)
- [ ] 128 Tauros — *Wild* (Safari Zone)
- [ ] 129 Magikarp — *Wild* (fishing / salesman in Route 4 Center)
- [ ] 130 Gyarados — *Evolve*
- [ ] 131 Lapras — *Gift* (Silph Co.)
- [ ] 132 Ditto — *Wild*
- [ ] 133 Eevee — *Gift* (Celadon Condominiums)
- [ ] 134 Vaporeon — *Evolve* (Water Stone)
- [ ] 135 Jolteon — *Evolve* (Thunder Stone)
- [ ] 136 Flareon — *Evolve* (Fire Stone)
- [ ] 137 Porygon — *Game Corner prize* (Celadon)
- [ ] 138 Omanyte — *Fossil* ✋ **Helix obtained — revive at Cinnabar Lab**
- [ ] 139 Omastar — *Evolve*
- [ ] 140 Kabuto — 🔄 *Fossil* (Dome not chosen — **save-edit**)
- [ ] 141 Kabutops — *Evolve*
- [ ] 142 Aerodactyl — *Fossil* (Old Amber, Pewter Museum)
- [ ] 143 Snorlax — *Wild* (static — 2 on Routes 12 & 16)
- [ ] 144 Articuno — *Legendary* (Seafoam Islands)
- [ ] 145 Zapdos — *Legendary* (Power Plant)
- [ ] 146 Moltres — *Legendary* (Mt. Ember, Sevii) · **FR**
- [ ] 147 Dratini — *Wild* (Safari Zone fishing)
- [ ] 148 Dragonair — *Evolve*
- [ ] 149 Dragonite — *Evolve*
- [ ] 150 Mewtwo — *Legendary* (Cerulean Cave, post-game)
- [ ] 151 Mew — ⭐ *Event only*

---

## 🔄 The "can't-do-solo" checklist

Everything below needs a trade partner or event — full details & data in [[A3 - Trades & Exclusives]] (and [[A1 - Missables]] for the one-time picks). Knock these out and the rest is just catching:

**Trade evolutions (trade any partner, then trade back):** Alakazam · Machamp · Golem · Gengar → [[A3 - Trades & Exclusives]]

**LeafGreen exclusives (13):** Sandshrew · Sandslash · Vulpix · Ninetales · Bellsprout · Weepinbell · Victreebel · Slowpoke · Slowbro · Staryu · Starmie · Magmar · Pinsir → [[A3 - Trades & Exclusives]]

**One-or-the-other picks (trade for the alternates — see [[A1 - Missables]]):**
- Starter — you keep 1 of Bulbasaur / Charmander / Squirtle
- Fossil — you keep 1 of Omanyte / Kabuto
- Hitmon — you keep 1 of Hitmonlee / Hitmonchan

**Event only:** Mew
