# ✅ Progress Checklist

Your run tracker **and** the full 151 Living Dex. **You tick the walkthrough steps & milestones yourself; the "Catch here" species boxes are auto-filled from [[Team & Boxes]]** (your roster) — don't hand-check those. Steps link to the area file.

> [!tip] Reading the catch lists
> Each **Catch here** box = one Pokémon to obtain for the Living Dex. A line with N boxes (e.g. Pidgey 1/3, 2/3, 3/3) means keep **that many** so you can hold every stage of its line (catch spares and evolve). **Surf / fishing Pokémon appear only once you have Surf or the right Rod.**

## 🏅 Milestones
- [x] Boulder — Brock Badge — [[07 - Pewter City]]
- [ ] Cascade — Misty Badge — [[11 - Cerulean City]]
- [ ] Thunder — Lt. Surge Badge — [[16 - Vermilion City]]
- [ ] Rainbow — Erika Badge — [[25 - Celadon City]]
- [ ] Soul — Koga Badge — [[35 - Fuchsia City]]
- [ ] Marsh — Sabrina Badge — [[37 - Saffron City]]
- [ ] Volcano — Blaine Badge — [[42 - Cinnabar Island]]
- [ ] Earth — Giovanni Badge — [[03 - Viridian City]]
- [ ] **Elite Four & Champion** — [[45 - Elite Four & Champion]]
- [ ] **HMs:** Cut · Fly · Surf · Strength · Flash · Rock Smash · Waterfall
- [ ] **Living Dex: 151 / 151**

## 🗺️ Kanto — main quest
### [[01 - Pallet Town]] ✅
- [x] Grab the Potion from your bedroom PC
- [x] Choose your starter in Oak’s Lab
- [x] Win the rival battle
- [x] Head north to Route 1

### [[02 - Route 1]] ✅
- [x] Take the free Potion from the Mart clerk
- [x] Catch a Pidgey and a Rattata
- [x] Head north to Viridian City
**Catch here (Living Dex):**
- [x] Pidgey (1/3)
- [x] Pidgey (2/3)
- [x] Pidgey (3/3)
- [x] Rattata (1/2)
- [x] Rattata (2/2)

### [[03 - Viridian City]] ✅
- [x] Get the Potion (item ball in the north-west grass, by the Route 22 gate)
- [x] Get Oak’s Parcel at the Mart → deliver to Oak in Pallet
- [x] Return for your Pokédex + 5 Poké Balls
- [x] Get the old-man tutorial + Teachy TV
- [x] Head north to Route 2 (Viridian Forest)

### [[04 - Route 22]] ✅
- [x] Catch a Mankey and a Spearow
- [x] Beat your rival
- [x] Return east to Viridian
**Catch here (Living Dex):**
- [x] Spearow (1/2)
- [x] Spearow (2/2)
- [x] Mankey (1/2)
- [x] Mankey (2/2)

### [[05 - Route 2]] ✅
- [x] Note the Cut-blocked items (come back later)
- [x] Enter Viridian Forest to head north
**Catch here (Living Dex):**
- [x] Caterpie (1/3)
- [x] Caterpie (2/3)
- [x] Caterpie (3/3)
- [x] Weedle (1/3)
- [x] Weedle (2/3)
- [x] Weedle (3/3)

### [[06 - Viridian Forest]] ✅
- [x] Catch a Pikachu (rare!), plus Metapod/Kakuna
- [x] Grab the four item balls (+ 2 hidden)
- [x] Beat Bug Catchers 1–5 (numbered on the map)
- [x] Take the north exit to Pewter
**Catch here (Living Dex):**
- [x] Pikachu (1/2)
- [x] Pikachu (2/2)

### [[07 - Pewter City]] ✅
- [x] Heal and stock up at the Mart
- [x] Beat the gym trainer, then Brock
- [x] Grab the Running Shoes heading east
- [x] Continue to Route 3

### [[08 - Route 3]]
- [ ] Catch Nidoran♂/♀ and Jigglypuff
- [x] Beat trainers 1–8 (numbered on the map) heading east
- [ ] Continue north to Route 4
**Catch here (Living Dex):**
- [x] Nidoran♀ (1/3)
- [ ] Nidoran♀ (2/3)
- [ ] Nidoran♀ (3/3)
- [x] Nidoran♂ (1/3)
- [x] Nidoran♂ (2/3)
- [x] Nidoran♂ (3/3)
- [x] Jigglypuff (1/2)
- [x] Jigglypuff (2/2)

### [[09 - Route 4]]
- [ ] Heal & stock up at the Pokémon Center
- [ ] Catch an Ekans
- [ ] Enter Mt. Moon
- [ ] On the east side: beat Lass Crissy & grab TM05 Roar
**Catch here (Living Dex):**
- [ ] Ekans (1/2)
- [ ] Ekans (2/2)

### [[10 - Mt. Moon]]
- [ ] Catch Zubat/Geodude/Paras and (deeper) Clefairy
- [ ] Grab the Moon Stones & items
- [ ] Beat trainers 1–11 (numbered on the maps)
- [ ] Choose ONE fossil after the Rockets
- [ ] Exit to Route 4 → Cerulean
**Catch here (Living Dex):**
- [ ] Clefairy (1/2)
- [ ] Clefairy (2/2)
- [ ] Zubat (1/2)
- [ ] Zubat (2/2)
- [ ] Paras (1/2)
- [ ] Paras (2/2)
- [ ] Geodude (1/3)
- [ ] Geodude (2/3)
- [ ] Geodude (3/3)

### [[11 - Cerulean City]]
- [ ] Heal & shop
- [ ] Beat the robbed-house Rocket → TM28 Dig
- [ ] Beat your rival (heading north)
- [ ] Beat Misty for the Cascade Badge
- [ ] Continue north to Nugget Bridge

### [[12 - Route 24]]
- [ ] Beat the bridge trainers 1–6 (numbered on the map)
- [ ] Beat the Rocket → get the Nugget
- [ ] Catch Abra (throw a ball turn 1!) and Oddish
- [ ] Grab TM45 Attract, then head east
**Catch here (Living Dex):**
- [ ] Oddish (1/3)
- [ ] Oddish (2/3)
- [ ] Oddish (3/3)
- [ ] Abra (1/3)
- [ ] Abra (2/3)
- [ ] Abra (3/3)

### [[13 - Route 25]]
- [ ] Beat trainers 1–9 (numbered on the map) heading east
- [ ] Reach Bill’s Cottage and change Bill back
- [ ] Get the S.S. Ticket
- [ ] Return toward Vermilion

### [[14 - Route 5]]
- [ ] Catch a Meowth
- [ ] (Optional) drop a Pokémon at the Day Care
- [ ] Take the Underground Path to Route 6
**Catch here (Living Dex):**
- [ ] Meowth (1/2)
- [ ] Meowth (2/2)

### [[15 - Route 6]]
- [ ] Beat trainers 1–6 (numbered on the map)
- [ ] Grab the hidden Sitrus Berry & Rare Candy
- [ ] Head south to Vermilion

### [[16 - Vermilion City]]
- [ ] Collect VS Seeker, Old Rod, Bike Voucher, Farfetch’d
- [ ] Board the S.S. Anne: sweep items, beat your rival, get HM01 Cut
- [ ] Cut the gym tree + solve the trash-can puzzle
- [ ] Beat the gym trainers, then Lt. Surge
- [ ] Head east to Route 11

### [[17 - Route 11]]
- [ ] Catch a Drowzee
- [ ] Beat trainers 1–10 (numbered on the map)
- [ ] Grab the items (X Defend, Great Ball, Awakening)
- [ ] Duck into Diglett’s Cave for Flash & Dugtrio
**Catch here (Living Dex):**
- [ ] Drowzee (1/2)
- [ ] Drowzee (2/2)

### [[18 - Diglett’s Cave]]
- [ ] Catch a Diglett (and a rare Dugtrio)
- [ ] Exit north to Route 2 → get HM05 Flash from the aide
- [ ] Return east toward Cerulean/Route 9
**Catch here (Living Dex):**
- [ ] Diglett (1/2)
- [ ] Diglett (2/2)

### [[19 - Route 9]]
- [ ] Grab TM40 Aerial Ace
- [ ] Beat trainers 1–9 (numbered on the map)
- [ ] Sweep the hidden items
- [ ] Continue east to Route 10

### [[20 - Route 10]]
- [ ] Heal at the Route 10 Pokémon Center
- [ ] Catch a Voltorb
- [ ] Beat trainers 1–6 (numbered on the map)
- [ ] Enter Rock Tunnel (note the Power Plant for later)
**Catch here (Living Dex):**
- [ ] Voltorb (1/2)
- [ ] Voltorb (2/2)

### [[21 - Rock Tunnel]]
- [ ] Use Flash immediately
- [ ] Catch a Machop and an Onix
- [ ] Beat trainers 1–15 (numbered on the maps)
- [ ] Grab the items
- [ ] Exit south to Lavender Town
**Catch here (Living Dex):**
- [ ] Machop (1/3)
- [ ] Machop (2/3)
- [ ] Machop (3/3)
- [ ] Onix

### [[22 - Lavender Town]]
- [ ] Heal & buy Great Balls at the Mart
- [ ] Note the Pokémon Tower (locked until the Silph Scope)
- [ ] Head west to Route 8 → Celadon

### [[23 - Route 8]]
- [ ] Catch a Growlithe (FireRed exclusive)
- [ ] Beat trainers 1–12 (numbered on the map)
- [ ] Take the Underground Path west to Route 7
**Catch here (Living Dex):**
- [ ] Growlithe (1/2)
- [ ] Growlithe (2/2)

### [[24 - Route 7]]
- [ ] Catch anything you still need (Oddish/Growlithe/Meowth)
- [ ] Head west into Celadon City

### [[25 - Celadon City]]
- [ ] Heal; grab Eevee on the Condominiums roof
- [ ] Shop the Dept. Store (stones, TMs, drinks→TMs)
- [ ] Get the Coin Case, play the Game Corner (Porygon & prize mons)
- [ ] Enter the Rocket Hideout via the poster switch → Silph Scope
- [ ] Beat Erika for the Rainbow Badge

### [[26 - Rocket Hideout]]
- [ ] Ride the arrow-tile mazes down through B1F–B4F
- [ ] Beat the Rocket grunts (numbered on the maps)
- [ ] Grab the items (Moon Stone, Rare Candy, TMs)
- [ ] Beat Giovanni → get the Silph Scope
- [ ] Escape and head to Lavender’s Pokémon Tower

### [[27 - Pokémon Tower]]
- [ ] Make sure you have the Silph Scope (from [[26 - Rocket Hideout]])
- [ ] Beat the rival on 2F
- [ ] Catch Gastly & Cubone (Haunter deeper up)
- [ ] Beat the Channelers on 3F–6F
- [ ] Defeat the ghost Marowak on 7F
- [ ] Beat the three Team Rocket Grunts
- [ ] Free Mr. Fuji → Poké Flute
- [ ] Leave and use the Poké Flute to wake sleeping Snorlax
**Catch here (Living Dex):**
- [ ] Gastly (1/3)
- [ ] Gastly (2/3)
- [ ] Gastly (3/3)
- [ ] Cubone (1/2)
- [ ] Cubone (2/2)

### [[28 - Route 16]]
- [ ] Get HM02 Fly from the gatehouse
- [ ] Wake & catch the Snorlax with the Poké Flute (save first!)
- [ ] Beat the trainers 1–6 (numbered on the map)
- [ ] Grab the Bicycle (redeem the Bike Voucher in Cerulean) for the Cycling Road
**Catch here (Living Dex):**
- [ ] Doduo (1/2)
- [ ] Doduo (2/2)

### [[29 - Route 17]]
- [ ] Ride the Bicycle south
- [ ] Beat the Bikers & Cue Balls 1–10 (numbered on the map)
- [ ] Sweep the hidden items along the guardrails

### [[30 - Route 18]]
- [ ] Beat the Bird Keepers 1–3
- [ ] Do the Lickitung trade in the gatehouse
- [ ] Enter Fuchsia City

### [[31 - Route 12]]
- [ ] Wake & catch the second Snorlax (Poké Flute)
- [ ] Get the Super Rod from the Fishing House
- [ ] Grab TM48 & Iron
- [ ] Beat the Fishermen 1–7 (numbered on the map)
- [ ] Continue south to Route 13
**Catch here (Living Dex):**
- [ ] Venonat (1/2)
- [ ] Venonat (2/2)
- [ ] Psyduck (1/2)
- [ ] Psyduck (2/2)
- [ ] Krabby (1/2)
- [ ] Krabby (2/2)
- [ ] Horsea (1/2)
- [ ] Horsea (2/2)

### [[32 - Route 13]]
- [ ] Catch a Ditto (and Pidgeotto)
- [ ] Beat the trainers 1–10 (numbered on the map)
- [ ] Navigate the fences west to Route 14
**Catch here (Living Dex):**
- [ ] Ditto

### [[33 - Route 14]]
- [ ] Beat the trainers 1–10 (numbered on the map; Twins Kiri & Jan are a double battle)
- [ ] Sweep the hidden Zinc
- [ ] Continue west to Route 15

### [[34 - Route 15]]
- [ ] Grab TM18 Rain Dance
- [ ] Beat the trainers 1–10 (numbered on the map)
- [ ] Enter Fuchsia City

### [[35 - Fuchsia City]]
- [ ] Heal & shop
- [ ] Get the Good Rod (Fishing Guru’s brother)
- [ ] Do the Safari Zone (Surf, Gold Teeth → Strength, rare catches)
- [ ] Return the Gold Teeth to the Warden for HM04 Strength
- [ ] Beat Koga for the Soul Badge
**Catch here (Living Dex):**
- [ ] Poliwag (1/3)
- [ ] Poliwag (2/3)
- [ ] Poliwag (3/3)
- [ ] Goldeen (1/2)
- [ ] Goldeen (2/2)

### [[36 - Safari Zone]]
- [ ] Pay ₽500 to enter (you get 30 Safari Balls & 500 steps)
- [ ] Grab the Gold Teeth (West) → return to the Warden for HM04 Strength
- [ ] Get HM03 Surf from the Secret House (far West)
- [ ] Hunt the rares: Scyther, Chansey, Kangaskhan, Tauros, Dratini
- [ ] Collect the items (Leaf Stone, TMs, stat items)
**Catch here (Living Dex):**
- [ ] Exeggcute (1/2)
- [ ] Exeggcute (2/2)
- [ ] Rhyhorn (1/2)
- [ ] Rhyhorn (2/2)
- [ ] Chansey
- [ ] Kangaskhan
- [ ] Scyther
- [ ] Tauros
- [ ] Dratini (1/3)
- [ ] Dratini (2/3)
- [ ] Dratini (3/3)

### [[37 - Saffron City]]
- [ ] Enter Saffron (give the gate guards a drink — Tea/soda)
- [ ] Fighting Dojo: beat the Black Belts, then choose Hitmonlee or Hitmonchan
- [ ] Free Silph Co. from Team Rocket (see [[38 - Silph Co.]])
- [ ] Get TM29 Psychic from Mr. Psychic
- [ ] Beat Sabrina for the Marsh Badge

### [[38 - Silph Co.]]
- [ ] Climb via stairs/teleporters; grab the Card Key (5F) to open locked doors
- [ ] Beat the Rockets & Scientists (numbered on the floor maps)
- [ ] Beat the rival on 7F
- [ ] Accept the free Lapras from a rescued worker (7F)
- [ ] Beat Giovanni on 11F → the president gives you the Master Ball
- [ ] Leave — Saffron is freed and Sabrina’s gym opens

### [[39 - Sea Route 19]]
- [ ] Surf south from Fuchsia
- [ ] Beat the Swimmers 1–10 (numbered on the map)
- [ ] Surf west toward Seafoam / Cinnabar
**Catch here (Living Dex):**
- [ ] Tentacool (1/2)
- [ ] Tentacool (2/2)

### [[40 - Sea Route 20]]
- [ ] Beat the Swimmers & trainers 1–10 (numbered on the map)
- [ ] Optionally enter Seafoam Islands (Articuno)
- [ ] Surf on to Cinnabar Island

### [[41 - Seafoam Islands]]
- [ ] Bring Surf + Strength
- [ ] Push boulders into the holes to slow the currents
- [ ] Catch Seel/Dewgong; grab the Water Stones
- [ ] Reach the bottom floor and catch Articuno (Lv 50)
- [ ] Exit toward Cinnabar
**Catch here (Living Dex):**
- [ ] Seel (1/2)
- [ ] Seel (2/2)

### [[42 - Cinnabar Island]]
- [ ] Revive your fossils at the Pokémon Lab
- [ ] Do the Lab in-game trades (Tangela, etc.)
- [ ] Clear the Pokémon Mansion for the Secret Key
- [ ] Beat Blaine for the Volcano Badge
**Catch here (Living Dex):**
- [ ] Shellder (1/2)
- [ ] Shellder (2/2)

### [[43 - Pokémon Mansion]]
- [ ] Flip the statue switches to open paths
- [ ] Catch Growlithe/Grimer/Koffing/Weezing; grab the hidden Moon Stone
- [ ] Beat the Burglars & Scientists (numbered on the maps)
- [ ] Reach B1F for the Secret Key
- [ ] Read the diaries (Mewtwo backstory), then return to Blaine
**Catch here (Living Dex):**
- [ ] Grimer (1/2)
- [ ] Grimer (2/2)
- [ ] Koffing (1/2)
- [ ] Koffing (2/2)

### [[44 - Victory Road]]
- [ ] Have all 8 badges (Route 23 gate checks them)
- [ ] Use Strength to push boulders onto the switches
- [ ] Beat the trainers (numbered on the maps)
- [ ] Catch Machoke/Marowak/Arbok; grab Rare Candy & Max Revive
- [ ] Climb to the exit → Indigo Plateau

### [[45 - Elite Four & Champion]]
- [ ] Heal & buy Full Restores / Revives at the Plateau Center
- [ ] Beat Lorelei (Ice)
- [ ] Beat Bruno (Fighting/Rock)
- [ ] Beat Agatha (Ghost/Poison)
- [ ] Beat Lance (Dragon/Flying)
- [ ] Beat the Champion (your rival)


## 🌴 Sevii Islands — post-game
### [[46 - One Island]]
- [ ] Talk to Celio in the Pokémon Center (Network Machine — needs the gems)
- [ ] Catch Tangela & Persian on Treasure Beach
- [ ] Sweep Treasure Beach for hidden items
- [ ] Head east to Kindle Road
**Catch here (Living Dex):**
- [ ] Tangela

### [[47 - Kindle Road]]
- [ ] Beat the trainers 1–11 (numbered on the map)
- [ ] Catch Ponyta
- [ ] Get HM06 Rock Smash at the Ember Spa
- [ ] Continue north to Mt. Ember
**Catch here (Living Dex):**
- [ ] Ponyta (1/2)
- [ ] Ponyta (2/2)

### [[48 - Mt. Ember]]
- [ ] Beat the trainers (numbered on the map)
- [ ] Climb to the summit and catch Moltres (Lv 50)
- [ ] Rock-Smash into the Ruby Path; beat the Rockets; grab the Ruby
- [ ] Give the Ruby to Celio on One Island

### [[49 - Two Island]]
- [ ] Deliver the Meteorite errand / progress the island quest
- [ ] Visit the Move Reminder & Game Corner in town
- [ ] Learn your starter’s ultimate move at the Cape Brink house
- [ ] Grab the hidden PP Max & Rare Candy at Cape Brink

### [[50 - Three Island]]
- [ ] Beat the biker gang harassing the town
- [ ] Beat the Bond Bridge trainers (numbered on the map)
- [ ] Cross to Berry Forest

### [[51 - Berry Forest]]
- [ ] Harvest the hidden berries throughout the forest
- [ ] Catch a Hypno (and Exeggcute/Venomoth)
- [ ] Explore for items, then return

### [[52 - Power Plant]]
- [ ] Surf to the Power Plant from Route 10
- [ ] Catch Magnemite/Voltorb/Pikachu/Electabuzz
- [ ] Watch for the two disguised Electrode
- [ ] Catch Zapdos (Lv 50)
**Catch here (Living Dex):**
- [ ] Magnemite (1/2)
- [ ] Magnemite (2/2)
- [ ] Electabuzz

### [[53 - Cerulean Cave]]
- [ ] Have the National Dex + both gems (Ruby & Sapphire) to enter
- [ ] Surf in from Cerulean City
- [ ] Catch the high-level wild Pokémon (Ditto, Chansey-tier rares)
- [ ] Reach the bottom and catch Mewtwo (Lv 70) — use the Master Ball

### [[54 - Four Island]]
- [ ] Get HM07 Waterfall in Icefall Cave (1F)
- [ ] Beat the Rocket inside
- [ ] Catch a wild Lapras (Surf, 1%) if you like
- [ ] Use the Day Care for breeding/leveling
**Catch here (Living Dex):**
- [ ] Lapras

### [[55 - Five Island]]
- [ ] Cross the Meadow, beating the Rockets
- [ ] Storm the Rocket Warehouse — beat the Grunts, Scientist, and two Admins
- [ ] Recover the Sapphire → give it to Celio (One Island)
- [ ] Explore the Lost Cave for Selphy’s reward

### [[56 - Six Island]]
- [ ] Cross Green/Water Path (Dragon Scale for Kingdra)
- [ ] Clear Pattern Bush (12 trainers; wild Heracross)
- [ ] In Ruin Valley, use Cut/Strength to enter the Dotted Hole
- [ ] Solve the Braille puzzle for the Sapphire → give to Celio

### [[57 - Seven Island]]
- [ ] Explore Sevault Canyon; grab the Tanoby Key
- [ ] Use the Key to unlock the Tanoby Ruins chambers
- [ ] Catch Unown (each chamber holds different letters)
- [ ] Optionally challenge the Trainer Tower

## 🎁 Gifts & one-time
*(Your chosen starter is here; the other two lines are in 🔄 Import.)*
- [x] Squirtle (1/3) — your starter (Oak's Lab)
- [ ] Squirtle (2/3)
- [ ] Squirtle (3/3)
- [ ] Eevee (1/4) — Celadon · need 3 more via Ditto breeding + a stone each
- [ ] Eevee (2/4)
- [ ] Eevee (3/4)
- [ ] Eevee (4/4)
- [ ] Lapras — Silph Co.
- [ ] Porygon — Celadon Game Corner
- [ ] Magikarp (1/2) — Route 4 salesman (or fish)
- [ ] Magikarp (2/2)
- [ ] Hitmonlee **or** Hitmonchan — Fighting Dojo, Saffron (**pick 1**; other → Import)

## 🦴 Fossils (revive at Cinnabar Lab)
- [ ] Helix→**Omanyte** *or* Dome→**Kabuto** — Mt. Moon (**pick 1**; other → Import)
- [ ] its evolution (Omastar / Kabutops, L40)
- [ ] Aerodactyl — Old Amber → Cinnabar Lab

## 🤝 In-game trades (obtainable solo)
- [ ] Mr. Mime — Route 2 (give Abra)
- [ ] Jynx — Cerulean (give Poliwhirl)
- [ ] Farfetch'd — Vermilion (give Spearow)
- [ ] Lickitung — Route 18 (give Golduck)

## 💤 Statics & Legendaries (save before each!)
- [ ] Snorlax — Route 12 or 16 (need Poké Flute)
- [ ] Articuno — Seafoam Islands
- [ ] Zapdos — Power Plant
- [ ] Moltres — Mt. Ember
- [ ] Mewtwo — Cerulean Cave (post-E4)

## 🔄 Import — trade or save-edit (can't get solo)
*See [[A3 - Trades & Exclusives]]. Squirtle chosen → Bulbasaur & Charmander lines here.*
**Alternate starters:**
- [ ] Bulbasaur (1/3) — unpicked starter
- [ ] Bulbasaur (2/3)
- [ ] Bulbasaur (3/3)
- [ ] Charmander (1/3) — unpicked starter
- [ ] Charmander (2/3)
- [ ] Charmander (3/3)
**13 LeafGreen exclusives:**
- [ ] Sandshrew (1/2) — LG-exclusive
- [ ] Sandshrew (2/2)
- [ ] Vulpix (1/2) — LG-exclusive
- [ ] Vulpix (2/2)
- [ ] Bellsprout (1/3) — LG-exclusive
- [ ] Bellsprout (2/3)
- [ ] Bellsprout (3/3)
- [ ] Slowpoke (1/2) — LG-exclusive
- [ ] Slowpoke (2/2)
- [ ] Staryu (1/2) — LG-exclusive
- [ ] Staryu (2/2)
- [ ] Magmar — LG-exclusive
- [ ] Pinsir — LG-exclusive
**4 trade evolutions** (evolve your caught base via trade/save-edit):
- [ ] Alakazam
- [ ] Machamp
- [ ] Golem
- [ ] Gengar
**Other:**
- [ ] Alternate fossil (Omanyte/Kabuto you didn't pick) + its evo
- [ ] Alternate Hitmon (the one you didn't pick)
- [ ] Mew — event → save-edit

*Coverage: 151 / 151 accounted for. ✅ all 151 covered.*
*Generated from walkthrough objectives + decomp data — regenerate when the guide changes.*
