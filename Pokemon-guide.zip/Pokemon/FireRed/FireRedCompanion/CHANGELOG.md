# Changelog — FireRed Companion

## v0.4.0 — Usable map redesign
- **Buildings are labeled on the map** ("Your House", "Oak's Lab", "Poké Mart", "Gym"…) — derived from each door's warp destination, so the map is readable instead of cryptic.
- **Exits are labeled** at the edges (▲ Route 1, ▼ Route 21).
- **Bigger + zoomable** (−/＋), scrolls both axes.
- **De-cluttered**: NPCs and Signs are off by default with toggles; a legend shows what colors mean.
- Larger, clearer markers; ledges scale with zoom; richer detail bar.
- Map data now carries building `place` names (`export_maps.py`).

## v0.3.0 — Native interactive map engine
- Replaced SVG/WebView with a native Canvas renderer; every marker hoverable/clickable.

## v0.2.0 — Phase 2: interactive walkthrough
- Walkthrough tab: 57 areas with maps + Steps/Connections/Wild/Items/Trainers.

## v0.1.0 — Phase 1
- Native SwiftUI + SwiftData app; Team & Boxes single source of truth; live auto-counting Pokédex.
