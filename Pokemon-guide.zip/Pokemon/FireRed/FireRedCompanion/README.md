# FireRed Companion — Phase 1

A native **SwiftUI + SwiftData** macOS app. The roster **is** the data store, so the Pokédex counts and Living-Dex total are **derived live** — the manual "sync" step from the Obsidian setup is gone by design.

## Run it
```bash
cd FireRedCompanion
swift run
```
…or open `Package.swift` in Xcode and hit Run.

## What Phase 1 does
- **Team & Boxes tab** — your live roster (party + boxes). Catch (＋), delete (swipe), change level (stepper), evolve/move via right-click. This is the single source of truth.
- **Pokédex tab** — all 151, each showing held ✓ and `×N`, **counted live** from the roster. Search included.
- **Header** — `Living Dex N / 151`, always current.
- On first launch it **seeds from your real roster** (`Resources/roster.json`), so it opens with your actual team.
- Data persists automatically (SwiftData / SQLite in the app's Application Support).

Because the dex counts individuals by their *current* species, **evolving a Pokémon automatically unchecks the old stage and checks the new one** — no bookkeeping.

## Data pipeline
Static data is bundled JSON, generated from the **pret/pokefirered decompilation** + your Team & Boxes note:
```bash
python3 tools/export_app_data.py     # regenerates Resources/species.json + roster.json
```
- `species.json` — 151 entries: id, name, types, family root, line stages (from the decomp).
- `roster.json` — one-time seed of your current party/box.

## Assets / legal
Only **original code and factual game data** (types, evolutions, dex order). **No** Nintendo assets — no sprites, music, tile art, or ROM. Future emulator work (Phase 3) must use an open-source core (e.g. mGBA) and the player's own ROM; nothing copyrighted gets bundled.

## Next
- **Phase 2:** interactive maps (render the existing SVGs, hover-for-details from the marker data we already compute) + the walkthrough content.
- **Phase 3 (stretch):** embed an emulator core and read the live party from work RAM (`gPlayerParty`) to update the roster automatically.
