import Foundation

struct MapData: Codable, Hashable {
    let w: Int
    let h: Int
    let tiles: [Int]          // 0 path · 1 grass · 2 water · 3 building · 4 wall
    let ledges: [Ledge]
    let markers: [Marker]
    let exits: [Conn]
}

struct Ledge: Codable, Hashable { let x: Int; let y: Int; let dir: String }

struct Marker: Codable, Hashable, Identifiable {
    let type: String         // trainer · item · door · npc · hidden · sign
    let x: Int
    let y: Int
    let label: String
    let detail: String
    var place: String?       // building name for door markers (e.g. "Oak's Lab")
    var id: String { "\(type)-\(x)-\(y)" }
}

enum MapStore {
    static let maps: [String: MapData] = {
        guard let url = Bundle.module.url(forResource: "mapdata", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([String: MapData].self, from: data)
        else { return [:] }
        return decoded
    }()
}
