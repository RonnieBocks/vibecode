import SwiftUI

/// Native, interactive map: Canvas tiles + labeled buildings/exits + hoverable markers.
struct NativeMapView: View {
    let mapName: String
    @State private var active: Marker?
    @State private var tile: CGFloat = 24
    @State private var showNPC = false
    @State private var showSign = false

    private var data: MapData? { MapStore.maps[mapName] }

    var body: some View {
        if let d = data {
            VStack(alignment: .leading, spacing: 8) {
                toolbar
                mapCanvas(d)
                    .frame(maxHeight: 460)
                    .background(Color(nsColor: .textBackgroundColor))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(.quaternary))
                detailBar
            }
        } else {
            Label("No interactive map for “\(mapName)” yet.", systemImage: "map")
                .font(.caption).foregroundStyle(.secondary).padding(.vertical, 8)
        }
    }

    // MARK: Toolbar
    private var toolbar: some View {
        HStack(spacing: 10) {
            HStack(spacing: 4) {
                Button { tile = max(14, tile - 3) } label: { Image(systemName: "minus.magnifyingglass") }
                Button { tile = min(44, tile + 3) } label: { Image(systemName: "plus.magnifyingglass") }
            }.buttonStyle(.bordered).controlSize(.small)
            Toggle("NPCs", isOn: $showNPC).toggleStyle(.button).controlSize(.small)
            Toggle("Signs", isOn: $showSign).toggleStyle(.button).controlSize(.small)
            Spacer()
            legendChips
        }
    }

    private var legendChips: some View {
        HStack(spacing: 10) {
            ForEach([("Trainer", Color(red:0.75,green:0.22,blue:0.17)),
                     ("Item", Color(red:0.90,green:0.49,blue:0.13)),
                     ("Hidden", Color(red:0.79,green:0.63,blue:0.15)),
                     ("Door", Color(red:0.48,green:0.25,blue:0.06))], id: \.0) { name, c in
                HStack(spacing: 3) {
                    Circle().fill(c).frame(width: 9, height: 9)
                    Text(name).font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
    }

    // MARK: Map
    private func mapCanvas(_ d: MapData) -> some View {
        let W = CGFloat(d.w) * tile, H = CGFloat(d.h) * tile
        let buildings = buildingLabels(d)
        let markers = d.markers.filter { m in
            switch m.type { case "sign": return showSign; case "npc": return showNPC; default: return true }
        }
        return ScrollView([.horizontal, .vertical]) {
            ZStack(alignment: .topLeading) {
                Canvas { ctx, _ in
                    for i in 0..<d.tiles.count {
                        let x = i % d.w, y = i / d.w
                        let r = CGRect(x: CGFloat(x)*tile, y: CGFloat(y)*tile, width: tile, height: tile)
                        ctx.fill(Path(r), with: .color(Self.tileColor(d.tiles[i])))
                        ctx.stroke(Path(r), with: .color(.black.opacity(0.06)), lineWidth: 0.5)
                    }
                    for l in d.ledges { drawLedge(l, in: &ctx) }
                }
                .frame(width: W, height: H)

                // Exit labels at edges
                ForEach(d.exits, id: \.self) { e in
                    exitPill(e).position(exitPos(e.dir, W: W, H: H))
                }
                // Building name labels
                ForEach(buildings, id: \.name) { b in
                    labelPill(b.name, color: Color(red:0.30,green:0.16,blue:0.04))
                        .position(x: CGFloat(b.cx)*tile + tile/2,
                                  y: max(9, CGFloat(b.cy)*tile - tile*0.35))
                }
                // Markers
                ForEach(markers) { mk in
                    MarkerDot(marker: mk, tile: tile, isActive: active == mk)
                        .position(x: CGFloat(mk.x)*tile + tile/2, y: CGFloat(mk.y)*tile + tile/2)
                        .help(mk.detail)
                        .onHover { if $0 { active = mk } }
                        .onTapGesture { active = mk }
                }
            }
            .frame(width: W, height: H)
            .padding(24)
        }
    }

    private struct Building { let name: String; let cx: Double; let cy: Double }
    private func buildingLabels(_ d: MapData) -> [Building] {
        var groups: [String: [Marker]] = [:]
        for m in d.markers where m.type == "door" { if let p = m.place { groups[p, default: []].append(m) } }
        return groups.map { name, v in
            Building(name: name,
                     cx: Double(v.map(\.x).reduce(0,+)) / Double(v.count),
                     cy: Double(v.map(\.y).reduce(0,+)) / Double(v.count))
        }
    }

    private func exitPos(_ dir: String, W: CGFloat, H: CGFloat) -> CGPoint {
        switch dir {
        case "up": return CGPoint(x: W/2, y: 12)
        case "down": return CGPoint(x: W/2, y: H - 12)
        case "left": return CGPoint(x: 44, y: H/2)
        default: return CGPoint(x: W - 44, y: H/2)   // right
        }
    }
    private func arrow(_ dir: String) -> String {
        ["up":"▲","down":"▼","left":"◀","right":"▶"][dir] ?? "•"
    }
    private func exitPill(_ e: Conn) -> some View {
        Text("\(arrow(e.dir)) \(e.to)")
            .font(.caption.bold()).foregroundStyle(.white)
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(Color(red:0.04,green:0.18,blue:0.29).opacity(0.92), in: Capsule())
    }
    private func labelPill(_ text: String, color: Color) -> some View {
        Text(text).font(.caption2.bold()).foregroundStyle(.white).lineLimit(1)
            .padding(.horizontal, 7).padding(.vertical, 3)
            .background(color.opacity(0.92), in: RoundedRectangle(cornerRadius: 5))
            .fixedSize()
    }

    private func drawLedge(_ l: Ledge, in ctx: inout GraphicsContext) {
        let cx = CGFloat(l.x)*tile + tile/2, cy = CGFloat(l.y)*tile + tile/2
        let s = tile * 0.22
        var p = Path()
        switch l.dir {
        case "S": p.move(to: .init(x: cx-s, y: cy)); p.addLine(to: .init(x: cx+s, y: cy)); p.addLine(to: .init(x: cx, y: cy+s))
        case "N": p.move(to: .init(x: cx-s, y: cy)); p.addLine(to: .init(x: cx+s, y: cy)); p.addLine(to: .init(x: cx, y: cy-s))
        case "E": p.move(to: .init(x: cx, y: cy-s)); p.addLine(to: .init(x: cx, y: cy+s)); p.addLine(to: .init(x: cx+s, y: cy))
        default:  p.move(to: .init(x: cx, y: cy-s)); p.addLine(to: .init(x: cx, y: cy+s)); p.addLine(to: .init(x: cx-s, y: cy))
        }
        p.closeSubpath()
        ctx.fill(p, with: .color(.black.opacity(0.4)))
    }

    // MARK: Detail bar
    private var detailBar: some View {
        HStack(spacing: 8) {
            if let m = active {
                MarkerDot(marker: m, tile: 20, isActive: true)
                Text(m.type.capitalized).font(.caption.bold()).foregroundStyle(.secondary)
                Text(m.detail).font(.callout).textSelection(.enabled)
            } else {
                Image(systemName: "hand.point.up.left").foregroundStyle(.secondary)
                Text("Hover or click any marker for details. Buildings and exits are labeled; use the toggles to show NPCs/signs.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 8))
    }

    static func tileColor(_ k: Int) -> Color {
        switch k {
        case 1: return Color(red: 0.36, green: 0.68, blue: 0.33)
        case 2: return Color(red: 0.25, green: 0.62, blue: 0.84)
        case 3: return Color(red: 0.61, green: 0.42, blue: 0.24)
        case 4: return Color(red: 0.43, green: 0.42, blue: 0.37)
        default: return Color(red: 0.90, green: 0.84, blue: 0.67)
        }
    }
}

private struct MarkerDot: View {
    let marker: Marker
    let tile: CGFloat
    let isActive: Bool

    var body: some View {
        let d = max(15, tile * 0.72)
        Text(glyph)
            .font(.system(size: max(9, d*0.5), weight: .bold))
            .foregroundStyle(.white)
            .frame(width: d, height: d)
            .background(Circle().fill(color))
            .overlay(Circle().stroke(isActive ? Color.yellow : .white, lineWidth: isActive ? 2.5 : 1.2))
            .shadow(color: .black.opacity(0.4), radius: isActive ? 3 : 1, y: 0.5)
    }

    private var glyph: String {
        switch marker.type {
        case "trainer": return marker.label
        case "item": return "i"
        case "hidden": return "H"
        case "door": return "🚪"
        case "npc": return "N"
        case "sign": return "s"
        default: return "?"
        }
    }
    private var color: Color {
        switch marker.type {
        case "trainer": return Color(red: 0.75, green: 0.22, blue: 0.17)
        case "item": return Color(red: 0.90, green: 0.49, blue: 0.13)
        case "hidden": return Color(red: 0.79, green: 0.63, blue: 0.15)
        case "door": return Color(red: 0.48, green: 0.25, blue: 0.06)
        case "sign": return Color(red: 0.35, green: 0.27, blue: 0.20)
        default: return Color(red: 0.55, green: 0.55, blue: 0.55)
        }
    }
}
