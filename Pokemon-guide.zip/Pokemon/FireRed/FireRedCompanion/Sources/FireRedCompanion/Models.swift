import Foundation
import SwiftData

/// Static reference data (bundled JSON, exported from the pret/pokefirered decompilation).
struct Species: Codable, Identifiable, Hashable {
    let id: Int
    let name: String
    let type1: String
    let type2: String?
    let familyRoot: String
    let lineStages: Int   // copies needed to hold every stage of the line at once

    var typeLine: String { type2 == nil ? type1 : "\(type1)/\(type2!)" }
}

struct RosterSeed: Codable {
    let species: String
    let level: Int
    let moves: [String]
    let heldItem: String?
    let container: String
}

/// The ONE editable source of truth — a Pokémon the player currently owns.
/// Everything derived (dex counts, Living-Dex total) is computed live from these.
@Model
final class OwnedMon {
    var species: String
    var nickname: String?
    var level: Int
    var moves: [String]
    var heldItem: String?
    var container: String   // "party" or "box"
    var caughtAt: Date

    init(species: String, level: Int, moves: [String] = [], heldItem: String? = nil,
         container: String = "box", nickname: String? = nil) {
        self.species = species
        self.level = level
        self.moves = moves
        self.heldItem = heldItem
        self.container = container
        self.nickname = nickname
        self.caughtAt = .now
    }
}

enum DexData {
    static let species: [Species] = load("species")
    static let seed: [RosterSeed] = load("roster")
    static let byName: [String: Species] =
        Dictionary(species.map { ($0.name, $0) }, uniquingKeysWith: { a, _ in a })

    private static func load<T: Decodable>(_ resource: String) -> T {
        guard let url = Bundle.module.url(forResource: resource, withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode(T.self, from: data)
        else { fatalError("Missing/invalid resource: \(resource).json") }
        return decoded
    }
}
