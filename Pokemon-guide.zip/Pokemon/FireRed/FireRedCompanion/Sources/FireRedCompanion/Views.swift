import SwiftUI
import SwiftData

struct RootView: View {
    @Environment(\.modelContext) private var ctx
    @Query private var owned: [OwnedMon]

    private var heldDistinct: Int { Set(owned.map(\.species)).count }

    var body: some View {
        TabView {
            DexView().tabItem { Label("Pokédex", systemImage: "book") }
            RosterView().tabItem { Label("Team & Boxes", systemImage: "tray.full") }
            WalkthroughView().tabItem { Label("Walkthrough", systemImage: "map") }
        }
        .frame(minWidth: 860, minHeight: 620)
        .safeAreaInset(edge: .top) {
            HStack {
                Text("FireRed Companion").font(.headline)
                Text("v\(appVersion)").font(.caption2).foregroundStyle(.secondary)
                Spacer()
                Text("Living Dex \(heldDistinct) / 151")
                    .font(.subheadline).monospacedDigit()
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(.green.opacity(0.18), in: Capsule())
            }
            .padding(.horizontal).padding(.vertical, 8)
            .background(.bar)
        }
        .task { seedIfNeeded() }
    }

    private func seedIfNeeded() {
        guard owned.isEmpty else { return }
        for r in DexData.seed {
            ctx.insert(OwnedMon(species: r.species, level: r.level, moves: r.moves,
                                heldItem: r.heldItem, container: r.container))
        }
    }
}

struct DexView: View {
    @Query private var owned: [OwnedMon]
    @State private var search = ""

    var body: some View {
        // Live counts derived from the roster — no sync step, ever.
        let counts = Dictionary(grouping: owned, by: \.species).mapValues(\.count)
        List {
            ForEach(DexData.species.filter {
                search.isEmpty || $0.name.localizedCaseInsensitiveContains(search)
            }) { sp in
                DexRow(species: sp, count: counts[sp.name] ?? 0)
            }
        }
        .searchable(text: $search, prompt: "Search species")
    }
}

struct DexRow: View {
    let species: Species
    let count: Int
    private var held: Bool { count > 0 }

    var body: some View {
        HStack(spacing: 10) {
            Text(String(format: "%03d", species.id))
                .foregroundStyle(.secondary).monospacedDigit()
                .frame(width: 42, alignment: .leading)
            Text(species.name)
                .fontWeight(held ? .semibold : .regular)
                .foregroundStyle(held ? .primary : .secondary)
            Spacer()
            Text(species.typeLine).font(.caption).foregroundStyle(.secondary)
            if held {
                Text("×\(count)").font(.caption).monospacedDigit()
                    .padding(.horizontal, 6).padding(.vertical, 2)
                    .background(.green.opacity(0.2), in: Capsule())
            }
            Image(systemName: held ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(held ? .green : Color.secondary.opacity(0.5))
        }
    }
}

struct RosterView: View {
    @Environment(\.modelContext) private var ctx
    @Query(sort: [SortDescriptor(\OwnedMon.level, order: .reverse)]) private var owned: [OwnedMon]
    @State private var showAdd = false

    private var party: [OwnedMon] { owned.filter { $0.container == "party" } }
    private var box: [OwnedMon] { owned.filter { $0.container == "box" } }

    var body: some View {
        List {
            Section("Party (\(party.count)/6)") {
                ForEach(party) { MonRow(mon: $0) }
                    .onDelete { remove($0, from: party) }
            }
            Section("Box (\(box.count))") {
                ForEach(box) { MonRow(mon: $0) }
                    .onDelete { remove($0, from: box) }
            }
        }
        .toolbar {
            Button { showAdd = true } label: { Label("Catch", systemImage: "plus") }
        }
        .sheet(isPresented: $showAdd) { AddMonView() }
    }

    private func remove(_ idx: IndexSet, from arr: [OwnedMon]) {
        for i in idx { ctx.delete(arr[i]) }
    }
}

struct MonRow: View {
    @Bindable var mon: OwnedMon

    var body: some View {
        HStack(spacing: 12) {
            Text(mon.species).frame(width: 120, alignment: .leading)
            Text("Lv \(mon.level)").foregroundStyle(.secondary).monospacedDigit()
            Stepper("", value: $mon.level, in: 1...100).labelsHidden()
            Spacer()
            if !mon.moves.isEmpty {
                Text(mon.moves.joined(separator: ", "))
                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
        }
        .contextMenu {
            // Evolving = just change the species here; the dex re-counts automatically.
            Menu("Evolve / change species") {
                ForEach(DexData.species) { sp in
                    Button(sp.name) { mon.species = sp.name }
                }
            }
            Button(mon.container == "party" ? "Move to Box" : "Move to Party") {
                mon.container = mon.container == "party" ? "box" : "party"
            }
        }
    }
}

struct AddMonView: View {
    @Environment(\.modelContext) private var ctx
    @Environment(\.dismiss) private var dismiss
    @Query private var owned: [OwnedMon]
    @State private var species = "Pidgey"
    @State private var level = 5

    private var partyFull: Bool { owned.filter { $0.container == "party" }.count >= 6 }

    var body: some View {
        NavigationStack {
            Form {
                Picker("Species", selection: $species) {
                    ForEach(DexData.species) { Text($0.name).tag($0.name) }
                }
                Stepper("Level \(level)", value: $level, in: 1...100)
                Text(partyFull ? "Party full → will go to the Box" : "Will join your Party")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .navigationTitle("Catch a Pokémon")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        ctx.insert(OwnedMon(species: species, level: level,
                                            container: partyFull ? "box" : "party"))
                        dismiss()
                    }
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
        .frame(minWidth: 360, minHeight: 240)
    }
}
