import SwiftUI
import SwiftData

@main
struct FireRedCompanionApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(for: OwnedMon.self)
    }
}
