import Foundation

let appVersion = "0.4.0"

struct Area: Codable, Identifiable, Hashable {
    let id: Int
    let name: String
    let maps: [String]
    let connections: [Conn]
    let wild: [WildGroup]
    let items: [String]
    let newMons: [String]
    let steps: [String]
    let trainers: [TrainerGroup]

    /// "01 - Pallet Town" -> "Pallet Town"
    var shortName: String {
        name.replacingOccurrences(of: #"^\d+\w? - "#, with: "", options: .regularExpression)
    }
}

struct Conn: Codable, Hashable { let dir: String; let to: String }
struct WildMon: Codable, Hashable { let name: String; let type: String; let rate: String; let levels: String }
struct WildGroup: Codable, Hashable { let method: String; let mons: [WildMon] }
struct BattleMon: Codable, Hashable {
    let name: String; let type: String; let level: String; let exp: String; let moves: String; let stats: String?
}
struct Battle: Codable, Hashable { let who: String; let mons: [BattleMon]; let reward: String? }
struct TrainerGroup: Codable, Hashable { let section: String; let battles: [Battle] }

enum AreaData {
    static let all: [Area] = {
        guard let url = Bundle.module.url(forResource: "areas", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([Area].self, from: data)
        else { return [] }
        return decoded.filter { $0.id >= 1 }.sorted { $0.id < $1.id }
    }()
}
