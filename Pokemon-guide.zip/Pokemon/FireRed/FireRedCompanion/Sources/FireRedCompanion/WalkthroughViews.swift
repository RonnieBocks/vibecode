import SwiftUI

struct WalkthroughView: View {
    @State private var selected: Area? = AreaData.all.first

    var body: some View {
        NavigationSplitView {
            List(AreaData.all, selection: $selected) { area in
                NavigationLink(value: area) {
                    Text(area.name).lineLimit(1)
                }
            }
            .navigationTitle("Areas")
            .frame(minWidth: 210)
        } detail: {
            if let area = selected {
                AreaDetailView(area: area)
            } else {
                ContentUnavailableView("Pick an area", systemImage: "map")
            }
        }
    }
}

struct AreaDetailView: View {
    let area: Area

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(area.shortName).font(.largeTitle.bold())

                // Native interactive maps — every marker is hoverable/clickable
                ForEach(area.maps, id: \.self) { m in
                    let base = m.replacingOccurrences(of: ".svg", with: "")
                    VStack(alignment: .leading, spacing: 4) {
                        if area.maps.count > 1 {
                            Text(base).font(.caption.bold()).foregroundStyle(.secondary)
                        }
                        NativeMapView(mapName: base)
                    }
                }

                if !area.steps.isEmpty { StepsSection(steps: area.steps) }
                if !area.connections.isEmpty { ConnectionsSection(conns: area.connections) }
                if !area.wild.isEmpty { WildSection(groups: area.wild) }
                if !area.items.isEmpty { SimpleListSection(title: "Items", icon: "shippingbox", rows: area.items) }
                if !area.newMons.isEmpty { SimpleListSection(title: "New Pokémon", icon: "sparkles", rows: area.newMons) }
                if !area.trainers.isEmpty { TrainersSection(groups: area.trainers) }
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

private struct SectionCard<Content: View>: View {
    let title: String; let icon: String; @ViewBuilder var content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: icon).font(.headline)
            content
        }
        .padding(12)
        .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 8))
    }
}

private struct StepsSection: View {
    let steps: [String]
    var body: some View {
        SectionCard(title: "Do this in order", icon: "checklist") {
            ForEach(Array(steps.enumerated()), id: \.offset) { i, s in
                Text("\(i + 1). \(s)").font(.callout)
            }
        }
    }
}

private struct ConnectionsSection: View {
    let conns: [Conn]
    var body: some View {
        SectionCard(title: "Connections", icon: "arrow.triangle.branch") {
            ForEach(conns, id: \.self) { c in
                HStack { Text(c.dir).foregroundStyle(.secondary).frame(width: 120, alignment: .leading); Text(c.to) }
                    .font(.callout)
            }
        }
    }
}

private struct WildSection: View {
    let groups: [WildGroup]
    var body: some View {
        SectionCard(title: "Wild Pokémon", icon: "leaf") {
            ForEach(groups, id: \.self) { g in
                Text(g.method).font(.subheadline.bold()).padding(.top, 2)
                ForEach(g.mons, id: \.self) { m in
                    HStack {
                        Text(m.name).frame(width: 120, alignment: .leading)
                        Text(m.type).font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        Text(m.rate).monospacedDigit().foregroundStyle(.secondary)
                    }
                    .font(.callout)
                    .help("\(m.name) · \(m.type) · \(m.rate) · Levels \(m.levels)")
                }
            }
        }
    }
}

private struct SimpleListSection: View {
    let title: String; let icon: String; let rows: [String]
    var body: some View {
        SectionCard(title: title, icon: icon) {
            ForEach(rows, id: \.self) { Text($0).font(.callout) }
        }
    }
}

private struct TrainersSection: View {
    let groups: [TrainerGroup]
    var body: some View {
        SectionCard(title: "Trainers & Battles", icon: "figure.fencing") {
            ForEach(Array(groups.enumerated()), id: \.offset) { _, g in
                Text(g.section).font(.subheadline.bold()).padding(.top, 2)
                ForEach(Array(g.battles.enumerated()), id: \.offset) { _, b in
                    DisclosureGroup {
                        ForEach(Array(b.mons.enumerated()), id: \.offset) { _, mon in
                            VStack(alignment: .leading, spacing: 1) {
                                HStack {
                                    Text(mon.name).fontWeight(.medium)
                                    Text(mon.type).font(.caption).foregroundStyle(.secondary)
                                    Spacer()
                                    Text("Lv \(mon.level)").monospacedDigit().foregroundStyle(.secondary)
                                    Text("· \(mon.exp) exp").font(.caption).foregroundStyle(.secondary)
                                }
                                Text(mon.moves).font(.caption).foregroundStyle(.secondary)
                                if let s = mon.stats { Text(s).font(.caption2).foregroundStyle(.tertiary) }
                            }
                            .padding(.vertical, 1)
                        }
                        if let r = b.reward {
                            Text("Reward: \(r)").font(.caption).foregroundStyle(.secondary)
                        }
                    } label: {
                        Text(b.who).font(.callout)
                            .help(b.mons.map { "\($0.name) L\($0.level)" }.joined(separator: ", "))
                    }
                }
            }
        }
    }
}
