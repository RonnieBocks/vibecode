// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "FireRedCompanion",
    platforms: [.macOS(.v14)],
    targets: [
        .executableTarget(
            name: "FireRedCompanion",
            resources: [
                .process("Resources/species.json"),
                .process("Resources/roster.json"),
                .process("Resources/areas.json"),
                .process("Resources/mapdata.json"),
            ]
        )
    ]
)
