# -*- coding: utf-8 -*-
import re,json,urllib.request
BASE="https://raw.githubusercontent.com/pret/pokefirered/master/"
def get(p): return urllib.request.urlopen(BASE+p).read().decode('utf-8','ignore')
RES="/Users/ronnie/Obsidian/Pokemon/FireRed/FireRedCompanion/Sources/FireRedCompanion/Resources/"
# --- species order + families + types ---
ptr=get("src/data/pokemon/level_up_learnset_pointers.h"); order=[];seen=set()
for m in re.finditer(r'\[SPECIES_([A-Z0-9_]+)\]\s*=',ptr):
    s='SPECIES_'+m.group(1)
    if s!='SPECIES_NONE' and s not in seen: seen.add(s);order.append(s)
K=order[:151]; KS=set(K)
evo=get("src/data/pokemon/evolution.h"); fwd={}
for blk in re.finditer(r'\[SPECIES_([A-Z0-9_]+)\]\s*=\s*\{(.*?)\},?\s*\n(?=\s*(?:\[SPECIES_|\};))',evo,re.S):
    t=re.findall(r'SPECIES_([A-Z0-9_]+)',blk.group(2))
    if t: fwd['SPECIES_'+blk.group(1)]=['SPECIES_'+x for x in t]
parent={t:s for s,v in fwd.items() for t in v}
def rootf(s):
    while s in parent and parent[s] in KS: s=parent[s]
    return s
def famlen(r):
    if r=='SPECIES_EEVEE': return 4
    out=[r];fr=[r]
    while fr:
        nx=[]
        for s in fr:
            for t in fwd.get(s,[]):
                if t in KS and t not in out: out.append(t);nx.append(t)
        fr=nx
    return len(out)
si=get("src/data/pokemon/species_info.h"); types={}
for blk in re.split(r'(?=\[SPECIES_[A-Z0-9_]+\]\s*=\s*\{)',si):
    hm=re.match(r'\[SPECIES_([A-Z0-9_]+)\]',blk)
    if not hm: continue
    tm=re.search(r'\.types\s*=\s*\{\s*TYPE_(\w+)\s*,\s*TYPE_(\w+)',blk)
    if tm: types['SPECIES_'+hm.group(1)]=(tm.group(1).title(),tm.group(2).title())
def disp(s): return s.replace('SPECIES_','').title().replace('_',' ').replace('Nidoran M','Nidoran♂').replace('Nidoran F','Nidoran♀').replace('Mr Mime','Mr. Mime').replace('Farfetchd',"Farfetch'd")
species=[]
for i,s in enumerate(K,1):
    t1,t2=types.get(s,('Normal','Normal'))
    r=rootf(s)
    species.append({"id":i,"name":disp(s),"type1":t1,"type2":(None if t2==t1 else t2),
                    "familyRoot":disp(r),"lineStages":famlen(r)})
json.dump(species,open(RES+"species.json","w"),ensure_ascii=False,indent=1)

# --- roster from Team & Boxes ---
names={disp(s) for s in K}
tb=open("/Users/ronnie/Obsidian/Pokemon/FireRed/Player/Team & Boxes.md").read()
roster=[]; section=None
for line in tb.splitlines():
    if line.startswith("## 👥"): section="party"; continue
    if line.startswith("## 📦"): section="box"; continue
    if line.startswith("## 📝"): section=None; continue
    if section and line.lstrip().startswith("|"):
        c=[x.strip() for x in line.strip().strip("|").split("|")]
        if len(c)<4 or c[1] not in names: continue
        moves=[m for m in c[4:8] if m and m!="—"] if len(c)>=8 else []
        item=c[8] if len(c)>8 and c[8] not in("","—") else None
        lv=int(c[3]) if c[3].isdigit() else 0
        roster.append({"species":c[1],"level":lv,"moves":moves,"heldItem":item,"container":section})
json.dump(roster,open(RES+"roster.json","w"),ensure_ascii=False,indent=1)
print("species:",len(species)," roster:",len(roster))
print("sample:",species[0], "|", roster[0] if roster else "none")
