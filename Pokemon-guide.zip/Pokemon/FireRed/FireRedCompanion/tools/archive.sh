#!/bin/bash
# Build a release binary and archive it, then git-commit + tag the version.
# Usage: tools/archive.sh <version>   e.g. tools/archive.sh 0.2.0
set -e
V="${1:?usage: archive.sh <version>}"
cd "$(dirname "$0")/.."
echo "$V" > VERSION
swift build -c release
BIN=.build/release
OUT="Archives/FireRedCompanion-v$V"
rm -rf "$OUT" && mkdir -p "$OUT"
cp "$BIN/FireRedCompanion" "$OUT/" 2>/dev/null || true
# copy the SwiftPM resource bundle if present
cp -R "$BIN"/FireRedCompanion_*.bundle "$OUT/" 2>/dev/null || true
( cd Archives && zip -qr "FireRedCompanion-v$V.zip" "FireRedCompanion-v$V" && rm -rf "FireRedCompanion-v$V" )
echo "archived Archives/FireRedCompanion-v$V.zip"
git add -A
git commit -q -m "v$V" || echo "(nothing to commit)"
git tag -f "v$V"
echo "committed + tagged v$V"
