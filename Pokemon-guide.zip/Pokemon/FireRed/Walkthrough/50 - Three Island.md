# 50 — Three Island

*A town menaced by a biker gang — and the path to Berry Forest.*

![[50 - Three Island.svg]]
*Three Island*

![[50 - Bond Bridge.svg]]
*Bond Bridge*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Harbor / Port</td><td style="padding:5px;color:#212121;">Ferry</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;">Bond Bridge → Berry Forest</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">29/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Oddish 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gloom 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">36</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">34/37/40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Venonat</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">37/40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">95%</td><td style="padding:5px;color:#212121;">5–20/20–35/35–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacruel</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Zinc · Hidden: PP Up</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Bond Bridge hidden: Max Repel, Pearl, Stardust</td></tr>
</table>

> [!todo] Do this in order
> 1. Beat the biker gang harassing the town
> 2. Beat the Bond Bridge trainers (numbered on the map)
> 3. Cross to Berry Forest

A **biker gang** is harassing a local — beat them to clear the town:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Three Island & Bond Bridge</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Aroma Lady Nikki</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">666</td><td style="padding:5px;color:#212121;">Stun Spore, Acid, Sweet Scent, Razor Leaf</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 84 · Atk 60 · Def 30 · Sp.Atk 56 · Sp.Def 27 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weepinbell</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1197</td><td style="padding:5px;color:#212121;">Poison Powder, Stun Spore, Acid, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 71 · Def 42 · Sp.Atk 67 · Sp.Def 38 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1036</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Tuber Amira</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">561</td><td style="padding:5px;color:#212121;">Water Gun, Double Slap, Rain Dance, Body Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 71 · Atk 39 · Def 32 · Sp.Atk 32 · Sp.Def 32 · Speed 66</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">982</td><td style="padding:5px;color:#212121;">Water Gun, Double Slap, Rain Dance, Body Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 90 · Atk 50 · Def 50 · Sp.Atk 40 · Sp.Def 40 · Speed 68</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">561</td><td style="padding:5px;color:#212121;">Water Gun, Double Slap, Rain Dance, Body Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 71 · Atk 39 · Def 32 · Sp.Atk 32 · Sp.Def 32 · Speed 66</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽140</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Swimmer F Tisha</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kingler</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1677</td><td style="padding:5px;color:#212121;">Harden, Mud Shot, Stomp, Guillotine</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 89 · Atk 103 · Def 92 · Sp.Atk 43 · Sp.Def 43 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽152</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Tuber Alexis</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">771</td><td style="padding:5px;color:#212121;">Camouflage, Swift, Bubble Beam, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 35 · Def 42 · Sp.Atk 52 · Sp.Def 42 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">771</td><td style="padding:5px;color:#212121;">Camouflage, Swift, Bubble Beam, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 35 · Def 42 · Sp.Atk 52 · Sp.Def 42 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">837</td><td style="padding:5px;color:#212121;">Harden, Mud Shot, Stomp, Guillotine</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 76 · Def 66 · Sp.Atk 22 · Sp.Def 22 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">837</td><td style="padding:5px;color:#212121;">Harden, Mud Shot, Stomp, Guillotine</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 76 · Def 66 · Sp.Atk 22 · Sp.Def 22 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽136</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Aroma Lady Violet</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bulbasaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">493</td><td style="padding:5px;color:#212121;">Sleep Powder, Razor Leaf, Sweet Scent, Growth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 40 · Def 40 · Sp.Atk 51 · Sp.Def 51 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ivysaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">1087</td><td style="padding:5px;color:#212121;">Poison Powder, Sleep Powder, Razor Leaf, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 89 · Atk 49 · Def 50 · Sp.Atk 62 · Sp.Def 62 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ivysaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">1087</td><td style="padding:5px;color:#212121;">Poison Powder, Sleep Powder, Razor Leaf, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 89 · Atk 49 · Def 50 · Sp.Atk 62 · Sp.Def 62 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1008</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Twins Joy & Meg</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">538</td><td style="padding:5px;color:#212121;">Defense Curl, Metronome, Cosmic Power, Moonlight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 38 · Def 40 · Sp.Atk 49 · Sp.Def 53 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">538</td><td style="padding:5px;color:#212121;">Defense Curl, Metronome, Cosmic Power, Moonlight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 38 · Def 40 · Sp.Atk 49 · Sp.Def 53 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽444</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Twins Joy & Meg</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">538</td><td style="padding:5px;color:#212121;">Defense Curl, Metronome, Cosmic Power, Moonlight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 38 · Def 40 · Sp.Atk 49 · Sp.Def 53 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">538</td><td style="padding:5px;color:#212121;">Defense Curl, Metronome, Cosmic Power, Moonlight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 38 · Def 40 · Sp.Atk 49 · Sp.Def 53 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽444</td></tr>
</table>

West across **Bond Bridge** (wild Pidgeotto, Oddish, Venonat) lies **[[51 - Berry Forest]]**.

⬅️ **Prev:** [[49 - Two Island]] · ➡️ **Next:** [[51 - Berry Forest]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
