# 19 — Route 9

*A rugged path east of Cerulean toward Rock Tunnel.*

![[19 - Route 9.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="11 - Cerulean City" data-href="11 - Cerulean City">Cerulean City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="20 - Route 10" data-href="20 - Route 10">Route 10</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">13/16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">14/16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ekans 🔴</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">11/13/15/17</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">TM40 Aerial Ace</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Burn Heal</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Ether, Rare Candy, Chesto Berry</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— none new</td></tr>
</table>

> [!todo] Do this in order
> 1. Grab TM40 Aerial Ace
> 2. Beat trainers 1–9 (numbered on the map)
> 3. Sweep the hidden items
> 4. Continue east to Route 10

Route 9 is a rocky trail east of Cerulean. Grab **TM40 Aerial Ace** (a reliable, never-miss Flying move — great on your Fearow/Pidgeot). Work through the trainers:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 9</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Picnicker Alicia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">300</td><td style="padding:5px;color:#212121;">Sweet Scent, Poison Powder, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 23 · Def 24 · Sp.Atk 32 · Sp.Def 28 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">324</td><td style="padding:5px;color:#212121;">Growth, Wrap, Sleep Powder, Poison Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 32 · Def 17 · Sp.Atk 30 · Sp.Def 15 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">300</td><td style="padding:5px;color:#212121;">Sweet Scent, Poison Powder, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 23 · Def 24 · Sp.Atk 32 · Sp.Def 28 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">324</td><td style="padding:5px;color:#212121;">Growth, Wrap, Sleep Powder, Poison Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 32 · Def 17 · Sp.Atk 30 · Sp.Def 15 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽360</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Hiker Jeremy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">376</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Karate Chop, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 37 · Def 25 · Sp.Atk 19 · Sp.Def 19 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">462</td><td style="padding:5px;color:#212121;">Screech, Bind, Rock Throw, Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 23 · Def 69 · Sp.Atk 17 · Sp.Def 23 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Camper Chris</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">409</td><td style="padding:5px;color:#212121;">Roar, Ember, Leer, Odor Sleuth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 34 · Def 23 · Sp.Atk 34 · Sp.Def 26 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">292</td><td style="padding:5px;color:#212121;">Growl, Ember, Metal Claw, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 26 · Def 23 · Sp.Atk 30 · Sp.Def 26 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽420</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Bug Catcher Brent</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Beedrill</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">646</td><td style="padding:5px;color:#212121;">Fury Attack, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 35 · Def 20 · Sp.Atk 22 · Sp.Def 35 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Beedrill</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">646</td><td style="padding:5px;color:#212121;">Fury Attack, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 35 · Def 20 · Sp.Atk 22 · Sp.Def 35 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽228</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Camper Drew</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">231</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 26 · Def 18 · Sp.Atk 14 · Sp.Def 18 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandshrew</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">378</td><td style="padding:5px;color:#212121;">Scratch, Defense Curl, Sand Attack, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 33 · Def 37 · Sp.Atk 12 · Sp.Def 16 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">252</td><td style="padding:5px;color:#212121;">Wrap, Leer, Poison Sting, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 27 · Def 21 · Sp.Atk 20 · Sp.Def 25 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandshrew</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">378</td><td style="padding:5px;color:#212121;">Scratch, Defense Curl, Sand Attack, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 33 · Def 37 · Sp.Atk 12 · Sp.Def 16 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽380</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Bug Catcher Conner</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">226</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 17 · Def 19 · Sp.Atk 13 · Sp.Def 13 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">222</td><td style="padding:5px;color:#212121;">Poison Sting, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 19 · Def 17 · Sp.Atk 13 · Sp.Def 13 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Venonat</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">321</td><td style="padding:5px;color:#212121;">Foresight, Supersonic, Confusion, Poison Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 27 · Def 25 · Sp.Atk 21 · Sp.Def 27 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽240</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Hiker Brice</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">367</td><td style="padding:5px;color:#212121;">Defense Curl, Mud Sport, Rock Throw, Magnitude</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 37 · Def 45 · Sp.Atk 17 · Sp.Def 17 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">376</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Karate Chop, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 37 · Def 25 · Sp.Atk 19 · Sp.Def 19 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">367</td><td style="padding:5px;color:#212121;">Defense Curl, Mud Sport, Rock Throw, Magnitude</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 37 · Def 45 · Sp.Atk 17 · Sp.Def 17 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Picnicker Caitlin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">339</td><td style="padding:5px;color:#212121;">Scratch, Growl, Bite, Pay Day</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 25 · Def 21 · Sp.Atk 23 · Sp.Def 23 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽460</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Hiker Alan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">387</td><td style="padding:5px;color:#212121;">Magnitude, Rock Throw, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 38 · Def 47 · Sp.Atk 17 · Sp.Def 17 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">486</td><td style="padding:5px;color:#212121;">Harden, Rock Throw, Bind, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 23 · Def 72 · Sp.Atk 17 · Sp.Def 23 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽756</td></tr>
</table>

Sweep for the hidden **Ether, Rare Candy, and Chesto Berry**, then continue **east to [[20 - Route 10]]**.

⬅️ **Prev:** [[18 - Diglett’s Cave]] · ➡️ **Next:** [[20 - Route 10]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
