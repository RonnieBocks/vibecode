# 07 — Pewter City

*A city of stone — home to Brock and the Boulder Badge.*

![[07 - Pewter City.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;">Route 3 → Mt. Moon</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="06 - Viridian Forest" data-href="06 - Viridian Forest">Viridian Forest</a> / Route 2</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">From Brock (beat the Gym): <b>Boulder Badge</b> · <b>TM39 Rock Tomb</b> — and your first TM auto-adds the <b>TM Case</b> Key Item</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Poké Ball</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Old Amber — Museum, needs Cut (later)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Running Shoes — from Oak’s Aide (east exit)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— none</td></tr>
</table>

> [!todo] Do this in order
> 1. Heal and stock up at the Mart
> 2. Beat the gym trainer, then Brock
> 3. Grab the Running Shoes heading east
> 4. Continue to Route 3

Heal, and **stock up** at the Mart (Poké Balls, Potions, Antidotes) — no shop again until Cerulean. The Museum holds the **Old Amber** for later (needs Cut).

**Pewter Gym — Brock (Rock).** One trainer, then the leader:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ PEWTER GYM — Brock (Boulder Badge)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Camper Liam</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">183</td><td style="padding:5px;color:#212121;">Tackle, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 28 · Atk 21 · Def 25 · Sp.Atk 11 · Sp.Def 11 · Speed 9</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandshrew</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">11</td><td style="padding:5px;color:#212121;">219</td><td style="padding:5px;color:#212121;">Scratch, Defense Curl, Sand Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 32 · Atk 21 · Def 23 · Sp.Atk 9 · Sp.Def 11 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽220</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Leader Brock</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">12</td><td style="padding:5px;color:#212121;">220</td><td style="padding:5px;color:#212121;">Tackle, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 31 · Atk 24 · Def 29 · Sp.Atk 12 · Sp.Def 12 · Speed 9</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">14</td><td style="padding:5px;color:#212121;">324</td><td style="padding:5px;color:#212121;">Tackle, Bind, Rock Tomb</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 33 · Atk 17 · Def 49 · Sp.Atk 13 · Sp.Def 17 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1400</td></tr>
</table>

**Onix** has huge Defense but low HP/Sp.Def — special **Water/Grass** melt it. Charmander users: bring **Mankey** (Low Kick) or **Butterfree** (Confusion). Beating Brock gives the **Boulder Badge**, **TM39 Rock Tomb**, and the **TM Case**.

Heading **east to Route 3**, **Oak’s Aide** gives the **Running Shoes** (hold B to run). Continue to [[08 - Route 3]].

⬅️ **Prev:** [[06 - Viridian Forest]] · ➡️ **Next:** [[08 - Route 3]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- ~~183 XP for beating Geodude against Liam~~ — ✅ matches after the exp fix
- ~~219 XP for beating Sandshrew against Liam~~ — ✅ matches after the exp fix
- ~~220 XP for beating Geodude against Brock~~ — ✅ matches after the exp fix
- ~~324 XP for beating Onix against Brock~~ — ✅ matches after the exp fix
- ~~This walkthrough doesn't list the Boulder Badge, TM39, or TM case as items in the Item Table at the top of this file, like it should.~~ — ✅ added Boulder Badge, TM39 Rock Tomb & the TM Case to the item table
