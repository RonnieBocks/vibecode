# 05 — Route 2

*The wooded corridor linking Viridian to Pewter.*

![[05 - Route 2.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="07 - Pewter City" data-href="07 - Pewter City">Pewter City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="03 - Viridian City" data-href="03 - Viridian City">Viridian City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Building (E)</td><td style="padding:5px;color:#212121;">Diglett’s Cave (later)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">45%</td><td style="padding:5px;color:#212121;">2/3/4/5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">45%</td><td style="padding:5px;color:#212121;">2/3/4/5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">4/5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">4/5</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Ether — behind a Cut tree (later)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Paralyze Heal — behind a Cut tree (later)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Caterpie</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Weedle</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Caterpie → Metapod → Butterfree** — keep **3**
> - **Weedle → Kakuna → Beedrill** — keep **3**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Note the Cut-blocked items (come back later)
> 2. Enter Viridian Forest to head north

Route 2 is split by ledges and **Cut trees**. Coming from Viridian, the **Viridian Forest** gate is at the top of the southern stretch — go through the forest and you’ll come out on the northern stretch to Pewter.

The **Ether** and **Paralyze Heal** here sit behind **Cut trees** — grab them once you have Cut. The east building leads to **Diglett’s Cave** (later). Enter the forest: **[[06 - Viridian Forest]]**.

⬅️ **Prev:** [[04 - Route 22]] · ➡️ **Next:** [[06 - Viridian Forest]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
