# 57 — Seven Island

*Sevault Canyon, the Unown-filled Tanoby Ruins, and the Trainer Tower.*

![[57 - Seven Island.svg]]
*Seven Island*

![[57 - Sevault Canyon.svg]]
*Sevault Canyon*

![[57 - Tanoby Ruins.svg]]
*Tanoby Ruins*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Harbor</td><td style="padding:5px;color:#212121;">Ferry</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Canyon</td><td style="padding:5px;color:#212121;">Sevault Canyon → Tanoby Key</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Ruins</td><td style="padding:5px;color:#212121;">Tanoby Ruins (Unown)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk CANYON</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Phanpy</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">50</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">52</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">43</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">54</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Skarmory</td><td style="padding:5px;color:#212121;">Steel/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Larvitar</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">15/20</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">49/52</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🪨 Rock Smash CANYON</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">65%</td><td style="padding:5px;color:#212121;">25–35/30–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">30–45/35–50</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk CHAMBER</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Unown</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">25</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Sevault Canyon: King’s Rock, Max Elixir, Nugget</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Tanoby Ruins hidden: Heart Scales ×4</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Sevault Canyon House: the Tanoby Key</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Unown (26 forms — post-National-Dex)</td></tr>
</table>

> [!todo] Do this in order
> 1. Explore Sevault Canyon; grab the Tanoby Key
> 2. Use the Key to unlock the Tanoby Ruins chambers
> 3. Catch Unown (each chamber holds different letters)
> 4. Optionally challenge the Trainer Tower

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Sevault Canyon</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Pkmn Ranger Jackson</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tangela</td><td style="padding:5px;color:#212121;">Grass</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1743</td><td style="padding:5px;color:#212121;">Slam, Mega Drain, Bind, Ingrain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 171 · Atk 107 · Def 166 · Sp.Atk 152 · Sp.Def 93 · Speed 112</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1029</td><td style="padding:5px;color:#212121;">Confusion, Poison Powder, Barrage, Reflect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 166 · Atk 93 · Def 132 · Sp.Atk 112 · Sp.Def 98 · Speed 93</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggutor</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">2226</td><td style="padding:5px;color:#212121;">Confusion, Egg Bomb, Sleep Powder, Stomp</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 201 · Atk 147 · Def 137 · Sp.Atk 176 · Sp.Def 117 · Speed 107</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1764</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Tamer Evan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1675</td><td style="padding:5px;color:#212121;">Poison Sting, Slash, Swift, Fury Swipes</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 149 · Atk 120 · Def 129 · Sp.Atk 67 · Sp.Def 77 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Lickitung</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1305</td><td style="padding:5px;color:#212121;">Wrap, Disable, Slam, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 163 · Atk 77 · Def 96 · Sp.Atk 81 · Sp.Def 96 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ursaring</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1984</td><td style="padding:5px;color:#212121;">Rest, Slash, Snore, Thrash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 166 · Atk 152 · Def 98 · Sp.Atk 98 · Sp.Def 98 · Speed 78</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1960</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Pkmn Ranger Katelyn</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Chansey</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">52</td><td style="padding:5px;color:#212121;">2841</td><td style="padding:5px;color:#212121;">Egg Bomb, Defense Curl, Minimize, Soft Boiled</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 374 · Atk 62 · Def 62 · Sp.Atk 93 · Sp.Def 166 · Speed 109</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1872</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Crush Girl Cyndy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1531</td><td style="padding:5px;color:#212121;">Seismic Toss, Rage, Cross Chop, Swagger</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 144 · Atk 129 · Def 86 · Sp.Atk 86 · Sp.Def 96 · Speed 120</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmontop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1419</td><td style="padding:5px;color:#212121;">Rapid Spin, Counter, Agility, Detect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 130 · Atk 120 · Def 120 · Sp.Atk 62 · Sp.Def 134 · Speed 96</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1501</td><td style="padding:5px;color:#212121;">Revenge, Vital Throw, Submission, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 158 · Atk 125 · Def 96 · Sp.Atk 77 · Sp.Def 86 · Speed 72</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1152</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Cooltrainer Leroy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhydon</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">2053</td><td style="padding:5px;color:#212121;">Take Down, Horn Drill, Rock Blast, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 202 · Atk 174 · Def 164 · Sp.Atk 94 · Sp.Def 94 · Speed 89</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowbro</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1686</td><td style="padding:5px;color:#212121;">Psychic, Headbutt, Amnesia, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 197 · Atk 125 · Def 158 · Sp.Atk 149 · Sp.Def 129 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kangaskhan</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1762</td><td style="padding:5px;color:#212121;">Dizzy Punch, Bite, Endure, Reversal</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 202 · Atk 141 · Def 127 · Sp.Atk 89 · Sp.Def 127 · Speed 136</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1501</td><td style="padding:5px;color:#212121;">Cross Chop, Vital Throw, Revenge, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 182 · Atk 149 · Def 120 · Sp.Atk 101 · Sp.Def 110 · Speed 96</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ursaring</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">2025</td><td style="padding:5px;color:#212121;">Slash, Faint Attack, Snore, Rest</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 200 · Atk 185 · Def 130 · Sp.Atk 130 · Sp.Def 130 · Speed 110</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Cooltrainer Michelle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1489</td><td style="padding:5px;color:#212121;">Slash, Screech, Faint Attack, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 165 · Atk 117 · Def 108 · Sp.Atk 113 · Sp.Def 113 · Speed 160</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dewgong</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1771</td><td style="padding:5px;color:#212121;">Ice Beam, Take Down, Icy Wind, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 188 · Atk 117 · Def 127 · Sp.Atk 117 · Sp.Def 141 · Speed 117</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ninetales</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1830</td><td style="padding:5px;color:#212121;">Flamethrower, Confuse Ray, Will O Wisp, Grudge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 176 · Atk 125 · Def 125 · Sp.Atk 130 · Sp.Def 149 · Speed 149</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rapidash</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1974</td><td style="padding:5px;color:#212121;">Bounce, Agility, Fire Spin, Take Down</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 168 · Atk 149 · Def 120 · Sp.Atk 129 · Sp.Def 129 · Speed 153</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Girafarig</td><td style="padding:5px;color:#212121;">Normal/Psychic</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1596</td><td style="padding:5px;color:#212121;">Crunch, Psybeam, Stomp, Odor Sleuth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 180 · Atk 135 · Def 120 · Sp.Atk 145 · Sp.Def 120 · Speed 140</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Cool Couple Lex & Nya</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Miltank</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">52</td><td style="padding:5px;color:#212121;">2227</td><td style="padding:5px;color:#212121;">Body Slam, Milk Drink, Growl, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 212 · Atk 140 · Def 166 · Sp.Atk 98 · Sp.Def 129 · Speed 161</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tauros</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">52</td><td style="padding:5px;color:#212121;">2350</td><td style="padding:5px;color:#212121;">Thrash, Horn Attack, Pursuit, Swagger</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 192 · Atk 161 · Def 155 · Sp.Atk 98 · Sp.Def 129 · Speed 171</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1248</td></tr>
</table>

The final island. **Sevault Canyon** (Rock Smash + Strength) holds strong wild Pokémon (Onix, Marowak, plus Johto’s Larvitar/Skarmory/Phanpy) and, in a house, the **Tanoby Key**.

Using the Key opens the seven **Tanoby Ruins** chambers out in the water, each home to wild **Unown** — the puzzle Pokémon with 26 letter forms (catch them all for the Unown Dex). The ruins’ floors hide **Heart Scales** (for the Move Reminder).

The **Trainer Tower** (far end) is an optional battle facility — clear its floors against the clock for prizes. That’s the last of the Sevii Islands — with both gems delivered, the National Dex, and the legendaries caught, your Kanto journey (and the road to a full Living Dex) is complete.

The **Tanoby Ruins** approach has optional trainers:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Tanoby Ruins</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Gentleman Clifford</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1302</td><td style="padding:5px;color:#212121;">Bonemerang, Rage, False Swipe, Thrash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 117 · Atk 83 · Def 112 · Sp.Atk 54 · Sp.Def 83 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golduck</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1827</td><td style="padding:5px;color:#212121;">Confusion, Screech, Psych Up, Fury Swipes</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 137 · Atk 85 · Def 81 · Sp.Atk 98 · Sp.Def 83 · Speed 88</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽3528</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Ruin Maniac Brandon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1156</td><td style="padding:5px;color:#212121;">Dragon Breath, Sandstorm, Slam, Iron Tail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 50 · Def 165 · Sp.Atk 35 · Sp.Def 50 · Speed 75</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2400</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Painter Edna</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Smeargle</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1135</td><td style="padding:5px;color:#212121;">Fake Out, Extreme Speed, Protect, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 50 · Def 65 · Sp.Atk 50 · Sp.Def 75 · Speed 105</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Ruin Maniac Benjamin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">883</td><td style="padding:5px;color:#212121;">Earthquake, Rock Blast, Rollout, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 96 · Atk 81 · Def 101 · Sp.Atk 33 · Sp.Def 33 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1377</td><td style="padding:5px;color:#212121;">Earthquake, Rock Blast, Rock Throw, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 110 · Atk 96 · Def 115 · Sp.Atk 48 · Sp.Def 48 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1377</td><td style="padding:5px;color:#212121;">Earthquake, Rock Blast, Rock Throw, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 110 · Atk 96 · Def 115 · Sp.Atk 48 · Sp.Def 48 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2304</td></tr>
</table>

⬅️ **Prev:** [[56 - Six Island]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
