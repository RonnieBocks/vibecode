# 02 — Route 1

*Your first stretch of tall grass on the road north.*

![[02 - Route 1.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="03 - Viridian City" data-href="03 - Viridian City">Viridian City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="01 - Pallet Town" data-href="01 - Pallet Town">Pallet Town</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">50%</td><td style="padding:5px;color:#212121;">2/3/4/5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">50%</td><td style="padding:5px;color:#212121;">2/3/4</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Potion (free — from the Mart clerk)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Pidgey</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Rattata</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Pidgey → Pidgeotto → Pidgeot** — keep **3**
> - **Rattata → Raticate** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Take the free Potion from the Mart clerk
> 2. Catch a Pidgey and a Rattata
> 3. Head north to Viridian City

Head north. A **Poké Mart clerk** stops you and gives a **free Potion**. No trainers here — just grass.

On your **first** pass you have **no Poké Balls yet** (you get 5 with the Pokédex, after the Viridian parcel run), so just walk through now. **Coming back**, catch the two locals for your dex: **Pidgey** (→ Pidgeot) and **Rattata** (→ Raticate) — weaken with a light hit, then toss a ball. Continue **north into [[03 - Viridian City]]**.

> [!tip] Don’t over-level — the gym here is locked; your next fights are in Viridian Forest.

⬅️ **Prev:** [[01 - Pallet Town]] · ➡️ **Next:** [[03 - Viridian City]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- ~~On the first entrance to Route 1, Red has no Pokeballs, therefore he can't catch any pokemon on this section yet.~~ — ✅ note added: walk through first, catch Pidgey/Rattata on the way back