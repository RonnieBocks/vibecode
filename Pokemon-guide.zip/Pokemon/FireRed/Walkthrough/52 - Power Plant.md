# 52 — Power Plant

*A derelict plant crackling with Electric Pokémon — and Zapdos.*

![[52 - Power Plant.svg]]
*Power Plant*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance</td><td style="padding:5px;color:#212121;">Route 10 (Surf)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">22/25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">22/25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">22/24/26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">31/34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Electabuzz 🔴</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">32/35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Max Potion, TM17 Protect, TM25 Thunder, Thunder Stone, Elixir</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Max Elixir, Thunder Stone</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">2 disguised Electrode (static battles)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Magneton</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Electabuzz 🔴</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Zapdos</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Magnemite → Magneton** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Surf to the Power Plant from Route 10
> 2. Catch Magnemite/Voltorb/Pikachu/Electabuzz
> 3. Watch for the two disguised Electrode
> 4. Catch Zapdos (Lv 50)

Back in Kanto: Surf to the **Power Plant** off Route 10. It’s full of Electric-types — catch **Electabuzz** 🔴 (FireRed exclusive), **Magneton**, and more. Two “item balls” are actually **disguised Electrode** that battle you.

The legendary **Zapdos (Lv 50)** waits inside — save, status/weaken it, and throw Ultra Balls (Electric/Flying, so use Rock/Ice). Grab the **Thunder Stone** (for your Raichu) and **TM25 Thunder** while you’re here.

⬅️ **Prev:** [[51 - Berry Forest]] · ➡️ **Next:** [[53 - Cerulean Cave]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
