# 41 — Seafoam Islands

*An icy sea cave of boulder puzzles — and the legendary Articuno.*

![[41 - Seafoam Islands 1F.svg]]
*1F*

![[41 - Seafoam Islands B1F.svg]]
*B1F*

![[41 - Seafoam Islands B2F.svg]]
*B2F*

![[41 - Seafoam Islands B3F.svg]]
*B3F*

![[41 - Seafoam Islands B4F.svg]]
*B4F*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance (Route 20)</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="40 - Sea Route 20" data-href="40 - Sea Route 20">Sea Route 20</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Exit</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="42 - Cinnabar Island" data-href="42 - Cinnabar Island">Cinnabar Island</a> (Route 20 west)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">55%</td><td style="padding:5px;color:#212121;">26/27/29/31/33</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">34%</td><td style="padding:5px;color:#212121;">22/24/26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">11%</td><td style="padding:5px;color:#212121;">26/28/30</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">29/31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">34%</td><td style="padding:5px;color:#212121;">22/24/26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">11%</td><td style="padding:5px;color:#212121;">26/28/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">33/35</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk B2F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">22/24</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">26/28/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">32/34</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk B3F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">32/34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">24</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">26/28/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Dewgong</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">32/34</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf B3F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">25–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Dewgong</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">35–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">30–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod B3F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod B3F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod B3F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">15–25/20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">16%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk B4F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">50%</td><td style="padding:5px;color:#212121;">30/32/34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">32/34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">26/28/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Dewgong</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">34/36</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf B4F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">25–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Dewgong</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">35–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">30–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod B4F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod B4F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod B4F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">15–25/20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">16%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">1F: Ice Heal</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B1F: Water Stone, Revive</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B2F: Big Pearl</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B3F hidden: Nugget</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B4F: Ultra Ball · Hidden: Water Stone</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Articuno (Lv 50 — bottom floor)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Seel</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Dewgong</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Articuno</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Seel → Dewgong** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Bring Surf + Strength
> 2. Push boulders into the holes to slow the currents
> 3. Catch Seel/Dewgong; grab the Water Stones
> 4. Reach the bottom floor and catch Articuno (Lv 50)
> 5. Exit toward Cinnabar

Seafoam is a **Strength boulder puzzle**: push the boulders into the holes on each floor to calm the water currents so you can Surf down to the bottom. Catch **Seel** (→ Dewgong) and grab two **Water Stones** along the way.

At the very bottom, the legendary bird **Articuno (Lv 50)** waits:

- **Save first.** Lower its HP carefully (it resists nothing you'll spam — use a strong neutral attacker), inflict **Sleep or Paralysis**, and throw **Ultra Balls**. It has Ice/Flying typing, so avoid Fire/Electric/Rock overkill.

Then continue to **[[42 - Cinnabar Island]]**.

⬅️ **Prev:** [[40 - Sea Route 20]] · ➡️ **Next:** [[42 - Cinnabar Island]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
