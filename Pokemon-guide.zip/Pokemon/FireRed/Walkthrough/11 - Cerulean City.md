# 11 — Cerulean City

*A city of water, a robbed house, and Misty’s Cascade Badge.*

![[11 - Cerulean City.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="12 - Route 24" data-href="12 - Route 24">Route 24</a> (Nugget Bridge)</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="14 - Route 5" data-href="14 - Route 5">Route 5</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="09 - Route 4" data-href="09 - Route 4">Route 4</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;">Route 9</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">84%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Rare Candy (behind the top-left house)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">TM28 Dig (after the robbed-house Rocket)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Bicycle (Bike Shop — needs Bike Voucher, later)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Jynx — in-game trade (give a Poliwhirl)</td></tr>
</table>

> [!todo] Do this in order
> 1. Heal & shop
> 2. Beat the robbed-house Rocket → TM28 Dig
> 3. Beat your rival (heading north)
> 4. Beat Misty for the Cascade Badge
> 5. Continue north to Nugget Bridge

Heal and shop (Super Potions now). The **Bike Shop** bike is unaffordable — you’ll get a **Bike Voucher** in Vermilion. A man trades a **Jynx** for a **Poliwhirl**.

A house was **robbed** — beat the Rocket responsible:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TEAM ROCKET — Robbed House</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Team Rocket Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">319</td><td style="padding:5px;color:#212121;">Low Kick, Leer, Focus Energy, Karate Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 50 · Atk 32 · Def 22 · Sp.Atk 16 · Sp.Def 16 · Speed 16</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">370</td><td style="padding:5px;color:#212121;">Hypnosis, Disable, Confusion, Headbutt</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 21 · Def 20 · Sp.Atk 19 · Sp.Def 35 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽544</td></tr>
</table>

Then he flees, opening the path to **TM28 Dig** (up on Route 24/25). Heading north toward Nugget Bridge, your **rival** strikes:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ RIVAL — Cerulean (Nugget Bridge)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Bulbasaur</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">411</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 33 · Def 32 · Sp.Atk 30 · Sp.Def 30 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Abra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">249</td><td style="padding:5px;color:#212121;">Teleport</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 19 · Def 17 · Sp.Atk 46 · Sp.Def 30 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">15</td><td style="padding:5px;color:#212121;">183</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 41 · Atk 29 · Def 23 · Sp.Atk 20 · Sp.Def 23 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">250</td><td style="padding:5px;color:#212121;">Metal Claw, Ember, Growl, Scratch</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 41 · Def 38 · Sp.Atk 44 · Sp.Def 41 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽288</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Charmander</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">411</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 33 · Def 32 · Sp.Atk 30 · Sp.Def 30 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Abra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">249</td><td style="padding:5px;color:#212121;">Teleport</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 19 · Def 17 · Sp.Atk 46 · Sp.Def 30 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">15</td><td style="padding:5px;color:#212121;">183</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 41 · Atk 29 · Def 23 · Sp.Atk 20 · Sp.Def 23 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Squirtle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">253</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Withdraw, Water Gun</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 61 · Atk 40 · Def 46 · Sp.Atk 41 · Sp.Def 46 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽288</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Squirtle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">411</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 33 · Def 32 · Sp.Atk 30 · Sp.Def 30 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Abra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">249</td><td style="padding:5px;color:#212121;">Teleport</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 19 · Def 17 · Sp.Atk 46 · Sp.Def 30 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">15</td><td style="padding:5px;color:#212121;">183</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 41 · Atk 29 · Def 23 · Sp.Atk 20 · Sp.Def 23 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bulbasaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">246</td><td style="padding:5px;color:#212121;">Sleep Powder, Poison Powder, Vine Whip, Leech Seed</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 40 · Def 40 · Sp.Atk 46 · Sp.Def 46 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽288</td></tr>
</table>

**Cerulean Gym — Misty (Water).** Two juniors, then the leader:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ CERULEAN GYM — Misty (Cascade Badge)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Picnicker Diana</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">451</td><td style="padding:5px;color:#212121;">Tail Whip, Water Sport, Supersonic, Horn Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 30 · Def 27 · Sp.Atk 18 · Sp.Def 24 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽380</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Swimmer M Luis</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">283</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 35 · Atk 17 · Def 27 · Sp.Atk 27 · Sp.Def 13 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">331</td><td style="padding:5px;color:#212121;">Tackle, Withdraw, Icicle Spear, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 35 · Atk 25 · Def 37 · Sp.Atk 19 · Sp.Def 13 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽64</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Leader Misty</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">408</td><td style="padding:5px;color:#212121;">Tackle, Harden, Recover, Water Pulse</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 38 · Atk 21 · Def 24 · Sp.Atk 30 · Sp.Def 24 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Starmie</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">931</td><td style="padding:5px;color:#212121;">Swift, Recover, Rapid Spin, Water Pulse</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 36 · Def 40 · Sp.Atk 47 · Sp.Def 40 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2100</td></tr>
</table>

**Grass/Electric** wreck her — a **Pikachu** or **Bulbasaur** makes it easy. Watch **Water Pulse** (confusion) and Starmie’s **Recover**. Winning gives the **Cascade Badge** (lets you use **Cut**) and **TM03 Water Pulse**. Head north to **[[12 - Route 24]]**.

⬅️ **Prev:** [[10 - Mt. Moon]] · ➡️ **Next:** [[12 - Route 24]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- On first enter, the robbed house is blocked. I'm not sure what moves the NPC standing at the door, but I'll add another note when I find out. 
- 
