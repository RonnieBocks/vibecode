# 56 — Six Island

*Paths, Pattern Bush, and the Dotted Hole where the Sapphire hides.*

![[56 - Six Island.svg]]
*Six Island*

![[56 - Water Path.svg]]
*Water Path*

![[56 - Green Path.svg]]
*Green Path*

![[56 - Pattern Bush.svg]]
*Pattern Bush*

![[56 - Ruin Valley.svg]]
*Ruin Valley*

![[56 - Dotted Hole.svg]]
*Dotted Hole*

![[56 - Altering Cave.svg]]
*Altering Cave*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Harbor</td><td style="padding:5px;color:#212121;">Ferry</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Paths</td><td style="padding:5px;color:#212121;">Green Path / Water Path</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Ruin Valley</td><td style="padding:5px;color:#212121;">Dotted Hole (Sapphire)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass PATH</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">44</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Sentret</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">10/15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Oddish 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">44</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">48/50</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">41</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gloom 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">48</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">41</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">47/50</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf PATH</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">95%</td><td style="padding:5px;color:#212121;">5–20/20–35/35–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacruel</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod PATH</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod PATH</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod PATH</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Qwilfish</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass BUSH</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spinarak</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">9/14</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Kakuna</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">9</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">6</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">6</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Heracross</td><td style="padding:5px;color:#212121;">Bug/Fighting</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">15/20/25/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Metapod</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">9</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ledyba</td><td style="padding:5px;color:#212121;">Bug/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">9/14</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass VALLEY</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Natu</td><td style="padding:5px;color:#212121;">Psychic/Flying</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">15/20</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">44</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Yanma</td><td style="padding:5px;color:#212121;">Bug/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">18</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Wooper</td><td style="padding:5px;color:#212121;">Water/Ground</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">49</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">43</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Wobbuffet</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">41</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">49/52</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf VALLEY</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Wooper</td><td style="padding:5px;color:#212121;">Water/Ground</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–20/10–20/15–25/20–25</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod VALLEY</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod VALLEY</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod VALLEY</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass CAVE</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">6/8/10/12/14/16</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Water Path: Elixir, Dragon Scale · Hidden berries</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Ruin Valley: HP Up, Full Restore, Sun Stone</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Green Path hidden: Ultra Ball</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— (Heracross/Natu/Yanma/Wooper etc. are post-National-Dex Johto mons)</td></tr>
</table>

> [!todo] Do this in order
> 1. Cross Green/Water Path (Dragon Scale for Kingdra)
> 2. Clear Pattern Bush (12 trainers; wild Heracross)
> 3. In Ruin Valley, use Cut/Strength to enter the Dotted Hole
> 4. Solve the Braille puzzle for the Sapphire → give to Celio

Six Island’s paths lead to **Pattern Bush**, a bug-filled maze with a dozen trainers and wild **Heracross**:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Pattern Bush</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Pkmn Breeder Allison</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">699</td><td style="padding:5px;color:#212121;">Cosmic Power, Moonlight, Light Screen, Meteor Mash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 62 · Def 65 · Sp.Atk 77 · Sp.Def 81 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">699</td><td style="padding:5px;color:#212121;">Cosmic Power, Moonlight, Light Screen, Meteor Mash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 62 · Def 65 · Sp.Atk 77 · Sp.Def 81 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefable</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1326</td><td style="padding:5px;color:#212121;">Sing, Double Slap, Minimize, Metronome</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 163 · Atk 86 · Def 89 · Sp.Atk 101 · Sp.Def 105 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1344</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Youngster Nash</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weepinbell</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1519</td><td style="padding:5px;color:#212121;">Stun Spore, Acid, Sweet Scent, Razor Leaf</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 89 · Def 52 · Sp.Atk 84 · Sp.Def 47 · Speed 56</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weepinbell</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1519</td><td style="padding:5px;color:#212121;">Stun Spore, Acid, Sweet Scent, Razor Leaf</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 89 · Def 52 · Sp.Atk 84 · Sp.Def 47 · Speed 56</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Victreebel</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">2005</td><td style="padding:5px;color:#212121;">Vine Whip, Sleep Powder, Sweet Scent, Razor Leaf</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 137 · Atk 107 · Def 68 · Sp.Atk 103 · Sp.Def 63 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽784</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Bug Catcher Garret</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Heracross</td><td style="padding:5px;color:#212121;">Bug/Fighting</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">2100</td><td style="padding:5px;color:#212121;">Brick Break, Counter, Take Down, Reversal</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 137 · Atk 127 · Def 78 · Sp.Atk 44 · Sp.Def 98 · Speed 88</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽588</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Lass Joana</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Snubbull</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">661</td><td style="padding:5px;color:#212121;">Lick, Roar, Rage, Take Down</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 117 · Atk 83 · Def 54 · Sp.Atk 44 · Sp.Def 44 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽784</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Camper Riley</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pinsir</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">2100</td><td style="padding:5px;color:#212121;">Brick Break, Guillotine, Submission, Swords Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 122 · Atk 127 · Def 103 · Sp.Atk 58 · Sp.Def 73 · Speed 88</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Heracross</td><td style="padding:5px;color:#212121;">Bug/Fighting</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">2142</td><td style="padding:5px;color:#212121;">Brick Break, Counter, Take Down, Reversal</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 130 · Def 80 · Sp.Atk 45 · Sp.Def 100 · Speed 90</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1000</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Bug Catcher Jonah</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Yanma</td><td style="padding:5px;color:#212121;">Bug/Flying</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1417</td><td style="padding:5px;color:#212121;">Detect, Uproar, Wing Attack, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 113 · Atk 63 · Def 45 · Sp.Atk 72 · Sp.Def 45 · Speed 90</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Beedrill</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1533</td><td style="padding:5px;color:#212121;">Pursuit, Pin Missile, Agility, Endeavor</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 113 · Atk 77 · Def 41 · Sp.Atk 45 · Sp.Def 77 · Speed 72</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Yanma</td><td style="padding:5px;color:#212121;">Bug/Flying</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">1449</td><td style="padding:5px;color:#212121;">Detect, Uproar, Wing Attack, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 115 · Atk 64 · Def 46 · Sp.Atk 74 · Sp.Def 46 · Speed 92</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Beedrill</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1600</td><td style="padding:5px;color:#212121;">Pursuit, Pin Missile, Agility, Endeavor</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 80 · Def 42 · Sp.Atk 47 · Sp.Def 80 · Speed 75</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽564</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Pkmn Breeder Bethany</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Chansey</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">2731</td><td style="padding:5px;color:#212121;">Sing, Egg Bomb, Defense Curl, Light Screen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 325 · Atk 25 · Def 25 · Sp.Atk 55 · Sp.Def 125 · Speed 70</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1400</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Ruin Maniac Layton</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1675</td><td style="padding:5px;color:#212121;">Poison Sting, Slash, Swift, Fury Swipes</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 130 · Atk 101 · Def 110 · Sp.Atk 48 · Sp.Def 57 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1110</td><td style="padding:5px;color:#212121;">Dragon Breath, Sandstorm, Slam, Iron Tail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 48 · Def 158 · Sp.Atk 33 · Sp.Def 48 · Speed 72</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1675</td><td style="padding:5px;color:#212121;">Poison Sting, Slash, Swift, Fury Swipes</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 130 · Atk 101 · Def 110 · Sp.Atk 48 · Sp.Def 57 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2304</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Youngster Cordell</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Farfetchd</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">966</td><td style="padding:5px;color:#212121;">Swords Dance, Agility, Slash, False Swipe</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 107 · Atk 67 · Def 57 · Sp.Atk 60 · Sp.Def 64 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Farfetchd</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">966</td><td style="padding:5px;color:#212121;">Swords Dance, Agility, Slash, False Swipe</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 107 · Atk 67 · Def 57 · Sp.Atk 60 · Sp.Def 64 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Lass Dalia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hoppip</td><td style="padding:5px;color:#212121;">Grass/Flying</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">729</td><td style="padding:5px;color:#212121;">Sleep Powder, Leech Seed, Cotton Spore, Mega Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 88 · Atk 37 · Def 41 · Sp.Atk 37 · Sp.Def 55 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hoppip</td><td style="padding:5px;color:#212121;">Grass/Flying</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">744</td><td style="padding:5px;color:#212121;">Sleep Powder, Leech Seed, Cotton Spore, Mega Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 89 · Atk 37 · Def 42 · Sp.Atk 37 · Sp.Def 56 · Speed 52</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Skiploom</td><td style="padding:5px;color:#212121;">Grass/Flying</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1369</td><td style="padding:5px;color:#212121;">Sleep Powder, Leech Seed, Cotton Spore, Mega Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 108 · Atk 47 · Def 52 · Sp.Atk 47 · Sp.Def 66 · Speed 80</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Skiploom</td><td style="padding:5px;color:#212121;">Grass/Flying</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1398</td><td style="padding:5px;color:#212121;">Sleep Powder, Leech Seed, Cotton Spore, Mega Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 110 · Atk 48 · Def 53 · Sp.Atk 48 · Sp.Def 67 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Bug Catcher Vance</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Venonat</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">771</td><td style="padding:5px;color:#212121;">Stun Spore, Psybeam, Sleep Powder, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 115 · Atk 57 · Def 53 · Sp.Atk 43 · Sp.Def 57 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Venomoth</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1419</td><td style="padding:5px;color:#212121;">Stun Spore, Gust, Psybeam, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 125 · Atk 67 · Def 62 · Sp.Atk 91 · Sp.Def 77 · Speed 91</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽576</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Picnicker Marcy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Paras</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">720</td><td style="padding:5px;color:#212121;">Spore, Slash, Growth, Giga Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 72 · Def 57 · Sp.Atk 48 · Sp.Def 57 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Paras</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">720</td><td style="padding:5px;color:#212121;">Spore, Slash, Growth, Giga Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 72 · Def 57 · Sp.Atk 48 · Sp.Def 57 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Parasect</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1344</td><td style="padding:5px;color:#212121;">Leech Life, Spore, Slash, Growth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 117 · Atk 98 · Def 83 · Sp.Atk 63 · Sp.Def 83 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽980</td></tr>
</table>

**Water Path** hides a **Dragon Scale** (evolves Seadra → Kingdra by trade). In **Ruin Valley**, use **Cut/Strength** to reach the **Dotted Hole**; inside, a Braille puzzle (read with the Braille signs) leads to the **Sapphire**. If Team Rocket hasn’t already, this is where the Sapphire chase begins/ends — deliver it to **Celio**. Grab the **Sun Stone** in Ruin Valley, then ferry to **[[57 - Seven Island]]**.

**Green Path** has an optional trainer:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Green Path</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Psychic Jaclyn</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Natu</td><td style="padding:5px;color:#212121;">Psychic/Flying</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">750</td><td style="padding:5px;color:#212121;">Night Shade, Confuse Ray, Future Sight, Wish</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 144 · Atk 101 · Def 96 · Sp.Atk 120 · Sp.Def 96 · Speed 120</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowbro</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1686</td><td style="padding:5px;color:#212121;">Psychic, Headbutt, Amnesia, Yawn</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 197 · Atk 125 · Def 158 · Sp.Atk 149 · Sp.Def 129 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1522</td><td style="padding:5px;color:#212121;">Psychic, Future Sight, Recover, Reflect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 147 · Atk 88 · Def 83 · Sp.Atk 171 · Sp.Def 122 · Speed 156</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽980</td></tr>
</table>

**Water Path** trainers (incl. a Twins double battle):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Water Path</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Aroma Lady Rose</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sunkern</td><td style="padding:5px;color:#212121;">Grass</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">546</td><td style="padding:5px;color:#212121;">Endeavor, Sunny Day, Synthesis, Giga Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 88 · Atk 34 · Def 34 · Sp.Atk 34 · Sp.Def 34 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sunflora</td><td style="padding:5px;color:#212121;">Grass</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1533</td><td style="padding:5px;color:#212121;">Bullet Seed, Sunny Day, Petal Dance, Solar Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 132 · Atk 78 · Def 58 · Sp.Atk 107 · Sp.Def 88 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1372</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Twins Miu & Mia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">877</td><td style="padding:5px;color:#212121;">Thunderbolt, Agility, Thunder, Light Screen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 60 · Def 35 · Sp.Atk 55 · Sp.Def 45 · Speed 95</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">877</td><td style="padding:5px;color:#212121;">Thunderbolt, Agility, Thunder, Light Screen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 60 · Def 35 · Sp.Atk 55 · Sp.Def 45 · Speed 95</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽600</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Twins Miu & Mia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">877</td><td style="padding:5px;color:#212121;">Thunderbolt, Agility, Thunder, Light Screen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 60 · Def 35 · Sp.Atk 55 · Sp.Def 45 · Speed 95</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">877</td><td style="padding:5px;color:#212121;">Thunderbolt, Agility, Thunder, Light Screen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 60 · Def 35 · Sp.Atk 55 · Sp.Def 45 · Speed 95</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽600</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Swimmer M Samir</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">2292</td><td style="padding:5px;color:#212121;">Twister, Hydro Pump, Rain Dance, Dragon Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 155 · Atk 130 · Def 84 · Sp.Atk 65 · Sp.Def 105 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽200</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Swimmer F Denise</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Chinchou</td><td style="padding:5px;color:#212121;">Water/Electric</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">945</td><td style="padding:5px;color:#212121;">Confuse Ray, Take Down, Hydro Pump, Charge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 132 · Atk 42 · Def 42 · Sp.Atk 59 · Sp.Def 59 · Speed 70</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Lanturn</td><td style="padding:5px;color:#212121;">Water/Electric</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1638</td><td style="padding:5px;color:#212121;">Water Gun, Spark, Confuse Ray, Take Down</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 181 · Atk 61 · Def 61 · Sp.Atk 79 · Sp.Def 79 · Speed 70</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽196</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Juggler Edward</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">1014</td><td style="padding:5px;color:#212121;">Swift, Light Screen, Spark, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 92 · Atk 32 · Def 51 · Sp.Atk 55 · Sp.Def 55 · Speed 97</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">1014</td><td style="padding:5px;color:#212121;">Swift, Light Screen, Spark, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 92 · Atk 32 · Def 51 · Sp.Atk 55 · Sp.Def 55 · Speed 97</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1510</td><td style="padding:5px;color:#212121;">Swift, Spark, Self Destruct, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 113 · Atk 52 · Def 70 · Sp.Atk 80 · Sp.Def 80 · Speed 136</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mr Mime</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1398</td><td style="padding:5px;color:#212121;">Psychic, Role Play, Reflect, Encore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 96 · Atk 48 · Def 67 · Sp.Atk 101 · Sp.Def 120 · Speed 91</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1920</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Hiker Earl</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1134</td><td style="padding:5px;color:#212121;">Dragon Breath, Sandstorm, Slam, Iron Tail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 93 · Atk 49 · Def 161 · Sp.Atk 34 · Sp.Def 49 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1533</td><td style="padding:5px;color:#212121;">Revenge, Vital Throw, Submission, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 137 · Atk 103 · Def 73 · Sp.Atk 54 · Sp.Def 63 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1764</td></tr>
</table>

**Ruin Valley** trainers:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Ruin Valley</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Hiker Daryl</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sudowoodo</td><td style="padding:5px;color:#212121;">Rock</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1446</td><td style="padding:5px;color:#212121;">Rock Slide, Block, Faint Attack, Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 130 · Atk 105 · Def 120 · Sp.Atk 35 · Sp.Def 70 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Ruin Maniac Stanly</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1377</td><td style="padding:5px;color:#212121;">Self Destruct, Rollout, Rock Blast, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 110 · Atk 96 · Def 115 · Sp.Atk 48 · Sp.Def 48 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1110</td><td style="padding:5px;color:#212121;">Dragon Breath, Sandstorm, Slam, Iron Tail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 48 · Def 158 · Sp.Atk 33 · Sp.Def 48 · Speed 72</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1377</td><td style="padding:5px;color:#212121;">Self Destruct, Rollout, Rock Blast, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 110 · Atk 96 · Def 115 · Sp.Atk 48 · Sp.Def 48 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2304</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Ruin Maniac Foster</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golem</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1896</td><td style="padding:5px;color:#212121;">Self Destruct, Rollout, Rock Blast, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 115 · Def 135 · Sp.Atk 60 · Sp.Def 70 · Speed 50</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2400</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Ruin Maniac Larry</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1533</td><td style="padding:5px;color:#212121;">Revenge, Vital Throw, Submission, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 137 · Atk 103 · Def 73 · Sp.Atk 54 · Sp.Def 63 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1533</td><td style="padding:5px;color:#212121;">Revenge, Vital Throw, Submission, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 137 · Atk 103 · Def 73 · Sp.Atk 54 · Sp.Def 63 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2352</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Pokemaniac Hector</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1417</td><td style="padding:5px;color:#212121;">Scary Face, Rock Blast, Horn Drill, Take Down</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 152 · Atk 103 · Def 112 · Sp.Atk 49 · Sp.Def 49 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kangaskhan</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1837</td><td style="padding:5px;color:#212121;">Rage, Endure, Dizzy Punch, Reversal</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 176 · Atk 112 · Def 98 · Sp.Atk 58 · Sp.Def 98 · Speed 107</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2352</td></tr>
</table>

⬅️ **Prev:** [[55 - Five Island]] · ➡️ **Next:** [[57 - Seven Island]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
