# 47 — Kindle Road

*A volcanic coast of trainers and Rapidash — and the Ember Spa.*

![[47 - Kindle Road.svg]]
*Kindle Road*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="46 - One Island" data-href="46 - One Island">One Island</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="48 - Mt. Ember" data-href="48 - Mt. Ember">Mt. Ember</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Building</td><td style="padding:5px;color:#212121;">Ember Spa (free heal)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ponyta</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">31/34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">36</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rapidash</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">37/40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">37/40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">95%</td><td style="padding:5px;color:#212121;">5–20/20–35/35–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacruel</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🪨 Rock Smash</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">95%</td><td style="padding:5px;color:#212121;">5–20/10–20/15–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">25–40/30–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Ether, Max Repel, Carbos</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">HM06 Rock Smash (Ember Spa — from the man by the waterfall)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Ponyta</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Rapidash</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Ponyta → Rapidash** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Beat the trainers 1–11 (numbered on the map)
> 2. Catch Ponyta
> 3. Get HM06 Rock Smash at the Ember Spa
> 4. Continue north to Mt. Ember

Kindle Road climbs north to Mt. Ember, lined with Swimmers, Black Belts, and Crush Girls:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Kindle Road</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Fisherman Tommy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">784</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 49 · Def 44 · Sp.Atk 28 · Sp.Def 38 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">784</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 49 · Def 44 · Sp.Atk 28 · Sp.Def 38 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1275</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 101 · Atk 69 · Def 50 · Sp.Atk 50 · Sp.Def 61 · Speed 52</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1275</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 101 · Atk 69 · Def 50 · Sp.Atk 50 · Sp.Def 61 · Speed 52</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1275</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 101 · Atk 69 · Def 50 · Sp.Atk 50 · Sp.Def 61 · Speed 52</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1260</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Swimmer F Maria</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1228</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 87 · Atk 53 · Def 75 · Sp.Atk 75 · Sp.Def 38 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1228</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 87 · Atk 53 · Def 75 · Sp.Atk 75 · Sp.Def 38 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽148</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Swimmer M Finn</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Starmie</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1684</td><td style="padding:5px;color:#212121;">Rapid Spin, Recover, Swift, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 93 · Atk 62 · Def 69 · Sp.Atk 81 · Sp.Def 69 · Speed 92</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽152</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Crush Girl Sharon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">586</td><td style="padding:5px;color:#212121;">Focus Energy, Seismic Toss, Cross Chop, Swagger</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 82 · Def 49 · Sp.Atk 49 · Sp.Def 56 · Speed 75</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1180</td><td style="padding:5px;color:#212121;">Focus Energy, Seismic Toss, Rage, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 113 · Atk 101 · Def 67 · Sp.Atk 67 · Sp.Def 75 · Speed 93</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽888</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Black Belt Shea</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">715</td><td style="padding:5px;color:#212121;">Foresight, Revenge, Vital Throw, Submission</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 103 · Def 81 · Sp.Atk 69 · Sp.Def 69 · Speed 69</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1188</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 146 · Atk 119 · Def 96 · Sp.Atk 81 · Sp.Def 88 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽912</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Black Belt Hugh</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">697</td><td style="padding:5px;color:#212121;">Foresight, Revenge, Vital Throw, Submission</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 135 · Atk 101 · Def 79 · Sp.Atk 67 · Sp.Def 67 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1156</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 143 · Atk 116 · Def 93 · Sp.Atk 79 · Sp.Def 86 · Speed 75</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽888</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Swimmer M Garrett</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">727</td><td style="padding:5px;color:#212121;">Icicle Spear, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 50 · Def 75 · Sp.Atk 36 · Sp.Def 22 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cloyster</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1522</td><td style="padding:5px;color:#212121;">Withdraw, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 71 · Def 131 · Sp.Atk 64 · Sp.Def 36 · Speed 54</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Wartortle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1164</td><td style="padding:5px;color:#212121;">Bite, Rapid Spin, Protect, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 92 · Atk 52 · Def 65 · Sp.Atk 54 · Sp.Def 65 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽152</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Camper Bryce</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidorino</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">909</td><td style="padding:5px;color:#212121;">Poison Sting, Horn Attack, Helping Hand, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 89 · Atk 56 · Def 46 · Sp.Atk 44 · Sp.Def 44 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">894</td><td style="padding:5px;color:#212121;">Quick Attack, Hyper Fang, Scary Face, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 63 · Def 48 · Sp.Atk 41 · Sp.Def 55 · Speed 74</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">1257</td><td style="padding:5px;color:#212121;">Sand Attack, Poison Sting, Slash, Swift</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 100 · Atk 77 · Def 84 · Sp.Atk 37 · Sp.Def 44 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Crush Girl Tanya</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmonlee</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1131</td><td style="padding:5px;color:#212121;">Focus Energy, Hi Jump Kick, Mind Reader, Foresight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 105 · Atk 115 · Def 64 · Sp.Atk 50 · Sp.Def 107 · Speed 90</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmonchan</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1140</td><td style="padding:5px;color:#212121;">Ice Punch, Fire Punch, Sky Uppercut, Mega Punch</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 105 · Atk 103 · Def 84 · Sp.Atk 50 · Sp.Def 107 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽912</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Picnicker Claire</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">517</td><td style="padding:5px;color:#212121;">Bite, Pay Day, Faint Attack, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 36 · Def 29 · Sp.Atk 33 · Sp.Def 33 · Speed 68</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">517</td><td style="padding:5px;color:#212121;">Bite, Pay Day, Faint Attack, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 36 · Def 29 · Sp.Atk 33 · Sp.Def 33 · Speed 68</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">615</td><td style="padding:5px;color:#212121;">Double Team, Slam, Thunderbolt, Agility</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 43 · Def 26 · Sp.Atk 40 · Sp.Def 33 · Speed 68</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">510</td><td style="padding:5px;color:#212121;">Minimize, Defense Curl, Metronome, Cosmic Power</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 94 · Atk 36 · Def 38 · Sp.Atk 47 · Sp.Def 50 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽700</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Swimmer F Abigail</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Psyduck</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">600</td><td style="padding:5px;color:#212121;">Disable, Confusion, Screech, Psych Up</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 41 · Def 38 · Sp.Atk 50 · Sp.Def 40 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Psyduck</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">616</td><td style="padding:5px;color:#212121;">Disable, Confusion, Screech, Psych Up</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 42 · Def 39 · Sp.Atk 51 · Sp.Def 41 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golduck</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1378</td><td style="padding:5px;color:#212121;">Disable, Confusion, Screech, Psych Up</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 106 · Atk 65 · Def 62 · Sp.Atk 75 · Sp.Def 64 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽148</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Crush Kin Mik & Kia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">1219</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 130 · Atk 102 · Def 79 · Sp.Atk 63 · Sp.Def 71 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">1245</td><td style="padding:5px;color:#212121;">Focus Energy, Seismic Toss, Rage, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 119 · Atk 106 · Def 71 · Sp.Atk 71 · Sp.Def 79 · Speed 98</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽936</td></tr>
</table>

Catch a **Ponyta** (→ Rapidash). The **Ember Spa** (a hot spring) heals your team for free, and the man by the waterfall inside gives **HM06 Rock Smash** (usable with the Marsh Badge). Continue north to **[[48 - Mt. Ember]]**.

⬅️ **Prev:** [[46 - One Island]] · ➡️ **Next:** [[48 - Mt. Ember]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
