# 🔄 A3 — Version Exclusives, Trades & Trade-Evolutions

*Everything you cannot catch in FireRed alone — your save-edit / trade shopping list for the full 151.*
Back to [[00 - Index & Basics]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">🧩 YOUR SOLO PLAN</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">No trade partner? Everything below is reachable by <b>editing the save to simulate a trade</b>: the 13 LeafGreen-exclusive species, the 4 trade evolutions, plus Mew. Data verified against the pret/pokefirered decompilation.</td></tr>
</table>

## 🔵 LeafGreen exclusives (13) — not in FireRed
Confirmed by diffing FireRed vs LeafGreen wild-encounter tables (evolutions of these count too):
<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">MUST TRADE / SAVE-EDIT — 13 SPECIES</th></tr>
<tr><th style="background:#6a1b9a;color:#fff;padding:5px;text-align:left;">Species</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Sandshrew</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Sandslash</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Vulpix</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Ninetales</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Bellsprout</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Weepinbell</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Victreebel</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Slowpoke</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Slowbro</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Staryu</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Starmie</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Magmar</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Pinsir</td></tr>
</table>
<i>(Sandslash, Ninetales, Weepinbell/Victreebel, Slowbro, Starmie all derive from a LeafGreen-only base, so the whole line needs importing.)</i>

## ⛓️ The 4 trade evolutions
These evolve <b>only</b> by trading. Solo, evolve them via save-edit (set the "traded" flag or force the evolution):
<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="3" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">TRADE EVOLUTIONS</th></tr>
<tr><th style="background:#6a1b9a;color:#fff;padding:5px;text-align:left;">Evolution</th><th style="background:#6a1b9a;color:#fff;padding:5px;text-align:left;">Method</th><th style="background:#6a1b9a;color:#fff;padding:5px;text-align:left;">Where to get the base</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Kadabra → <b>Alakazam</b></td><td style="padding:5px;color:#212121;">Trade</td><td style="padding:5px;color:#212121;">Catch Abra/Kadabra at Route 24/25 & Cerulean Cave.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Machoke → <b>Machamp</b></td><td style="padding:5px;color:#212121;">Trade</td><td style="padding:5px;color:#212121;">Machop line via Rock Tunnel / Cerulean Cave / Route 10.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Graveler → <b>Golem</b></td><td style="padding:5px;color:#212121;">Trade</td><td style="padding:5px;color:#212121;">Geodude line everywhere in caves.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Haunter → <b>Gengar</b></td><td style="padding:5px;color:#212121;">Trade</td><td style="padding:5px;color:#212121;">Gastly line in Pokémon Tower.</td></tr>
</table>

## 🤝 In-game NPC trades (no partner needed)
These NPCs trade with you directly — the only legit way to get Mr. Mime, Jynx, Farfetch'd, and Lickitung in Kanto:
<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">IN-GAME TRADES</th></tr>
<tr><th style="background:#6a1b9a;color:#fff;padding:5px;text-align:left;">You receive</th><th style="background:#6a1b9a;color:#fff;padding:5px;text-align:left;">You give</th><th style="background:#6a1b9a;color:#fff;padding:5px;text-align:left;">Where</th><th style="background:#6a1b9a;color:#fff;padding:5px;text-align:left;">Notes</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;"><b>Mr. Mime</b></td><td style="padding:5px;color:#212121;">Abra</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="05 - Route 2" data-href="05 - Route 2">Route 2 house</a></td><td style="padding:5px;color:#212121;">Mr. Mime is trade-only in Kanto — this is how you get it.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;"><b>Jynx</b></td><td style="padding:5px;color:#212121;">Poliwhirl</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="11 - Cerulean City" data-href="11 - Cerulean City">Cerulean City</a></td><td style="padding:5px;color:#212121;">Trade-only in Kanto.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;"><b>Farfetch'd</b></td><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="16 - Vermilion City" data-href="16 - Vermilion City">Vermilion City</a></td><td style="padding:5px;color:#212121;">Trade-only in Kanto.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;"><b>Lickitung</b></td><td style="padding:5px;color:#212121;">Golduck</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="30 - Route 18" data-href="30 - Route 18">Route 18 gatehouse</a></td><td style="padding:5px;color:#212121;">Trade-only in Kanto (LeafGreen wants Slowbro).</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;"><b>Tangela</b></td><td style="padding:5px;color:#212121;">Venonat</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="42 - Cinnabar Island" data-href="42 - Cinnabar Island">Cinnabar Pokémon Lab</a></td><td style="padding:5px;color:#212121;">Convenience trade.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;"><b>Seel</b></td><td style="padding:5px;color:#212121;">Ponyta</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="42 - Cinnabar Island" data-href="42 - Cinnabar Island">Cinnabar Pokémon Lab</a></td><td style="padding:5px;color:#212121;">Convenience trade.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;"><b>Electrode</b></td><td style="padding:5px;color:#212121;">Raichu</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="42 - Cinnabar Island" data-href="42 - Cinnabar Island">Cinnabar Pokémon Lab</a></td><td style="padding:5px;color:#212121;">Convenience trade.</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Nidoran♀ / Nidoran♂</td><td style="padding:5px;color:#212121;">the opposite Nidoran</td><td style="padding:5px;color:#212121;">Various NPC houses</td><td style="padding:5px;color:#212121;">Gender-swap flavor trades (not needed for the dex).</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Nidorina / Nidorino</td><td style="padding:5px;color:#212121;">the opposite Nido</td><td style="padding:5px;color:#212121;">Various NPC houses</td><td style="padding:5px;color:#212121;">Swap trades (flavor).</td></tr>
</table>

## 🐭 Mew
Event-only distribution — never obtainable in normal play. Save-edit it in to finish the Living Dex.

## ✅ Your solo save-edit checklist for 151
1. The <b>2 alternate starters</b> + <b>alternate fossil</b> + <b>alternate Hitmon</b> (see [[A1 - Missables]]).
2. The <b>13 LeafGreen exclusives</b> above.
3. The <b>4 trade evolutions</b> (Alakazam, Machamp, Golem, Gengar).
4. <b>Mew</b>.


---
*Appendices index: [[00 - Index & Basics#📚 Appendices]] · Back to [[Pokemon FireRed]]*
