# 33 — Route 14

*More fences, bird keepers, and bikers.*

![[33 - Route 14.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="34 - Route 15" data-href="34 - Route 15">Route 15</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="32 - Route 13" data-href="32 - Route 13">Route 13</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Oddish 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">22/24/26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Venonat</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">24/26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ditto</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">23</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">27</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gloom 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">29</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Zinc, Pinap Berry</td></tr>
</table>

> [!todo] Do this in order
> 1. Beat the trainers 1–10 (numbered on the map; Twins Kiri & Jan are a double battle)
> 2. Sweep the hidden Zinc
> 3. Continue west to Route 15

Another fenced route with a heavier **Ditto** rate (15%) if you still need one.

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 14</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Bird Keeper Carter</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">330</td><td style="padding:5px;color:#212121;">Gust, Quick Attack, Whirlwind, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 30 · Def 27 · Sp.Atk 24 · Sp.Def 24 · Speed 36</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">576</td><td style="padding:5px;color:#212121;">Pursuit, Fury Attack, Tri Attack, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 57 · Atk 52 · Def 30 · Sp.Atk 24 · Sp.Def 24 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">678</td><td style="padding:5px;color:#212121;">Gust, Quick Attack, Whirlwind, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 38 · Def 35 · Sp.Atk 33 · Sp.Def 33 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Bird Keeper Mitch</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">306</td><td style="padding:5px;color:#212121;">Gust, Quick Attack, Whirlwind, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 28 · Def 25 · Sp.Atk 23 · Sp.Def 23 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">322</td><td style="padding:5px;color:#212121;">Leer, Fury Attack, Pursuit, Aerial Ace</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 36 · Def 20 · Sp.Atk 21 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">306</td><td style="padding:5px;color:#212121;">Gust, Quick Attack, Whirlwind, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 28 · Def 25 · Sp.Atk 23 · Sp.Def 23 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">901</td><td style="padding:5px;color:#212121;">Growl, Leer, Fury Attack, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 51 · Def 38 · Sp.Atk 36 · Sp.Def 36 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽624</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Bird Keeper Beck</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">702</td><td style="padding:5px;color:#212121;">Gust, Quick Attack, Whirlwind, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 75 · Atk 39 · Def 36 · Sp.Atk 34 · Sp.Def 34 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1006</td><td style="padding:5px;color:#212121;">Growl, Leer, Fury Attack, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 57 · Def 42 · Sp.Atk 40 · Sp.Def 40 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Bird Keeper Marlon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">348</td><td style="padding:5px;color:#212121;">Leer, Fury Attack, Pursuit, Aerial Ace</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 38 · Def 21 · Sp.Atk 22 · Sp.Def 22 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">576</td><td style="padding:5px;color:#212121;">Pursuit, Fury Attack, Tri Attack, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 57 · Atk 52 · Def 30 · Sp.Atk 24 · Sp.Def 24 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">972</td><td style="padding:5px;color:#212121;">Growl, Leer, Fury Attack, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 55 · Def 41 · Sp.Atk 39 · Sp.Def 39 · Speed 61</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Biker Isaac</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">540</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 49 · Def 33 · Sp.Atk 27 · Sp.Def 33 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">540</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 49 · Def 33 · Sp.Atk 27 · Sp.Def 33 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">684</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 41 · Def 58 · Sp.Atk 38 · Sp.Def 30 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽560</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Biker Malik</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">708</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 42 · Def 60 · Sp.Atk 39 · Sp.Def 31 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">558</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 51 · Def 34 · Sp.Atk 28 · Sp.Def 34 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽580</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Bird Keeper Donald</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Farfetchd</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">664</td><td style="padding:5px;color:#212121;">Fury Attack, Knock Off, Fury Cutter, Swords Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 77 · Atk 47 · Def 41 · Sp.Atk 43 · Sp.Def 45 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽792</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Biker Gerald</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">708</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 42 · Def 60 · Sp.Atk 39 · Sp.Def 31 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Muk</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">975</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 99 · Atk 65 · Def 48 · Sp.Atk 42 · Sp.Def 63 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽580</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Biker Lukas</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">634</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 38 · Def 54 · Sp.Atk 36 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">634</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 38 · Def 54 · Sp.Atk 36 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">501</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 77 · Atk 46 · Def 31 · Sp.Atk 25 · Sp.Def 31 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">634</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 38 · Def 54 · Sp.Atk 36 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽520</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Bird Keeper Benny</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">360</td><td style="padding:5px;color:#212121;">Leer, Fury Attack, Pursuit, Aerial Ace</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 39 · Def 22 · Sp.Atk 22 · Sp.Def 22 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1006</td><td style="padding:5px;color:#212121;">Growl, Leer, Fury Attack, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 57 · Def 42 · Sp.Atk 40 · Sp.Def 40 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Twins Kiri & Jan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">403</td><td style="padding:5px;color:#212121;">Ember, Metal Claw, Smokescreen, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 61 · Atk 35 · Def 29 · Sp.Atk 39 · Sp.Def 34 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Squirtle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">409</td><td style="padding:5px;color:#212121;">Water Gun, Bite, Rapid Spin, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 32 · Def 42 · Sp.Atk 34 · Sp.Def 42 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽348</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Twins Kiri & Jan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">403</td><td style="padding:5px;color:#212121;">Ember, Metal Claw, Smokescreen, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 61 · Atk 35 · Def 29 · Sp.Atk 39 · Sp.Def 34 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Squirtle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">409</td><td style="padding:5px;color:#212121;">Water Gun, Bite, Rapid Spin, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 32 · Def 42 · Sp.Atk 34 · Sp.Def 42 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽348</td></tr>
</table>

Head **west to [[34 - Route 15]]**.

⬅️ **Prev:** [[32 - Route 13]] · ➡️ **Next:** [[34 - Route 15]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
