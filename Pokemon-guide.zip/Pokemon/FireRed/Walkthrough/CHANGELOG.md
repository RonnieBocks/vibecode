# 🗒️ Changelog — FireRed Guide

Version history for the whole vault (Walkthrough + Player + maps). Newest first. Back to [[00 - Index & Basics]] · [[Pokemon FireRed]].

**Current version: v1.6** (2026-09-23)

---

## v1.6 — 2026-09-23 · Tables, legends & notes
- **Wild Pokémon tables regrouped by method** across every area — divider rows (🌿 Grass / 🏄 Surf / 🎣 Old·Good·Super Rod / 🪨 Rock Smash) instead of a Method column (`regroup_wild.py`).
- **Per-map legend strip** added to the bottom of all 116 map SVGs (item / trainer / rival / door / NPC / hidden / sign / ledge + tile swatches).
- **Clearer "where to go next"** directions (e.g. Route 22 → back to Viridian → north to Route 2).
- **Walkthrough Notes section on every area file** + this changelog; addressed playtest notes are ~~struck through~~ with a ✅ resolution.

## v1.5 — 2026-09-23 · Playtest corrections (areas 00–07)
- **Trainer EXP fix (guide-wide):** battle-table Exp was missing the **Gen-3 trainer ×1.5 bonus**; recomputed **1127 Exp cells** to `((baseExp×L)//7)×1.5` (`fix_trainer_exp.py`, and `tgen.py`). Verified vs in-game logs (rival Bulbasaur L5 = 67, Brock's Onix = 324, etc.).
- **Town Map timing:** Daisy only gives it after the Pokédex/parcel run — flow corrected in Pallet & Viridian.
- **Viridian Potion** relocated to the correct north-west item ball; **Pewter items** now list Boulder Badge, TM39 Rock Tomb & the TM Case.
- **Endgame spoilers deferred:** the Viridian Gym (Giovanni) roster and the Route 22 rival rematch moved to bottom "🔒 Endgame" sections.

## v1.4 — Living Dex guidance
- Added the **🏠 Living Dex callout** under each area's New Pokémon table (how many of each new line to keep, computed from `evolution.h`) + the master explainer in the Index.

## v1.3 — Every trainer accounted for
- Added FRLG **double-battle Couples** to their areas' tables + maps; created the missing **Sevault Canyon** table and **6 untabled Sevii sub-area** tables — every trainer on every map is now numbered.
- Rebuilt the **5 S.S. Anne** composite maps (corridor + cabins, all 16 trainers numbered).

## v1.2 — Enhanced maps
- New map style: **class-labeled numbered trainers, ledge chevrons, terrain texture, Poké-Ball item glyphs, auto-split panels** (West/East, North/South, grid) with in-world exit pills.

## v1.1 — Appendices
- Added [[A1 - Missables]], [[A2 - Evolution Item Budget]], [[A3 - Trades & Exclusives]], [[A4 - Hidden Items]].

## v1.0 — Complete walkthrough
- 57 per-area files (Pallet → the full Sevii post-game): color-block SVG maps, Connections / Wild / Items / New-Pokémon tables, inline battle tables for every trainer, gyms & Elite Four — all data from the pret/pokefirered decompilation.
- Player trackers: [[Pokemon FireRed]] hub, [[Pokedex Reference]], [[Pokedex Tracker]], [[Team & Boxes]].

---

*How the guide is generated/regenerated: `_BUILD_PLAYBOOK.md` (maps & tables) and `Player/_PLAYER_PLAYBOOK.md` (trackers).*
