# 06 — Viridian Forest

*A maze of trees, bug-catchers, and a wild Pikachu.*

![[06 - Viridian Forest.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North exit</td><td style="padding:5px;color:#212121;">Route 2 → Pewter City</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South exit</td><td style="padding:5px;color:#212121;">Route 2 → Viridian City</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">3/4/5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">3/4/5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Metapod</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Kakuna</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">4/5/6</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">3/5</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Poké Ball</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Antidote</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Potion</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Potion</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Potion</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Antidote</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Metapod</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Kakuna</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Pikachu</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Pikachu → Raichu** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Catch a Pikachu (rare!), plus Metapod/Kakuna
> 2. Grab the four item balls (+ 2 hidden)
> 3. Beat Bug Catchers 1–5 (numbered on the map)
> 4. Take the north exit to Pewter

The forest is an easy maze. The prize catch is **Pikachu** (~5%) — chip its HP and ball it (don’t let a strong hit KO it). Grab **Metapod/Kakuna** too, and sweep the item balls.

Five **Bug Catchers** dot the path (numbered on the map, south to north):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ BUG CATCHERS — Viridian Forest</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Bug Catcher Rick</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">6</td><td style="padding:5px;color:#212121;">66</td><td style="padding:5px;color:#212121;">Poison Sting, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 20 · Atk 9 · Def 8 · Sp.Atk 7 · Sp.Def 7 · Speed 11</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">6</td><td style="padding:5px;color:#212121;">67</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 21 · Atk 8 · Def 9 · Sp.Atk 7 · Sp.Def 7 · Speed 10</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽72</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Bug Catcher Doug</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">7</td><td style="padding:5px;color:#212121;">78</td><td style="padding:5px;color:#212121;">Poison Sting, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 22 · Atk 9 · Def 9 · Sp.Atk 7 · Sp.Def 7 · Speed 12</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kakuna</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">7</td><td style="padding:5px;color:#212121;">106</td><td style="padding:5px;color:#212121;">Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 23 · Atk 8 · Def 12 · Sp.Atk 8 · Sp.Def 8 · Speed 9</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">7</td><td style="padding:5px;color:#212121;">78</td><td style="padding:5px;color:#212121;">Poison Sting, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 22 · Atk 9 · Def 9 · Sp.Atk 7 · Sp.Def 7 · Speed 12</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽84</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Bug Catcher Sammy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">99</td><td style="padding:5px;color:#212121;">Poison Sting, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 26 · Atk 11 · Def 10 · Sp.Atk 8 · Sp.Def 8 · Speed 14</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽108</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Bug Catcher Anthony</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">7</td><td style="padding:5px;color:#212121;">79</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 23 · Atk 9 · Def 9 · Sp.Atk 7 · Sp.Def 7 · Speed 11</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">8</td><td style="padding:5px;color:#212121;">90</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 25 · Atk 9 · Def 10 · Sp.Atk 8 · Sp.Def 8 · Speed 12</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽96</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Bug Catcher Charlie</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Metapod</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">7</td><td style="padding:5px;color:#212121;">108</td><td style="padding:5px;color:#212121;">Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 24 · Atk 7 · Def 12 · Sp.Atk 8 · Sp.Def 8 · Speed 9</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">7</td><td style="padding:5px;color:#212121;">79</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 23 · Atk 9 · Def 9 · Sp.Atk 7 · Sp.Def 7 · Speed 11</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Metapod</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">7</td><td style="padding:5px;color:#212121;">108</td><td style="padding:5px;color:#212121;">Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 24 · Atk 7 · Def 12 · Sp.Atk 8 · Sp.Def 8 · Speed 9</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽84</td></tr>
</table>

A Flying move (Spearow’s Peck) sweeps them; they’re great EXP for a low-level project. Take the **north exit** to Route 2 and on to **[[07 - Pewter City]]**.

⬅️ **Prev:** [[05 - Route 2]] · ➡️ **Next:** [[07 - Pewter City]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- ~~Got 66 xp for beating Weedle with spearow against trainer 1~~ — ✅ matches after the exp fix
- Bug Catcher 2
	- ~~78 XP for weedle~~ — ✅ matches after the exp fix
	- ~~78 xp for second weedle~~ — ✅ matches after the exp fix
	- ~~106 xp for kakuna~~ — ✅ matches after the exp fix
- Bug Catcher 4
	- ~~79 XP for caterpie~~ — ✅ matches after the exp fix
	- ~~90 XP for second caterpie~~ — ✅ matches after the exp fix
- Bug Catcher 5
	- ~~108 xp for metapod~~ — ✅ matches after the exp fix
	- ~~79 xp for caterpie~~ — ✅ matches after the exp fix
	- ~~108 xp for metapod~~ — ✅ matches after the exp fix
- Bug Catcher 3
	- ~~99 xp for weedle~~ — ✅ matches after the exp fix
- ~~Seems like all of the XP counts are wrong but the cash per win are correct.~~ — ✅ trainer-exp ×1.5 correction — all your logged values now match exactly