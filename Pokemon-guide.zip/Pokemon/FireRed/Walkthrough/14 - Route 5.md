# 14 — Route 5

*A short link south — home to the Day Care.*

![[14 - Route 5.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="11 - Cerulean City" data-href="11 - Cerulean City">Cerulean City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;">Underground Path → <a class="internal-link" href="15 - Route 6" data-href="15 - Route 6">Route 6</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South gate</td><td style="padding:5px;color:#212121;">Saffron City (blocked)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">10/12/14/16</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">13/15/16</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Oddish 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">13/15/16</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Day Care (service — leave a Pokémon to level)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Meowth</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Meowth → Persian** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Catch a Meowth
> 2. (Optional) drop a Pokémon at the Day Care
> 3. Take the Underground Path to Route 6

A short hop south of Cerulean. The **Day Care** raises a Pokémon while you play — handy for a benched Living-Dex project. The **Saffron gate is blocked** (guards need a drink, later), so take the **Underground Path** house south to **[[15 - Route 6]]**. Catch **Meowth** (→ Persian) on the way.

⬅️ **Prev:** [[13 - Route 25]] · ➡️ **Next:** [[15 - Route 6]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
