# 28 — Route 16

*Gateway to the Cycling Road — and a snoozing Snorlax.*

![[28 - Route 16.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="25 - Celadon City" data-href="25 - Celadon City">Celadon City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="29 - Route 17" data-href="29 - Route 17">Route 17</a> (Cycling Road)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">20/22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">18/20/22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">18/20/22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">23/25</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">HM02 Fly (from the woman in the gatehouse)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Leftovers (on Snorlax’s tile)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Snorlax (Lv 30 — wake with the Poké Flute; 1 of only 2)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Doduo</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Raticate</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Doduo → Dodrio** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Get HM02 Fly from the gatehouse
> 2. Wake & catch the Snorlax with the Poké Flute (save first!)
> 3. Beat the trainers 1–6 (numbered on the map)
> 4. Grab the Bicycle (redeem the Bike Voucher in Cerulean) for the Cycling Road

Just west of Celadon, the woman in the **gatehouse** gives you **HM02 Fly** (usable with the Thunder Badge). A **Snorlax (Lv 30)** blocks the road south — play the **Poké Flute** to wake it and **catch it** (only two exist, so save first). Stand on its tile afterward and Itemfinder a hidden **Leftovers**.

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 16</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Cue Ball Camron</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">459</td><td style="padding:5px;color:#212121;">Karate Chop, Fury Swipes, Focus Energy, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 51 · Def 25 · Sp.Atk 25 · Sp.Def 31 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">546</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 51 · Def 34 · Sp.Atk 25 · Sp.Def 25 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Biker Ruben</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1038</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 55 · Def 72 · Sp.Atk 52 · Sp.Def 44 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">684</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 41 · Def 58 · Sp.Atk 38 · Sp.Def 30 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1038</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 55 · Def 72 · Sp.Atk 52 · Sp.Def 44 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽560</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Biker Hideo</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1222</td><td style="padding:5px;color:#212121;">Self Destruct, Sludge, Smokescreen, Haze</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 64 · Def 84 · Sp.Atk 61 · Sp.Def 51 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽660</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Cue Ball Luke</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">459</td><td style="padding:5px;color:#212121;">Karate Chop, Fury Swipes, Focus Energy, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 51 · Def 25 · Sp.Atk 25 · Sp.Def 31 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">546</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 51 · Def 34 · Sp.Atk 25 · Sp.Def 25 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Cue Ball Koji</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">528</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 77 · Atk 49 · Def 33 · Sp.Atk 24 · Sp.Def 24 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">444</td><td style="padding:5px;color:#212121;">Karate Chop, Fury Swipes, Focus Energy, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 49 · Def 24 · Sp.Atk 24 · Sp.Def 30 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">528</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 77 · Atk 49 · Def 33 · Sp.Atk 24 · Sp.Def 24 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Biker Lao</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">558</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 51 · Def 34 · Sp.Atk 28 · Sp.Def 34 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">708</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 42 · Def 60 · Sp.Atk 39 · Sp.Def 31 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽580</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Young Couple Lea & Jed</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rapidash</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1192</td><td style="padding:5px;color:#212121;">Tail Whip, Ember, Stomp, Fire Spin</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 63 · Def 45 · Sp.Atk 51 · Sp.Def 51 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ninetales</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1105</td><td style="padding:5px;color:#212121;">Ember, Quick Attack, Confuse Ray, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 49 · Def 48 · Sp.Atk 51 · Sp.Def 63 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽812</td></tr>
</table>

The **Cycling Road** (Routes 17–18) south requires the **Bicycle** — redeem your **Bike Voucher** at the Cerulean Bike Shop if you haven’t. Then head down to **[[29 - Route 17]]**.

⬅️ **Prev:** [[27 - Pokémon Tower]] · ➡️ **Next:** [[29 - Route 17]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
