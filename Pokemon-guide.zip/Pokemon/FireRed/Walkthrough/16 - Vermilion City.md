# 16 — Vermilion City

*A harbor town — the S.S. Anne, Cut, and Lt. Surge.*

![[16 - Vermilion City.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="15 - Route 6" data-href="15 - Route 6">Route 6</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;">Route 11 → Diglett’s Cave</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Harbor</td><td style="padding:5px;color:#212121;">S.S. Anne (with S.S. Ticket)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">44%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Shellder 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Old Rod (Fishing Guru)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">VS Seeker (Pokémon Center)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Bike Voucher (Fan Club chairman)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">HM01 Cut (S.S. Anne captain)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">TM34 Shock Wave (Lt. Surge)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Max Ether</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Magikarp (Old Rod, now obtainable)</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Farfetch’d (in-game trade — give a Spearow)</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Magikarp → Gyarados** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Collect VS Seeker, Old Rod, Bike Voucher, Farfetch’d
> 2. Board the S.S. Anne: sweep items, beat your rival, get HM01 Cut
> 3. Cut the gym tree + solve the trash-can puzzle
> 4. Beat the gym trainers, then Lt. Surge
> 5. Head east to Route 11

Grab the freebies: **VS Seeker** (Center), **Old Rod** (Fishing Guru — now you can fish Magikarp), **Bike Voucher** (Fan Club → free Bicycle in Cerulean), and a **Farfetch’d** via trade (give a Spearow).

**S.S. Anne** (board with the S.S. Ticket): the ship is packed with **optional trainers** in the cabins and on deck — excellent EXP and money — but they and the cabin items are **gone once the ship departs**, so clear them now.

![[16b - S.S. Anne Exterior.svg]]
*Exterior*

![[16b - S.S. Anne 1F.svg]]
*1F cabins*

![[16b - S.S. Anne 2F.svg]]
*2F cabins*

![[16b - S.S. Anne B1F.svg]]
*B1F cabins*

![[16b - S.S. Anne Deck.svg]]
*Deck*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ S.S. ANNE — Trainers (optional · missable once the ship leaves)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Lass Ann — 1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">211</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 21 · Def 19 · Sp.Atk 17 · Sp.Def 17 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♀</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">226</td><td style="padding:5px;color:#212121;">Scratch, Tail Whip, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 21 · Def 23 · Sp.Atk 19 · Sp.Def 19 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽288</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Youngster Tyler — 1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">270</td><td style="padding:5px;color:#212121;">Focus Energy, Double Kick, Poison Sting, Horn Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 50 · Atk 28 · Def 21 · Sp.Atk 21 · Sp.Def 21 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽336</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Gentleman Arthur — 1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">243</td><td style="padding:5px;color:#212121;">Peck, Focus Energy, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 26 · Def 20 · Sp.Atk 20 · Sp.Def 20 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♀</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">240</td><td style="padding:5px;color:#212121;">Scratch, Tail Whip, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 22 · Def 24 · Sp.Atk 20 · Sp.Def 20 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1368</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Gentleman Thomas — 1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">351</td><td style="padding:5px;color:#212121;">Bite, Roar, Ember, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 30 · Def 21 · Sp.Atk 30 · Sp.Def 23 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">351</td><td style="padding:5px;color:#212121;">Bite, Roar, Ember, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 30 · Def 21 · Sp.Atk 30 · Sp.Def 23 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1296</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Fisherman Dale — 2F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">403</td><td style="padding:5px;color:#212121;">Tail Whip, Water Sport, Supersonic, Horn Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 27 · Def 25 · Sp.Atk 16 · Sp.Def 22 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">382</td><td style="padding:5px;color:#212121;">Poison Sting, Supersonic, Constrict</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 18 · Def 16 · Sp.Atk 22 · Sp.Def 39 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">403</td><td style="padding:5px;color:#212121;">Tail Whip, Water Sport, Supersonic, Horn Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 27 · Def 25 · Sp.Atk 16 · Sp.Def 22 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽612</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Gentleman Brooks — 2F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">403</td><td style="padding:5px;color:#212121;">Thunder Wave, Quick Attack, Double Team, Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 30 · Def 18 · Sp.Atk 28 · Sp.Def 23 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1656</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Gentleman Lamar — 2F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">331</td><td style="padding:5px;color:#212121;">Bite, Roar, Ember, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 28 · Def 20 · Sp.Atk 28 · Sp.Def 22 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ponyta</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">553</td><td style="padding:5px;color:#212121;">Quick Attack, Growl, Tail Whip, Ember</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 33 · Def 23 · Sp.Atk 27 · Sp.Def 27 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1224</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Lass Dawn — 2F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">219</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 38 · Atk 25 · Def 17 · Sp.Atk 14 · Sp.Def 17 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">315</td><td style="padding:5px;color:#212121;">Tail Whip, Thunder Wave, Quick Attack, Double Team</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 24 · Def 15 · Sp.Atk 23 · Sp.Def 19 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽288</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Fisherman Barny — B1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">382</td><td style="padding:5px;color:#212121;">Poison Sting, Supersonic, Constrict</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 18 · Def 16 · Sp.Atk 22 · Sp.Def 39 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">385</td><td style="padding:5px;color:#212121;">Harden, Water Gun, Rapid Spin, Recover</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 20 · Def 23 · Sp.Atk 28 · Sp.Def 23 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">352</td><td style="padding:5px;color:#212121;">Tackle, Withdraw, Icicle Spear, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 27 · Def 39 · Sp.Atk 20 · Sp.Def 13 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽612</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Sailor Phillip — B1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">376</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Karate Chop, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 37 · Def 25 · Sp.Atk 19 · Sp.Def 19 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽640</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Sailor Huey — B1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">405</td><td style="padding:5px;color:#212121;">Poison Sting, Supersonic, Constrict</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 19 · Def 17 · Sp.Atk 23 · Sp.Def 41 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">408</td><td style="padding:5px;color:#212121;">Harden, Water Gun, Rapid Spin, Recover</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 38 · Atk 21 · Def 24 · Sp.Atk 30 · Sp.Def 24 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽576</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Sailor Dylan — B1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">301</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 18 · Def 28 · Sp.Atk 28 · Sp.Def 13 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">301</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 18 · Def 28 · Sp.Atk 28 · Sp.Def 13 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">301</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 18 · Def 28 · Sp.Atk 28 · Sp.Def 13 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽544</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">13. Sailor Leonard — B1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">436</td><td style="padding:5px;color:#212121;">Tackle, Withdraw, Icicle Spear, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 43 · Atk 32 · Def 47 · Sp.Atk 23 · Sp.Def 15 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">14. Sailor Duncan — B1F cabin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">301</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 18 · Def 28 · Sp.Atk 28 · Sp.Def 13 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">352</td><td style="padding:5px;color:#212121;">Tackle, Withdraw, Icicle Spear, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 27 · Def 39 · Sp.Atk 20 · Sp.Def 13 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">382</td><td style="padding:5px;color:#212121;">Poison Sting, Supersonic, Constrict</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 18 · Def 16 · Sp.Atk 22 · Sp.Def 39 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽544</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">15. Sailor Edmond — Deck</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">339</td><td style="padding:5px;color:#212121;">Low Kick, Leer, Focus Energy, Karate Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 33 · Def 23 · Sp.Atk 17 · Sp.Def 17 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">373</td><td style="padding:5px;color:#212121;">Tackle, Withdraw, Icicle Spear, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 38 · Atk 28 · Def 41 · Sp.Atk 21 · Sp.Def 14 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽576</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">16. Sailor Trevor — Deck</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">319</td><td style="padding:5px;color:#212121;">Low Kick, Leer, Focus Energy, Karate Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 50 · Atk 32 · Def 22 · Sp.Atk 16 · Sp.Def 16 · Speed 16</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">382</td><td style="padding:5px;color:#212121;">Poison Sting, Supersonic, Constrict</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 18 · Def 16 · Sp.Atk 22 · Sp.Def 39 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽544</td></tr>
</table>

Heal in the room near the stairs, then your rival challenges you:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ RIVAL — S.S. Anne</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Bulbasaur</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">459</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 37 · Def 35 · Sp.Atk 33 · Sp.Def 33 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">397</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 38 · Def 32 · Sp.Atk 29 · Sp.Def 35 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">558</td><td style="padding:5px;color:#212121;">Teleport, Kinesis, Confusion, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 26 · Def 24 · Sp.Atk 57 · Sp.Def 39 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmeleon</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">607</td><td style="padding:5px;color:#212121;">Growl, Ember, Metal Claw, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 50 · Def 48 · Sp.Atk 57 · Sp.Def 51 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Charmander</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">459</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 37 · Def 35 · Sp.Atk 33 · Sp.Def 33 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">397</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 38 · Def 32 · Sp.Atk 29 · Sp.Def 35 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">558</td><td style="padding:5px;color:#212121;">Teleport, Kinesis, Confusion, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 26 · Def 24 · Sp.Atk 57 · Sp.Def 39 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Wartortle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">612</td><td style="padding:5px;color:#212121;">Bubble, Withdraw, Water Gun, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 50 · Def 57 · Sp.Atk 51 · Sp.Def 57 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Squirtle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">459</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 37 · Def 35 · Sp.Atk 33 · Sp.Def 33 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">397</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 38 · Def 32 · Sp.Atk 29 · Sp.Def 35 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">558</td><td style="padding:5px;color:#212121;">Teleport, Kinesis, Confusion, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 26 · Def 24 · Sp.Atk 57 · Sp.Def 39 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ivysaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">603</td><td style="padding:5px;color:#212121;">Leech Seed, Vine Whip, Poison Powder, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 49 · Def 50 · Sp.Atk 57 · Sp.Def 57 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
</table>

Talk to the seasick **Captain** for **HM01 Cut** (usable in the field with the Cascade Badge). The ship then departs for good.

**Vermilion Gym — Lt. Surge (Electric).** Cut the tree out front, solve the **trash-can switch puzzle** (two hidden switches, second next to the first), then:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ VERMILION GYM — Lt. Surge (Thunder Badge)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Sailor Dwayne</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">369</td><td style="padding:5px;color:#212121;">Thunder Wave, Quick Attack, Double Team, Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 28 · Def 17 · Sp.Atk 26 · Sp.Def 21 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">369</td><td style="padding:5px;color:#212121;">Thunder Wave, Quick Attack, Double Team, Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 28 · Def 17 · Sp.Atk 26 · Sp.Def 21 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Engineer Baily</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">463</td><td style="padding:5px;color:#212121;">Tackle, Screech, Sonic Boom, Spark</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 17 · Def 26 · Sp.Atk 28 · Sp.Def 28 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">400</td><td style="padding:5px;color:#212121;">Thunder Shock, Supersonic, Sonic Boom, Thunder Wave</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 41 · Atk 19 · Def 34 · Sp.Atk 44 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1008</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Gentleman Tucker</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">403</td><td style="padding:5px;color:#212121;">Thunder Wave, Quick Attack, Double Team, Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 30 · Def 18 · Sp.Atk 28 · Sp.Def 23 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1656</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Leader Lt. Surge</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">463</td><td style="padding:5px;color:#212121;">Sonic Boom, Tackle, Screech, Shock Wave</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 17 · Def 26 · Sp.Atk 28 · Sp.Def 28 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">315</td><td style="padding:5px;color:#212121;">Quick Attack, Thunder Wave, Double Team, Shock Wave</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 24 · Def 15 · Sp.Atk 23 · Sp.Def 19 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raichu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">627</td><td style="padding:5px;color:#212121;">Quick Attack, Thunder Wave, Double Team, Shock Wave</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 48 · Def 31 · Sp.Atk 48 · Sp.Def 43 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2400</td></tr>
</table>

**Ground is immune to Electric** — a **Diglett/Dugtrio** (Diglett’s Cave, east via Route 11) hard-counters him. Winning gives the **Thunder Badge** (lets you use **Fly**) and **TM34 Shock Wave**. Next: **[[17 - Route 11]]**.

⬅️ **Prev:** [[15 - Route 6]] · ➡️ **Next:** [[17 - Route 11]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
