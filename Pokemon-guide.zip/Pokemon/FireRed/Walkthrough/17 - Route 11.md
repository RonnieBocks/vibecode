# 17 — Route 11

*A grassy shelf east of Vermilion, past Diglett’s Cave.*

![[17 - Route 11.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="16 - Vermilion City" data-href="16 - Vermilion City">Vermilion City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;">Route 12 (Snorlax blocks — later)</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Cave</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="18 - Diglett’s Cave" data-href="18 - Diglett’s Cave">Diglett’s Cave</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ekans 🔴</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">12/14/15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">13/15/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">11/13/15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">84%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">X Defend</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Great Ball</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Awakening</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Escape Rope</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Itemfinder — from Oak’s Aide (needs 30 caught)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Drowzee</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Drowzee → Hypno** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Catch a Drowzee
> 2. Beat trainers 1–10 (numbered on the map)
> 3. Grab the items (X Defend, Great Ball, Awakening)
> 4. Duck into Diglett’s Cave for Flash & Dugtrio

East of Vermilion, Route 11 is a wide grassy shelf. Catch a **Drowzee** (→ Hypno, a strong Psychic). The east gate leads to Route 12, but a **Snorlax** blocks it until you have the Poké Flute — ignore it for now.

Work through the trainers (numbered on the map):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 11</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Gamer Hugo</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">297</td><td style="padding:5px;color:#212121;">Bubble, Hypnosis, Water Gun</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 23 · Def 19 · Sp.Atk 19 · Sp.Def 19 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">319</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 38 · Atk 19 · Def 30 · Sp.Atk 30 · Sp.Def 14 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1296</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Youngster Eddie</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">279</td><td style="padding:5px;color:#212121;">Leer, Poison Sting, Bite, Glare</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 30 · Def 23 · Sp.Atk 21 · Sp.Def 27 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽336</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Youngster Dave</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">231</td><td style="padding:5px;color:#212121;">Peck, Focus Energy, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 25 · Def 19 · Sp.Atk 19 · Sp.Def 19 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidorino</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">454</td><td style="padding:5px;color:#212121;">Peck, Focus Energy, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 30 · Def 25 · Sp.Atk 24 · Sp.Def 24 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽288</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Youngster Dillon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandshrew</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">378</td><td style="padding:5px;color:#212121;">Scratch, Defense Curl, Sand Attack, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 33 · Def 37 · Sp.Atk 12 · Sp.Def 16 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">219</td><td style="padding:5px;color:#212121;">Leech Life, Astonish, Supersonic, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 22 · Def 18 · Sp.Atk 16 · Sp.Def 20 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽304</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Engineer Bernie</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">342</td><td style="padding:5px;color:#212121;">Tackle, Thunder Shock, Supersonic, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 17 · Def 30 · Sp.Atk 39 · Sp.Def 24 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">342</td><td style="padding:5px;color:#212121;">Tackle, Thunder Shock, Supersonic, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 17 · Def 30 · Sp.Atk 39 · Sp.Def 24 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">621</td><td style="padding:5px;color:#212121;">Tackle, Thunder Shock, Supersonic, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 26 · Def 39 · Sp.Atk 48 · Sp.Def 30 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽864</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Gamer Jasper</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">324</td><td style="padding:5px;color:#212121;">Growth, Wrap, Sleep Powder, Poison Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 32 · Def 17 · Sp.Atk 30 · Sp.Def 15 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">300</td><td style="padding:5px;color:#212121;">Sweet Scent, Poison Powder, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 23 · Def 24 · Sp.Atk 32 · Sp.Def 28 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1296</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Engineer Braxton</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">400</td><td style="padding:5px;color:#212121;">Thunder Shock, Supersonic, Sonic Boom, Thunder Wave</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 41 · Atk 19 · Def 34 · Sp.Atk 44 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1008</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Gamer Darian</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">351</td><td style="padding:5px;color:#212121;">Bite, Roar, Ember, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 30 · Def 21 · Sp.Atk 30 · Sp.Def 23 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">243</td><td style="padding:5px;color:#212121;">Tail Whip, Roar, Quick Attack, Will O Wisp</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 41 · Atk 19 · Def 19 · Sp.Atk 23 · Sp.Def 28 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1296</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Youngster Yasu</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">207</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 24 · Def 16 · Sp.Atk 13 · Sp.Def 16 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">207</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 24 · Def 16 · Sp.Atk 13 · Sp.Def 16 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">421</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 32 · Def 25 · Sp.Atk 22 · Sp.Def 28 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽272</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Gamer Dirk</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">396</td><td style="padding:5px;color:#212121;">Charge, Tackle, Screech, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 15 · Def 23 · Sp.Atk 24 · Sp.Def 24 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">342</td><td style="padding:5px;color:#212121;">Tackle, Thunder Shock, Supersonic, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 17 · Def 30 · Sp.Atk 39 · Sp.Def 24 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1296</td></tr>
</table>

Grab **X Defend, Great Ball, Awakening**, and if you have 30 dex entries the aide gives the **Itemfinder**. Then head into **[[18 - Diglett’s Cave]]** (south entrance) to grab Flash and a Dugtrio.

⬅️ **Prev:** [[16 - Vermilion City]] · ➡️ **Next:** [[18 - Diglett’s Cave]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
