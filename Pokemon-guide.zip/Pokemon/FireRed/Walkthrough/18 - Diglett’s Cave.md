# 18 — Diglett’s Cave

*A tunnel full of Diglett — and the shortcut to Flash.*

![[18 - Diglett’s Cave.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South entrance</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="17 - Route 11" data-href="17 - Route 11">Route 11</a> (Vermilion side)</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North entrance</td><td style="padding:5px;color:#212121;">Route 2 (Viridian side)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Diglett</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">95%</td><td style="padding:5px;color:#212121;">15/16/17/18/19/20/21/22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Dugtrio</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">29/31</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">HM05 Flash — from Oak’s Aide at the Route 2 (north) exit, with 10+ caught</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Diglett</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Dugtrio</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Diglett → Dugtrio** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Catch a Diglett (and a rare Dugtrio)
> 2. Exit north to Route 2 → get HM05 Flash from the aide
> 3. Return east toward Cerulean/Route 9

This tunnel connects Route 11 (Vermilion side) to Route 2 (Viridian side). It’s wall-to-wall **Diglett** (95%) with a rare **Dugtrio** (5%) — catch both. Diglett/Dugtrio (Ground) are **immune to Electric**, so a Dugtrio also hard-counters Lt. Surge if you did the gym after this.

Exit the **north** end onto Route 2; the aide in the gatehouse gives **HM05 Flash** (need 10+ caught) — you’ll need Flash for Rock Tunnel soon. Then head to Cerulean and east onto **[[19 - Route 9]]**.

⬅️ **Prev:** [[17 - Route 11]] · ➡️ **Next:** [[19 - Route 9]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
