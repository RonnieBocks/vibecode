# 04 — Route 22

*A quiet path west — and an early rival rematch.*

![[04 - Route 22.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;">Route 23 → Pokémon League (locked)</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="03 - Viridian City" data-href="03 - Viridian City">Viridian City</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">45%</td><td style="padding:5px;color:#212121;">2/3/4/5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">45%</td><td style="padding:5px;color:#212121;">2/3/4/5</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">3/5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">20–25/25–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">— none</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Mankey</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Spearow</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Spearow → Fearow** — keep **2**
> - **Mankey → Primeape** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Catch a Mankey and a Spearow
> 2. Beat your rival
> 3. Return east to Viridian

Step onto the route and your **rival** ambushes you (team depends on the starter he chose):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ RIVAL — Route 22</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Bulbasaur</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">105</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 30 · Atk 17 · Def 16 · Sp.Atk 15 · Sp.Def 15 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">124</td><td style="padding:5px;color:#212121;">Scratch, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 30 · Atk 18 · Def 17 · Sp.Atk 20 · Sp.Def 18 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽144</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Charmander</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">105</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 30 · Atk 17 · Def 16 · Sp.Atk 15 · Sp.Def 15 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Squirtle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">126</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 31 · Atk 18 · Def 21 · Sp.Atk 18 · Sp.Def 21 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽144</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Squirtle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">105</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 30 · Atk 17 · Def 16 · Sp.Atk 15 · Sp.Def 15 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bulbasaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">123</td><td style="padding:5px;color:#212121;">Tackle, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 31 · Atk 18 · Def 18 · Sp.Atk 21 · Sp.Def 21 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽144</td></tr>
</table>

His Pidgey only chips with Sand-Attack; beat it, then his starter. Around **Level 9–10** this is easy.

Catch **Mankey** (Fighting — its Low Kick wrecks Brock’s Onix) and **Spearow** (→ Fearow). Spearow is only a **10% encounter**, so it can take a while — that's normal, not a bug.

**➡️ To progress:** Route 22 is a dead-end spur (the north gate to the League is locked until 8 badges). Head back **east to [[03 - Viridian City]]**, then walk **north** through the city — the old man by the top exit lets you pass — into **Route 2 → [[06 - Viridian Forest]]**.

## 🔒 Endgame — Route 22 rival rematch (all 8 badges)
*Ignore until the very end: after the 8th badge you cross Route 22 again toward Victory Road and your rival ambushes you here.*

Much later — once you have all 8 badges — your rival ambushes you here **again** on the way to Victory Road:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ RIVAL — Route 22 (endgame rematch)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Bulbasaur</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1731</td><td style="padding:5px;color:#212121;">Feather Dance, Wing Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 205 · Atk 150 · Def 146 · Sp.Atk 141 · Sp.Def 141 · Speed 161</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1300</td><td style="padding:5px;color:#212121;">Take Down, Horn Drill, Rock Blast, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 194 · Atk 149 · Def 158 · Sp.Atk 99 · Sp.Def 99 · Speed 95</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">945</td><td style="padding:5px;color:#212121;">Solar Beam, Sleep Powder, Poison Powder, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 176 · Atk 108 · Def 144 · Sp.Atk 126 · Sp.Def 113 · Speed 108</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">2062</td><td style="padding:5px;color:#212121;">Hydro Pump, Twister, Leer, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 208 · Atk 185 · Def 143 · Sp.Atk 126 · Sp.Def 162 · Speed 145</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1872</td><td style="padding:5px;color:#212121;">Psychic, Calm Mind, Future Sight, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 179 · Atk 122 · Def 117 · Sp.Atk 202 · Sp.Def 155 · Speed 188</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charizard</td><td style="padding:5px;color:#212121;">Fire/Flying</td><td style="padding:5px;color:#212121;">53</td><td style="padding:5px;color:#212121;">2373</td><td style="padding:5px;color:#212121;">Flamethrower, Wing Attack, Slash, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 278 · Atk 226 · Def 220 · Sp.Atk 253 · Sp.Def 227 · Speed 243</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1908</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Charmander</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1731</td><td style="padding:5px;color:#212121;">Feather Dance, Wing Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 205 · Atk 150 · Def 146 · Sp.Atk 141 · Sp.Def 141 · Speed 161</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1300</td><td style="padding:5px;color:#212121;">Take Down, Horn Drill, Rock Blast, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 194 · Atk 149 · Def 158 · Sp.Atk 99 · Sp.Def 99 · Speed 95</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">877</td><td style="padding:5px;color:#212121;">Flame Wheel, Take Down, Leer, Agility</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 172 · Atk 135 · Def 113 · Sp.Atk 135 · Sp.Def 117 · Speed 126</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">945</td><td style="padding:5px;color:#212121;">Solar Beam, Sleep Powder, Poison Powder, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 176 · Atk 108 · Def 144 · Sp.Atk 126 · Sp.Def 113 · Speed 108</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1872</td><td style="padding:5px;color:#212121;">Psychic, Calm Mind, Future Sight, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 179 · Atk 122 · Def 117 · Sp.Atk 202 · Sp.Def 155 · Speed 188</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Blastoise</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">53</td><td style="padding:5px;color:#212121;">2385</td><td style="padding:5px;color:#212121;">Water Gun, Rain Dance, Bite, Rapid Spin</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 279 · Atk 225 · Def 243 · Sp.Atk 227 · Sp.Def 248 · Speed 220</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1908</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Squirtle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1731</td><td style="padding:5px;color:#212121;">Feather Dance, Wing Attack, Gust, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 205 · Atk 150 · Def 146 · Sp.Atk 141 · Sp.Def 141 · Speed 161</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1300</td><td style="padding:5px;color:#212121;">Take Down, Horn Drill, Rock Blast, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 194 · Atk 149 · Def 158 · Sp.Atk 99 · Sp.Def 99 · Speed 95</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">2062</td><td style="padding:5px;color:#212121;">Hydro Pump, Twister, Leer, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 208 · Atk 185 · Def 143 · Sp.Atk 126 · Sp.Def 162 · Speed 145</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">877</td><td style="padding:5px;color:#212121;">Flame Wheel, Take Down, Leer, Agility</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 172 · Atk 135 · Def 113 · Sp.Atk 135 · Sp.Def 117 · Speed 126</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">1872</td><td style="padding:5px;color:#212121;">Psychic, Calm Mind, Future Sight, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 179 · Atk 122 · Def 117 · Sp.Atk 202 · Sp.Def 155 · Speed 188</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Venusaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">53</td><td style="padding:5px;color:#212121;">2361</td><td style="padding:5px;color:#212121;">Razor Leaf, Sweet Scent, Growth, Synthesis</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 280 · Atk 224 · Def 225 · Sp.Atk 243 · Sp.Def 243 · Speed 222</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1908</td></tr>
</table>

⬅️ **Prev:** [[03 - Viridian City]] · ➡️ **Next:** [[05 - Route 2]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- ~~On the Pokemon Table, one long row should seperate walking, fishing, etc pokemon from each other, so one row saying Walking and then list the pokemon that you get via grass and walking, and then a row that says fishing, and list all of the fishing pokemon etc. Apply this Walkthrough-wide.~~ — ✅ wild tables regrouped by method (🌿 Grass / 🏄 Surf / 🎣 Rod) walkthrough-wide
- ~~I wasn't paying enough attention, but the rival battle on Route 22 was innaccurate as well. Red got 123 XP for beating Bulbasaur with Squirtle (I don't know for Pidgey), and Red did get 144 money for winning.~~ — ✅ trainer-exp ×1.5 correction — 123 now shown
- ~~Again, it's not relevant to disclose the Victory Road battles here, its intimidating and not helpful this early in the game.~~ — ✅ endgame rival rematch moved to a bottom 🔒 Endgame section
- ~~It took me an extremely long time to encounter two Spearows, so just check that the encounter rates are correct.~~ — ✅ verified: Spearow is 10% (correct) — noted in the guide
- ~~It tells me to go back to Viridian City, but not where to go to get to Route 2. The user could look at the map, but they'd have to scroll up, so just make sure that it says in plain english where to go next to progress.~~ — ✅ explicit ‘To progress’ directions added