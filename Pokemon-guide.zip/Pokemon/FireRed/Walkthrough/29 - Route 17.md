# 29 — Route 17

*The Cycling Road proper — a downhill sprint past bikers.*

![[29 - Route 17.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="28 - Route 16" data-href="28 - Route 16">Route 16</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="30 - Route 18" data-href="30 - Route 18">Route 18</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">20/22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">24/26/28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">25/27/29</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">25/27</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Rare Candy, Full Restore, PP Up, Max Revive, Max Elixir</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Fearow</td></tr>
</table>

> [!todo] Do this in order
> 1. Ride the Bicycle south
> 2. Beat the Bikers & Cue Balls 1–10 (numbered on the map)
> 3. Sweep the hidden items along the guardrails

A long downhill road you can only traverse by **Bicycle**. It’s lined with **Bikers and Cue Balls** (numbered on the map):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 17</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Cue Ball Isaiah</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">546</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 51 · Def 34 · Sp.Atk 25 · Sp.Def 25 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machamp</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1198</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 80 · Def 51 · Sp.Atk 42 · Sp.Def 54 · Speed 36</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Biker Virgil</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1038</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 55 · Def 72 · Sp.Atk 52 · Sp.Def 44 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">684</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 41 · Def 58 · Sp.Atk 38 · Sp.Def 30 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1038</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 55 · Def 72 · Sp.Atk 52 · Sp.Def 44 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽560</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Cue Ball Raul</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">459</td><td style="padding:5px;color:#212121;">Karate Chop, Fury Swipes, Focus Energy, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 51 · Def 25 · Sp.Atk 25 · Sp.Def 31 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">925</td><td style="padding:5px;color:#212121;">Fury Swipes, Focus Energy, Seismic Toss, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 65 · Def 39 · Sp.Atk 39 · Sp.Def 45 · Speed 60</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Biker Billy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Muk</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1110</td><td style="padding:5px;color:#212121;">Disable, Sludge, Minimize, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 112 · Atk 74 · Def 54 · Sp.Atk 47 · Sp.Def 71 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽660</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Biker Nikolas</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">639</td><td style="padding:5px;color:#212121;">Spark, Sonic Boom, Screech, Charge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 22 · Def 34 · Sp.Atk 36 · Sp.Def 36 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">639</td><td style="padding:5px;color:#212121;">Spark, Sonic Boom, Screech, Charge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 22 · Def 34 · Sp.Atk 36 · Sp.Def 36 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽580</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Cue Ball Jamal</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">411</td><td style="padding:5px;color:#212121;">Karate Chop, Fury Swipes, Focus Energy, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 46 · Def 23 · Sp.Atk 23 · Sp.Def 28 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">411</td><td style="padding:5px;color:#212121;">Karate Chop, Fury Swipes, Focus Energy, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 46 · Def 23 · Sp.Atk 23 · Sp.Def 28 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machamp</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">1074</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 72 · Def 46 · Sp.Atk 38 · Sp.Def 49 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">489</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 46 · Def 31 · Sp.Atk 23 · Sp.Def 23 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽624</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Cue Ball Zeek</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1032</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 71 · Def 51 · Sp.Atk 38 · Sp.Def 44 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽792</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Cue Ball Corey</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">925</td><td style="padding:5px;color:#212121;">Fury Swipes, Focus Energy, Seismic Toss, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 65 · Def 39 · Sp.Atk 39 · Sp.Def 45 · Speed 60</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">906</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 63 · Def 45 · Sp.Atk 34 · Sp.Def 39 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Biker Jaxon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1074</td><td style="padding:5px;color:#212121;">Sludge, Smokescreen, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 57 · Def 74 · Sp.Atk 54 · Sp.Def 45 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Muk</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">975</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 99 · Atk 65 · Def 48 · Sp.Atk 42 · Sp.Def 63 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽580</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Biker William</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">610</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 37 · Def 52 · Sp.Atk 35 · Sp.Def 27 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">925</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 50 · Def 65 · Sp.Atk 47 · Sp.Def 40 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">610</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 37 · Def 52 · Sp.Atk 35 · Sp.Def 27 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">610</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 37 · Def 52 · Sp.Atk 35 · Sp.Def 27 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">925</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Self Destruct, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 50 · Def 65 · Sp.Atk 47 · Sp.Def 40 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽500</td></tr>
</table>

Their Koffing/Grimer/Voltorb are weak to Ground/Psychic. There’s a small fortune in **hidden items** tucked by the guardrails (Rare Candy, Full Restore, Max Revive, and more) — worth an Itemfinder sweep. Continue south to **[[30 - Route 18]]**.

⬅️ **Prev:** [[28 - Route 16]] · ➡️ **Next:** [[30 - Route 18]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
