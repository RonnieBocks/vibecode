# 35 — Fuchsia City

*Home of the Safari Zone, the Warden, and Koga’s poison gym.*

![[35 - Fuchsia City.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="30 - Route 18" data-href="30 - Route 18">Route 18</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="34 - Route 15" data-href="34 - Route 15">Route 15</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;">Sea Route 19 (Surf)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">20–25/25–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Good Rod (Fishing Guru’s brother)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">HM04 Strength (Warden — after you return the Gold Teeth)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">HM03 Surf (Safari Zone Secret House — see [[36 - Safari Zone]])</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Max Revive</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— Safari Zone catches are in [[36 - Safari Zone]]</td></tr>
</table>

> [!todo] Do this in order
> 1. Heal & shop
> 2. Get the Good Rod (Fishing Guru’s brother)
> 3. Do the Safari Zone (Surf, Gold Teeth → Strength, rare catches)
> 4. Return the Gold Teeth to the Warden for HM04 Strength
> 5. Beat Koga for the Soul Badge

Fuchsia is a hub of key items and rare Pokémon.

- **Good Rod** — from the **Fishing Guru’s brother**.
- **Safari Zone** (entrance north) — a huge catching area with **Scyther, Chansey, Kangaskhan, Tauros, Dratini** and more, plus **HM03 Surf** (Secret House) and the **Gold Teeth**. Full details in **[[36 - Safari Zone]]**.
- **Warden’s House** — give him the **Gold Teeth** (found in the Safari Zone) for **HM04 Strength**; then push the boulder inside for a **Rare Candy**.

**Fuchsia Gym — Koga (Poison).** Navigate the invisible-wall maze past his trainers:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ FUCHSIA GYM — Koga (Soul Badge)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Tamer Phil</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1186</td><td style="padding:5px;color:#212121;">Sand Attack, Poison Sting, Slash, Swift</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 108 · Atk 86 · Def 93 · Sp.Atk 49 · Sp.Def 56 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1071</td><td style="padding:5px;color:#212121;">Poison Sting, Bite, Glare, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 76 · Def 65 · Sp.Atk 62 · Sp.Def 72 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1360</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Tamer Edgar</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1039</td><td style="padding:5px;color:#212121;">Poison Sting, Bite, Glare, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 74 · Def 63 · Sp.Atk 61 · Sp.Def 70 · Speed 71</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1152</td><td style="padding:5px;color:#212121;">Sand Attack, Poison Sting, Slash, Swift</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 105 · Atk 84 · Def 90 · Sp.Atk 47 · Sp.Def 54 · Speed 61</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1039</td><td style="padding:5px;color:#212121;">Poison Sting, Bite, Glare, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 74 · Def 63 · Sp.Atk 61 · Sp.Def 70 · Speed 71</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1320</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Juggler Kirk</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">676</td><td style="padding:5px;color:#212121;">Headbutt, Poison Gas, Meditate, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 34 · Def 32 · Sp.Atk 31 · Sp.Def 60 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">676</td><td style="padding:5px;color:#212121;">Headbutt, Poison Gas, Meditate, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 34 · Def 32 · Sp.Atk 31 · Sp.Def 60 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">963</td><td style="padding:5px;color:#212121;">Psybeam, Reflect, Recover, Future Sight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 65 · Atk 26 · Def 23 · Sp.Atk 79 · Sp.Def 48 · Speed 70</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">676</td><td style="padding:5px;color:#212121;">Headbutt, Poison Gas, Meditate, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 34 · Def 32 · Sp.Atk 31 · Sp.Def 60 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1240</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Juggler Shawn</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">742</td><td style="padding:5px;color:#212121;">Headbutt, Poison Gas, Meditate, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 84 · Atk 37 · Def 35 · Sp.Atk 34 · Sp.Def 66 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hypno</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1201</td><td style="padding:5px;color:#212121;">Confusion, Headbutt, Poison Gas, Meditate</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 101 · Atk 54 · Def 52 · Sp.Atk 54 · Sp.Def 83 · Speed 50</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1360</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Juggler Kayden</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hypno</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1342</td><td style="padding:5px;color:#212121;">Headbutt, Poison Gas, Meditate, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 112 · Atk 60 · Def 58 · Sp.Atk 60 · Sp.Def 92 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1520</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Juggler Nate</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">742</td><td style="padding:5px;color:#212121;">Headbutt, Poison Gas, Meditate, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 84 · Atk 37 · Def 35 · Sp.Atk 34 · Sp.Def 66 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1056</td><td style="padding:5px;color:#212121;">Reflect, Recover, Future Sight, Role Play</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 71 · Atk 28 · Def 25 · Sp.Atk 86 · Sp.Def 52 · Speed 76</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1360</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Leader Koga</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">903</td><td style="padding:5px;color:#212121;">Self Destruct, Sludge, Smokescreen, Toxic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 53 · Def 75 · Sp.Atk 49 · Sp.Def 38 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Muk</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">1311</td><td style="padding:5px;color:#212121;">Minimize, Sludge, Acid Armor, Toxic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 130 · Atk 86 · Def 63 · Sp.Atk 55 · Sp.Def 83 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">903</td><td style="padding:5px;color:#212121;">Self Destruct, Sludge, Smokescreen, Toxic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 53 · Def 75 · Sp.Atk 49 · Sp.Def 38 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">43</td><td style="padding:5px;color:#212121;">1593</td><td style="padding:5px;color:#212121;">Tackle, Sludge, Smokescreen, Toxic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 108 · Atk 82 · Def 108 · Sp.Atk 78 · Sp.Def 65 · Speed 56</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽4300</td></tr>
</table>

**Psychic** moves dominate his Koffing/Muk/Weezing; bring **Antidotes** (his Toxic stacks fast). Winning gives the **Soul Badge** (Speed boost; lets you use **Surf**) and **TM06 Toxic**. Next, gear up and Surf south from Fuchsia toward Cinnabar — or head to Saffron for Silph Co.

⬅️ **Prev:** [[34 - Route 15]] · ➡️ **Next:** [[36 - Safari Zone]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
