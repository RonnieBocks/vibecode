# 36 — Safari Zone

*A vast preserve of rare Pokémon — and two hidden HMs’ worth of prizes.*

![[36 - Safari Zone Center.svg]]
*Center*

![[36 - Safari Zone East.svg]]
*East*

![[36 - Safari Zone North.svg]]
*North*

![[36 - Safari Zone West.svg]]
*West*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance / Exit</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="35 - Fuchsia City" data-href="35 - Fuchsia City">Fuchsia City</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass · Center</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">24–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Venonat</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidorino</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidorina</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Parasect</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Scyther 🔴</td><td style="padding:5px;color:#212121;">Bug/Flying</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">23</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Chansey</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">23</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass · East</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">24</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">23–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Paras</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidorino</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">33</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidoran♀</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">24</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Parasect</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Kangaskhan</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Scyther 🔴</td><td style="padding:5px;color:#212121;">Bug/Flying</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">28</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass · North</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">25–27</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Paras</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">23</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidorino</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidorina</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Venomoth</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Chansey</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tauros</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">28</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass · West</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">25–27</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Venonat</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">23</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidorino</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidoran♀</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Venomoth</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tauros</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Kangaskhan</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">28</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">20–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Dratini</td><td style="padding:5px;color:#212121;">Dragon</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">15–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Dragonair</td><td style="padding:5px;color:#212121;">Dragon</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Center: Nugget · Hidden: Leaf Stone</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">East: Max Potion, Full Restore, TM11 Sunny Day, Leaf Stone</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">North: Protein, TM47 Steel Wing, Quick Claw</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">West: Gold Teeth, TM32 Double Team, Max Potion, Max Revive · Hidden: Revive</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Secret House (far West): HM03 Surf</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Rhyhorn</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Exeggcute</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Nidorina</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Nidorino</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Parasect</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Scyther 🔴</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Chansey</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Kangaskhan</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Tauros</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Venomoth</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Dratini</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Dragonair</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Venonat → Venomoth** — keep **2**
> - **Exeggcute → Exeggutor** — keep **2**
> - **Rhyhorn → Rhydon** — keep **2**
> - **Dratini → Dragonair → Dragonite** — keep **3**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Pay ₽500 to enter (you get 30 Safari Balls & 500 steps)
> 2. Grab the Gold Teeth (West) → return to the Warden for HM04 Strength
> 3. Get HM03 Surf from the Secret House (far West)
> 4. Hunt the rares: Scyther, Chansey, Kangaskhan, Tauros, Dratini
> 5. Collect the items (Leaf Stone, TMs, stat items)

> [!warning] Safari rules
> Pay **₽500** to enter. You get **30 Safari Balls** and **500 steps** — when either runs out, you’re booted. You **don’t battle**: each turn you can throw a **Ball**, toss **Bait** (makes it stay but harder to catch), throw a **Rock** (easier to catch but more likely to flee), or approach. There’s no fainting or HP — it’s pure catch-or-flee.

The Safari Zone is the single best catching spot in the game, spread over four areas (maps above). Priorities:

- **HM03 Surf** — in the **Secret House** at the far end of the **West** area (Surf south from the West area’s water to reach it). This unlocks Surfing (with the Soul Badge).
- **Gold Teeth** — an item on the ground in the **West** area. Return it to the **Warden** in Fuchsia for **HM04 Strength**.
- **Rare Pokémon** — **Scyther** 🔴 (Center 4%), **Chansey** (North 4%), **Kangaskhan** (East 4%), **Tauros** (North 4%), **Rhyhorn**, **Exeggcute**, and mid-stage **Nidorino/Nidorina/Parasect/Venomoth**. Fish the water with the **Super Rod** for **Dratini** (15%) and a rare **Dragonair** — the Dratini line is a huge prize here.
- **Items** — a **Leaf Stone** (evolves Exeggcute/Gloom/Weepinbell), TMs (Sunny Day, Steel Wing, Double Team), and stat boosters.

Catching tip: for the rares, throw a **Rock** then a **Ball** — the rock boosts catch rate (but watch the higher flee chance). Bait keeps them around at the cost of catch rate.

When you’re done (and have Surf + Strength sorted), return to Fuchsia. Next up: **Saffron City / Silph Co. (Sabrina)**, or Surf south toward **Cinnabar**.

⬅️ **Prev:** [[35 - Fuchsia City]] · ➡️ **Next:** [[37 - Saffron City]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
