# 💎 A2 — Evolution-Item Budget

*Which stones evolve which Pokémon, how many you need for a full Living Dex, and where they come from.*
Back to [[00 - Index & Basics]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#2e7d32;color:#fff;padding:7px;text-align:center;font-size:1.05em;">💡 THE ONE THING TO PLAN</th></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;"><b>Only the Moon Stone needs planning.</b> Fire / Water / Thunder / Leaf Stones are sold <b>unlimited</b> at the Celadon Dept. Store 4F for ₽2,100 each. The Moon Stone is <b>never sold</b> — there are exactly 4 fixed ones, matching the 4 Moon-Stone evolutions.</td></tr>
</table>

## Stone → evolution chart (151-relevant)
<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#2e7d32;color:#fff;padding:7px;text-align:center;font-size:1.05em;">STONE EVOLUTIONS</th></tr>
<tr><th style="background:#2e7d32;color:#fff;padding:5px;text-align:left;">Stone</th><th style="background:#2e7d32;color:#fff;padding:5px;text-align:left;">Evolution</th><th style="background:#2e7d32;color:#fff;padding:5px;text-align:left;">Need</th><th style="background:#2e7d32;color:#fff;padding:5px;text-align:left;">Notes</th></tr>
<tr><th colspan="4" style="background:#5fa564;color:#fff;padding:5px;text-align:left;">🌙 Moon Stone — NOT sold. Exactly 4 findable = exactly enough.</th></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Moon Stone</td><td style="padding:5px;color:#212121;">Nidorina → <b>Nidoqueen</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;">Also evolves Nidorino, Clefairy, Jigglypuff.</td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Moon Stone</td><td style="padding:5px;color:#212121;">Nidorino → <b>Nidoking</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Moon Stone</td><td style="padding:5px;color:#212121;">Clefairy → <b>Clefable</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Moon Stone</td><td style="padding:5px;color:#212121;">Jigglypuff → <b>Wigglytuff</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr><th colspan="4" style="background:#5fa564;color:#fff;padding:5px;text-align:left;">🔥 Fire Stone — buyable at Celadon Dept. Store 4F (₽2,100)</th></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Fire Stone</td><td style="padding:5px;color:#212121;">Growlithe → <b>Arcanine</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Fire Stone</td><td style="padding:5px;color:#212121;">Vulpix → <b>Ninetales</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;">Vulpix is LeafGreen-only (trade/save-edit).</td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Fire Stone</td><td style="padding:5px;color:#212121;">Eevee → <b>Flareon</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr><th colspan="4" style="background:#5fa564;color:#fff;padding:5px;text-align:left;">💧 Water Stone — buyable at Celadon 4F (₽2,100)</th></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Water Stone</td><td style="padding:5px;color:#212121;">Poliwhirl → <b>Poliwrath</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Water Stone</td><td style="padding:5px;color:#212121;">Shellder → <b>Cloyster</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Water Stone</td><td style="padding:5px;color:#212121;">Staryu → <b>Starmie</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;">Staryu is LeafGreen-only (trade/save-edit).</td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Water Stone</td><td style="padding:5px;color:#212121;">Eevee → <b>Vaporeon</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr><th colspan="4" style="background:#5fa564;color:#fff;padding:5px;text-align:left;">⚡ Thunder Stone — buyable at Celadon 4F (₽2,100)</th></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Thunder Stone</td><td style="padding:5px;color:#212121;">Pikachu → <b>Raichu</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Thunder Stone</td><td style="padding:5px;color:#212121;">Eevee → <b>Jolteon</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr><th colspan="4" style="background:#5fa564;color:#fff;padding:5px;text-align:left;">🍃 Leaf Stone — buyable at Celadon 4F (₽2,100)</th></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Leaf Stone</td><td style="padding:5px;color:#212121;">Gloom → <b>Vileplume</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Leaf Stone</td><td style="padding:5px;color:#212121;">Weepinbell → <b>Victreebel</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;">Weepinbell is LeafGreen-only (trade/save-edit).</td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Leaf Stone</td><td style="padding:5px;color:#212121;">Exeggcute → <b>Exeggutor</b></td><td style="padding:5px;color:#212121;">1</td><td style="padding:5px;color:#212121;"></td></tr>
</table>

## The 4 fixed Moon Stones
<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="3" style="background:#2e7d32;color:#fff;padding:7px;text-align:center;font-size:1.05em;">MOON STONE LOCATIONS</th></tr>
<tr><th style="background:#2e7d32;color:#fff;padding:5px;text-align:left;">Where</th><th style="background:#2e7d32;color:#fff;padding:5px;text-align:left;">Area</th><th style="background:#2e7d32;color:#fff;padding:5px;text-align:left;">Type</th></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Mt. Moon 1F</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="10 - Mt. Moon" data-href="10 - Mt. Moon">Mt. Moon</a></td><td style="padding:5px;color:#212121;">Item ball</td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Mt. Moon B2F</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="10 - Mt. Moon" data-href="10 - Mt. Moon">Mt. Moon</a></td><td style="padding:5px;color:#212121;">Hidden</td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Rocket Hideout B2F</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="26 - Rocket Hideout" data-href="26 - Rocket Hideout">Rocket Hideout</a></td><td style="padding:5px;color:#212121;">Item ball</td></tr>
<tr style="background:#e9f5ea;"><td style="padding:5px;color:#212121;">Pokémon Mansion 1F</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="43 - Pokémon Mansion" data-href="43 - Pokémon Mansion">Pokémon Mansion</a></td><td style="padding:5px;color:#212121;">Hidden</td></tr>
</table>
Want spares? Wild <b>Clefairy</b> in Mt. Moon and some Poison-types can hold a Moon Stone — catch or use Thief to farm extras.

## Eevee math (important)
You only get <b>one</b> Eevee, but a Living Dex needs Vaporeon + Jolteon + Flareon <b>and</b> a spare Eevee. Plan for <b>4 Eevee total</b> (breed 3 more via Ditto) and one each of Water / Thunder / Fire Stone for them.

## Living-Dex stone shopping list (Celadon 4F)
- <b>Fire Stone ×3</b> — Arcanine, Ninetales, Flareon
- <b>Water Stone ×4</b> — Poliwrath, Cloyster, Starmie, Vaporeon
- <b>Thunder Stone ×2</b> — Raichu, Jolteon
- <b>Leaf Stone ×3</b> — Vileplume, Victreebel, Exeggutor
- <b>Moon Stone ×4</b> — Nidoqueen, Nidoking, Clefable, Wigglytuff (the 4 fixed finds above)

<i>Note: to keep both a pre-evolution and its evolved form at once (a true Living Dex), you'll need an extra copy of each pre-evo — that's a catching/breeding job, not extra stones.</i>


---
*Appendices index: [[00 - Index & Basics#📚 Appendices]] · Back to [[Pokemon FireRed]]*
