# 🔥 FireRed Complete Walkthrough — Index & Basics

A full, leave-nothing-to-question walkthrough. **One file per area**, each opening with: **Map → Connections → Wild Pokémon (all methods) → Items → New Pokémon**, then conversational, hand-held step-by-step.
Back to [[Pokemon FireRed]]

> [!info] About this guide
> - **Guide version:** **v1.6** — see [[CHANGELOG]] for the full history.
> - **Game version:** Pokémon **FireRed (USA), Rev 0** — your cart (verified by ROM MD5 `e26ee0d4…`). Data is identical on Rev 0/1.
> - **Data source:** the **pret/pokefirered decompilation** — exact trainer teams, levels, moves, encounter rates, and item placements. Original text.
> - **Maps:** original **true-scale color-block SVGs** rendered from the game's layout data (not the game's artwork), with numbered trainers, ledges, exits, and a legend on each map. Paired with a **Connections** table and exact in-area positions.

## 🔑 Legend
- **L##** = level · moves in `{ }` = actual moveset.
- 🎯 dex-worthy · 🔴 FireRed-exclusive · 🔵 LeafGreen-exclusive · ⚠️ missable/one-time · 🧭 HM.
- Wild **%** = combined chance for that method. Methods: **Grass, Surf, Old/Good/Super Rod, Gift, Static/Event**.

## 🗺️ Map legend
Each area file opens with a true-scale terrain map rendered from the game's layout data (original color-blocks — not the game's artwork).

| Tile     | Meaning                      |     | Marker | Meaning                    |             |
| -------- | ---------------------------- | --- | ------ | -------------------------- | ----------- |
| 🟫 gray  | tree / cliff / wall          |     | **D**  | door (building entrance)   |             |
| 🟫 brown | building                     |     | **I**  | item (Poké Ball on ground) |             |
| 🟨 tan   | walkable path/ground         |     | **T**  | trainer                    |             |
| 🟩 green | tall grass (wild encounters) |     | **N**  | NPC                        |             |
| 🟦 blue  | water (Surf/fishing)         |     | **s**  | sign · **H**               | hidden item |

Blue text arrows around the edges (▲N / ▼S / ◀W / ▶E) mark the exits and where they lead.

---

# 📑 Table of Contents (per-area files)

**Basics** — this file.

**Region 1 — Kanto West**
- [[01 - Pallet Town]] ✅
- [[02 - Route 1]] ✅ · [[03 - Viridian City]] ✅ · [[04 - Route 22]] ✅ · [[05 - Route 2]] ✅
- [[06 - Viridian Forest]] ✅ · [[07 - Pewter City]] ✅
- [[08 - Route 3]] ✅ · [[09 - Route 4]] ✅ · [[10 - Mt. Moon]] ✅
- [[11 - Cerulean City]] ✅ · [[12 - Route 24]] ✅ · [[13 - Route 25]] ✅
- [[14 - Route 5]] ✅ · [[15 - Route 6]] ✅ · [[16 - Vermilion City]] ✅
- [[17 - Route 11]] ✅ · [[18 - Diglett’s Cave]] ✅ · [[19 - Route 9]] ✅ · [[20 - Route 10]] ✅
- [[21 - Rock Tunnel]] ✅ · [[22 - Lavender Town]] ✅
- [[23 - Route 8]] ✅ · [[24 - Route 7]] ✅ · [[25 - Celadon City]] ✅ · [[26 - Rocket Hideout]] ✅
- [[27 - Pokémon Tower]] ✅
- [[28 - Route 16]] ✅ · [[29 - Route 17]] ✅ · [[30 - Route 18]] ✅ (Cycling Road)
- [[31 - Route 12]] ✅ · [[32 - Route 13]] ✅ · [[33 - Route 14]] ✅ · [[34 - Route 15]] ✅
- [[35 - Fuchsia City]] ✅ (Koga)
- [[36 - Safari Zone]] ✅
- [[37 - Saffron City]] ✅ (Sabrina) · [[38 - Silph Co.]] ✅
- [[39 - Sea Route 19]] ✅ · [[40 - Sea Route 20]] ✅ · [[41 - Seafoam Islands]] ✅ (Articuno)
- [[42 - Cinnabar Island]] ✅ (Blaine) · [[43 - Pokémon Mansion]] ✅
- Viridian Gym (Giovanni) — in [[03 - Viridian City]] ✅ · [[44 - Victory Road]] ✅ · [[45 - Elite Four & Champion]] ✅
**Post-game**
- [[46 - One Island]] ✅ · [[47 - Kindle Road]] ✅ · [[48 - Mt. Ember]] ✅ (Moltres)
- [[49 - Two Island]] ✅ · [[50 - Three Island]] ✅ · [[51 - Berry Forest]] ✅
- [[52 - Power Plant]] ✅ (Zapdos) · [[53 - Cerulean Cave]] ✅ (Mewtwo)
- [[54 - Four Island]] ✅ (Icefall Cave, HM07) · [[55 - Five Island]] ✅ (Rocket Warehouse, Sapphire)
- [[56 - Six Island]] ✅ (Dotted Hole) · [[57 - Seven Island]] ✅ (Tanoby Ruins / Unown)

**🎉 Guide complete — Pallet Town through the full Sevii post-game (57 areas).**

## 📚 Appendices
Cross-area reference pages for the Living-Dex hunt — all built from the pret/pokefirered decompilation.
- [[A1 - Missables]] ⚠️ — statics (2 Snorlax, the 3 birds, Mewtwo), one-time gifts, pick-one forks, the lone Master Ball.
- [[A2 - Evolution Item Budget]] 💎 — every stone, who it evolves, how many you need, where they come from (only the Moon Stone needs planning).
- [[A3 - Trades & Exclusives]] 🔄 — the 13 LeafGreen exclusives, 4 trade evolutions, in-game NPC trades, and your solo save-edit checklist.
- [[A4 - Hidden Items]] 🔍 — every hidden item in the game, by area.

*Maintainer note: [[_BUILD_PLAYBOOK]] documents how this guide is generated (data sources, engine code, formatting spec, gotchas, and the full area list) — the recipe to rebuild it fast.*

*(Remaining areas — through Fuchsia, Saffron, Cinnabar, the Sevii Islands, and the League — get their own files as we build forward. Each links back here.)*

---

# 🎮 Game Basics

## Controls
**A** interact · **B** cancel / hold to run (with Running Shoes) · **Start** menu · **Select** use registered Key Item.

## The three starters
| Starter | Type | Final | Early game |
|---------|------|-------|-----------|
| **Bulbasaur** | Grass/Poison | Venusaur | Easiest — beats Brock **&** Misty |
| **Squirtle** | Water | Blastoise | Balanced; hard-counters Brock |
| **Charmander** | Fire | Charizard | Hardest start, strong later |

Your **rival takes the starter that beats yours**.

## Catching
Lower **HP** (aim red) and/or apply **status** (Sleep/Freeze best, then Para/Poison/Burn). Ball strength: Poké < Great < Ultra. Can't catch in trainer battles.

## 🏠 Living Dex — collecting as you go
The goal isn't just to *register* all 151 — it's to **hold one of every species at once, including every evolution stage**. That changes how you catch:
- A family with **S stages needs S individuals** held together. To have Caterpie **and** Metapod **and** Butterfree, you must obtain **3** Caterpie-line creatures (keep one, evolve the others up) — evolving your only copy *loses* the earlier stage.
- So **catch spares of each new line while you're in its area** — wild Pokémon get rarer/left-behind later. Each area file has a **🏠 Living Dex callout** under its New Pokémon table telling you how many of each new line to keep.
- **Eevee** needs **4** (Eevee + Vaporeon/Jolteon/Flareon — one of each stone; see [[A2 - Evolution Item Budget]]). **Starters** you only get one of — breed spares with Ditto later, and save-edit the other two lines.
- Track held copies with the `×N` counter in [[Pokedex Tracker]]; individuals live in [[Team & Boxes]]. What you can't get solo (13 LG-exclusives, 4 trade-evos, alt picks, Mew) is in [[A3 - Trades & Exclusives]].

## Status
Sleep/Freeze = can't act · Paralysis = 25% skip + Speed down · Poison = chip (also while walking) · Burn = chip + halves physical Attack. Cure with items or a Pokémon Center.

## Stats (Gen 3)
HP / Attack / Defense / Sp. Atk / Sp. Def / Speed. Physical vs special is set **by the move's type** (e.g. all Water = special, all Normal = physical).

## Type effectiveness (key matchups)
- **Water** ▸ Fire/Ground/Rock; weak Grass/Electric
- **Grass** ▸ Water/Ground/Rock; weak Fire/Ice/Poison/Flying/Bug
- **Fire** ▸ Grass/Ice/Bug/Steel; weak Water/Ground/Rock
- **Electric** ▸ Water/Flying; **no effect Ground**
- **Ground** ▸ Fire/Electric/Poison/Rock/Steel; **no effect Flying**
- **Fighting** ▸ Normal/Ice/Rock/Dark/Steel; **no effect Ghost**
- **Psychic** ▸ Fighting/Poison; weak Bug/Ghost/Dark
- **Flying** ▸ Grass/Fighting/Bug; weak Electric/Ice/Rock
- **Rock** ▸ Fire/Ice/Flying/Bug; weak Water/Grass/Fighting/Ground/Steel
- **Ice** ▸ Grass/Ground/Flying/Dragon; weak Fire/Fighting/Rock/Steel
- Ghost/Normal can't hit each other's immunities; **Normal/Fighting can't hit Ghost**.

## HMs (field use, badge-gated)
Cut (Cascade) · Fly (Thunder) · Surf (Soul) · Strength (Rainbow) · Flash (Boulder) · Rock Smash (Marsh) · Waterfall (Volcano).

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
