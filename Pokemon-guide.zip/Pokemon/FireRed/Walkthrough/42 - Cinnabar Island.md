# 42 — Cinnabar Island

*A volcanic isle — the fossil lab, a burning mansion, and Blaine.*

![[42 - Cinnabar Island.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North (Surf)</td><td style="padding:5px;color:#212121;">Sea Route 21 → Pallet Town</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="40 - Sea Route 20" data-href="40 - Sea Route 20">Sea Route 20</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Building</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="43 - Pokémon Mansion" data-href="43 - Pokémon Mansion">Pokémon Mansion</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Shellder 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Pokémon Lab: revive fossils → Omanyte / Kabuto / Aerodactyl</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Pokémon Lab: in-game trades (e.g. Venonat → Tangela, Raichu ↔ Electrode)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Secret Key (from the Pokémon Mansion — needed for the gym)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Omanyte / Kabuto (revive your fossil)</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Aerodactyl (revive Old Amber)</td></tr>
</table>

> [!todo] Do this in order
> 1. Revive your fossils at the Pokémon Lab
> 2. Do the Lab in-game trades (Tangela, etc.)
> 3. Clear the Pokémon Mansion for the Secret Key
> 4. Beat Blaine for the Volcano Badge

Cinnabar is home to the **Pokémon Lab** (bottom-left), where scientists **revive fossils** into Pokémon: your **Helix → Omanyte** or **Dome → Kabuto**, and the **Old Amber → Aerodactyl** (buy the Old Amber at the Pewter Museum first). The Lab also runs **in-game trades** — notably **Venonat → Tangela** for a free dex entry.

The gym is **locked** until you find the **Secret Key** in the **[[43 - Pokémon Mansion]]** (the big building) — do that first.

**Cinnabar Gym — Blaine (Fire).** He guards the way with **quiz doors** (answer to open, or battle the trainer):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ CINNABAR GYM — Blaine (Volcano Badge)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Super Nerd Erik</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">486</td><td style="padding:5px;color:#212121;">Confuse Ray, Imprison, Flamethrower, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 34 · Def 33 · Sp.Atk 41 · Sp.Def 51 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">486</td><td style="padding:5px;color:#212121;">Confuse Ray, Imprison, Flamethrower, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 34 · Def 33 · Sp.Atk 41 · Sp.Def 51 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ninetales</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">1372</td><td style="padding:5px;color:#212121;">Ember, Quick Attack, Confuse Ray, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 59 · Def 59 · Sp.Atk 63 · Sp.Def 77 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽864</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Super Nerd Avery</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ponyta</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1107</td><td style="padding:5px;color:#212121;">Ember, Stomp, Fire Spin, Take Down</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 62 · Def 42 · Sp.Atk 49 · Sp.Def 49 · Speed 66</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">472</td><td style="padding:5px;color:#212121;">Metal Claw, Smokescreen, Scary Face, Flamethrower</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 70 · Atk 40 · Def 34 · Sp.Atk 45 · Sp.Def 39 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">459</td><td style="padding:5px;color:#212121;">Confuse Ray, Imprison, Flamethrower, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 32 · Def 32 · Sp.Atk 39 · Sp.Def 49 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">663</td><td style="padding:5px;color:#212121;">Leer, Odor Sleuth, Take Down, Flame Wheel</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 52 · Def 35 · Sp.Atk 52 · Sp.Def 39 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽816</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Super Nerd Derek</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rapidash</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">41</td><td style="padding:5px;color:#212121;">1686</td><td style="padding:5px;color:#212121;">Fire Spin, Take Down, Agility, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 104 · Atk 87 · Def 62 · Sp.Atk 70 · Sp.Def 70 · Speed 91</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽984</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Super Nerd Zac</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">721</td><td style="padding:5px;color:#212121;">Odor Sleuth, Take Down, Flame Wheel, Helping Hand</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 87 · Atk 56 · Def 38 · Sp.Atk 56 · Sp.Def 42 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">499</td><td style="padding:5px;color:#212121;">Imprison, Flamethrower, Safeguard, Grudge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 75 · Atk 35 · Def 34 · Sp.Atk 42 · Sp.Def 53 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽888</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Burglar Quinn</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">702</td><td style="padding:5px;color:#212121;">Leer, Odor Sleuth, Take Down, Flame Wheel</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 55 · Def 37 · Sp.Atk 55 · Sp.Def 41 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">486</td><td style="padding:5px;color:#212121;">Confuse Ray, Imprison, Flamethrower, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 34 · Def 33 · Sp.Atk 41 · Sp.Def 51 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ninetales</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">1372</td><td style="padding:5px;color:#212121;">Ember, Quick Attack, Confuse Ray, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 59 · Def 59 · Sp.Atk 63 · Sp.Def 77 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽3168</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Burglar Ramon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ponyta</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">41</td><td style="padding:5px;color:#212121;">1335</td><td style="padding:5px;color:#212121;">Stomp, Fire Spin, Take Down, Agility</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 92 · Atk 74 · Def 50 · Sp.Atk 58 · Sp.Def 58 · Speed 78</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽3608</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Burglar Dusty</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">499</td><td style="padding:5px;color:#212121;">Imprison, Flamethrower, Safeguard, Grudge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 75 · Atk 35 · Def 34 · Sp.Atk 42 · Sp.Def 53 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">721</td><td style="padding:5px;color:#212121;">Odor Sleuth, Take Down, Flame Wheel, Helping Hand</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 87 · Atk 56 · Def 38 · Sp.Atk 56 · Sp.Def 42 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽3256</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Leader Blaine</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">819</td><td style="padding:5px;color:#212121;">Bite, Roar, Take Down, Fire Blast</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 63 · Def 42 · Sp.Atk 63 · Sp.Def 47 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ponyta</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">1302</td><td style="padding:5px;color:#212121;">Stomp, Bounce, Fire Spin, Fire Blast</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 90 · Atk 73 · Def 49 · Sp.Atk 57 · Sp.Def 57 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rapidash</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1728</td><td style="padding:5px;color:#212121;">Stomp, Bounce, Fire Spin, Fire Blast</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 106 · Atk 89 · Def 63 · Sp.Atk 72 · Sp.Def 72 · Speed 93</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arcanine</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">2145</td><td style="padding:5px;color:#212121;">Bite, Roar, Take Down, Fire Blast</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 141 · Atk 108 · Def 80 · Sp.Atk 99 · Sp.Def 80 · Speed 94</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽4700</td></tr>
</table>

Blaine's Fire team (Arcanine, Rapidash, etc.) is walled hard by **Water** — your Lapras/Blastoise/Gyarados sweep him; watch **Fire Blast**. Winning gives the **Volcano Badge** (lets you use **Waterfall**) and **TM38 Fire Blast**.

⬅️ **Prev:** [[41 - Seafoam Islands]] · ➡️ **Next:** [[43 - Pokémon Mansion]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
