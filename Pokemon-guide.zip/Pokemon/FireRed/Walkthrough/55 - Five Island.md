# 55 — Five Island

*Rocket’s last stand — recover the Sapphire, and explore the Lost Cave.*

![[55 - Five Island.svg]]
*Five Island*

![[55 - Five Island Meadow.svg]]
*Five Island Meadow*

![[55 - Rocket Warehouse.svg]]
*Rocket Warehouse*

![[55 - Resort Gorgeous.svg]]
*Resort Gorgeous*

![[55 - Lost Cave.svg]]
*Lost Cave*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Harbor</td><td style="padding:5px;color:#212121;">Ferry</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Meadow/Warehouse</td><td style="padding:5px;color:#212121;">Rocket Warehouse</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Resort</td><td style="padding:5px;color:#212121;">Lost Cave / Resort Gorgeous</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">44</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Sentret</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">10/15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">48/50</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Hoppip</td><td style="padding:5px;color:#212121;">Grass/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">10/15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">41</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">41</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">47/50</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">65%</td><td style="padding:5px;color:#212121;">5–35/35–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Hoppip</td><td style="padding:5px;color:#212121;">Grass/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacruel</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Qwilfish</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Meadow: Max Potion, PP Up</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Rocket Warehouse: Big Pearl, TM36 Sludge Bomb, Pearl, Up-Grade · Hidden: Nest Ball, Net Ball</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Resort Gorgeous / Lost Cave: hidden Star Piece, Stardust, Nest Ball</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— none (Johto mons + the Sapphire quest)</td></tr>
</table>

> [!todo] Do this in order
> 1. Cross the Meadow, beating the Rockets
> 2. Storm the Rocket Warehouse — beat the Grunts, Scientist, and two Admins
> 3. Recover the Sapphire → give it to Celio (One Island)
> 4. Explore the Lost Cave for Selphy’s reward

The **Meadow** leads to the **Rocket Warehouse**, where Team Rocket has hidden the stolen **Sapphire**. Fight through the Meadow guards:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TEAM ROCKET — Meadow</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1197</td><td style="padding:5px;color:#212121;">Memento, Haze, Smokescreen, Sludge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 98 · Atk 68 · Def 98 · Sp.Atk 63 · Sp.Def 49 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1816</td><td style="padding:5px;color:#212121;">Haze, Smokescreen, Sludge, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 122 · Atk 93 · Def 122 · Sp.Atk 88 · Sp.Def 73 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1568</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">585</td><td style="padding:5px;color:#212121;">Focus Energy, Pursuit, Super Fang, Endeavor</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 86 · Atk 58 · Def 38 · Sp.Atk 29 · Sp.Def 38 · Speed 74</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">925</td><td style="padding:5px;color:#212121;">Minimize, Screech, Acid Armor, Sludge Bomb</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 134 · Atk 81 · Def 53 · Sp.Atk 43 · Sp.Def 53 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Muk</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1614</td><td style="padding:5px;color:#212121;">Minimize, Screech, Acid Armor, Sludge Bomb</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 158 · Atk 105 · Def 77 · Sp.Atk 67 · Sp.Def 101 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1536</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">637</td><td style="padding:5px;color:#212121;">Stockpile, Swallow, Spit Up, Haze</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 115 · Atk 86 · Def 71 · Sp.Atk 67 · Sp.Def 80 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gloom</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1357</td><td style="padding:5px;color:#212121;">Sleep Powder, Acid, Moonlight, Petal Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 91 · Def 96 · Sp.Atk 110 · Sp.Def 101 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gloom</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1357</td><td style="padding:5px;color:#212121;">Sleep Powder, Acid, Moonlight, Petal Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 91 · Def 96 · Sp.Atk 110 · Sp.Def 101 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1536</td></tr>
</table>

Then clear the Warehouse — Grunts, a Scientist, and two **Team Rocket Admins**:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TEAM ROCKET — Warehouse</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Scientist Gideon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">1014</td><td style="padding:5px;color:#212121;">Swift, Screech, Spark, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 92 · Atk 32 · Def 51 · Sp.Atk 55 · Sp.Def 55 · Speed 97</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">1477</td><td style="padding:5px;color:#212121;">Spark, Sonic Boom, Screech, Charge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 111 · Atk 51 · Def 69 · Sp.Atk 78 · Sp.Def 78 · Speed 133</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">876</td><td style="padding:5px;color:#212121;">Screech, Swift, Spark, Thunder Wave</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 37 · Def 69 · Sp.Atk 92 · Sp.Def 55 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">1587</td><td style="padding:5px;color:#212121;">Tri Attack, Spark, Thunder Wave, Sonic Boom</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 102 · Atk 60 · Def 92 · Sp.Atk 115 · Sp.Def 69 · Speed 69</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Porygon</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">46</td><td style="padding:5px;color:#212121;">1281</td><td style="padding:5px;color:#212121;">Tri Attack, Conversion, Recover, Psybeam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 115 · Atk 60 · Def 69 · Sp.Atk 83 · Sp.Def 74 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2208</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Houndour</td><td style="padding:5px;color:#212121;">Dark/Fire</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1197</td><td style="padding:5px;color:#212121;">Odor Sleuth, Faint Attack, Flamethrower, Crunch</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 103 · Atk 63 · Def 34 · Sp.Atk 83 · Sp.Def 54 · Speed 68</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Houndour</td><td style="padding:5px;color:#212121;">Dark/Fire</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1197</td><td style="padding:5px;color:#212121;">Odor Sleuth, Faint Attack, Flamethrower, Crunch</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 103 · Atk 63 · Def 34 · Sp.Atk 83 · Sp.Def 54 · Speed 68</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1568</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">904</td><td style="padding:5px;color:#212121;">Vital Throw, Submission, Cross Chop, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 125 · Atk 81 · Def 53 · Sp.Atk 38 · Sp.Def 38 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">904</td><td style="padding:5px;color:#212121;">Vital Throw, Submission, Cross Chop, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 125 · Atk 81 · Def 53 · Sp.Atk 38 · Sp.Def 38 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1501</td><td style="padding:5px;color:#212121;">Revenge, Vital Throw, Submission, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 134 · Atk 101 · Def 72 · Sp.Atk 53 · Sp.Def 62 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1536</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Team Rocket Grunt Admin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">53</td><td style="padding:5px;color:#212121;">1941</td><td style="padding:5px;color:#212121;">Confuse Ray, Sludge Bomb, Air Cutter, Shadow Ball</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 248 · Atk 195 · Def 185 · Sp.Atk 179 · Sp.Def 190 · Speed 206</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">2001</td><td style="padding:5px;color:#212121;">Sludge Bomb, Thunderbolt, Explosion, Shadow Ball</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 242 · Atk 210 · Def 242 · Sp.Atk 204 · Sp.Def 188 · Speed 177</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Houndoom</td><td style="padding:5px;color:#212121;">Dark/Fire</td><td style="padding:5px;color:#212121;">55</td><td style="padding:5px;color:#212121;">2403</td><td style="padding:5px;color:#212121;">Flamethrower, Crunch, Iron Tail, Shadow Ball</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 257 · Atk 214 · Def 170 · Sp.Atk 236 · Sp.Def 203 · Speed 219</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1760</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hypno</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1732</td><td style="padding:5px;color:#212121;">Meditate, Psychic, Psych Up, Swagger</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 142 · Atk 76 · Def 73 · Sp.Atk 76 · Sp.Def 117 · Speed 70</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hypno</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1732</td><td style="padding:5px;color:#212121;">Meditate, Psychic, Psych Up, Swagger</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 142 · Atk 76 · Def 73 · Sp.Atk 76 · Sp.Def 117 · Speed 70</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1568</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Team Rocket Grunt Admin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Muk</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">52</td><td style="padding:5px;color:#212121;">1749</td><td style="padding:5px;color:#212121;">Sludge Bomb, Screech, Minimize, Rock Tomb</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 249 · Atk 192 · Def 161 · Sp.Atk 150 · Sp.Def 187 · Speed 135</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">53</td><td style="padding:5px;color:#212121;">1669</td><td style="padding:5px;color:#212121;">Sludge Bomb, Bite, Earthquake, Iron Tail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 206 · Atk 174 · Def 157 · Sp.Atk 153 · Sp.Def 168 · Speed 169</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vileplume</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">2128</td><td style="padding:5px;color:#212121;">Sludge Bomb, Giga Drain, Sleep Powder, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 226 · Atk 172 · Def 177 · Sp.Atk 194 · Sp.Def 183 · Speed 140</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1728</td></tr>
</table>

Recover the **Sapphire** and take it to **Celio** on One Island. With **both gems**, his Network Machine finally links to Hoenn — enabling trades with Ruby/Sapphire/Emerald (and, for your solo Living Dex, the save-edit trades you planned). The **Lost Cave** (via Resort Gorgeous) is a maze where a girl named Selphy rewards you if you find her. Ferry on to **[[56 - Six Island]]**.

The luxury **Resort Gorgeous** is full of optional trainers:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Resort Gorgeous</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Youngster Destin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1192</td><td style="padding:5px;color:#212121;">Hyper Fang, Scary Face, Pursuit, Super Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 110 · Atk 82 · Def 62 · Sp.Atk 53 · Sp.Def 72 · Speed 98</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1161</td><td style="padding:5px;color:#212121;">Whirlwind, Wing Attack, Feather Dance, Agility</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 62 · Def 57 · Sp.Atk 53 · Sp.Def 53 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Swimmer M Toby</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1347</td><td style="padding:5px;color:#212121;">Double Slap, Rain Dance, Body Slam, Belly Drum</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 120 · Atk 67 · Def 67 · Sp.Atk 53 · Sp.Def 53 · Speed 91</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1080</td><td style="padding:5px;color:#212121;">Bubble Beam, Wrap, Barrier, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 96 · Atk 43 · Def 38 · Sp.Atk 53 · Sp.Def 101 · Speed 72</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacruel</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">2107</td><td style="padding:5px;color:#212121;">Bubble Beam, Wrap, Barrier, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 134 · Atk 72 · Def 67 · Sp.Atk 81 · Sp.Def 120 · Speed 101</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽192</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Lady Gillian</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mareep</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">47</td><td style="padding:5px;color:#212121;">594</td><td style="padding:5px;color:#212121;">Thunder Wave, Cotton Spore, Light Screen, Thunder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 108 · Atk 42 · Def 42 · Sp.Atk 66 · Sp.Def 47 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mareep</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">606</td><td style="padding:5px;color:#212121;">Thunder Wave, Cotton Spore, Light Screen, Thunder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 110 · Atk 43 · Def 43 · Sp.Atk 67 · Sp.Def 48 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Flaaffy</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">49</td><td style="padding:5px;color:#212121;">1228</td><td style="padding:5px;color:#212121;">Thunder Wave, Cotton Spore, Light Screen, Thunder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 127 · Atk 58 · Def 58 · Sp.Atk 83 · Sp.Def 63 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽9800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Lady Jacki</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hoppip</td><td style="padding:5px;color:#212121;">Grass/Flying</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">760</td><td style="padding:5px;color:#212121;">Sleep Powder, Leech Seed, Cotton Spore, Mega Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 38 · Def 43 · Sp.Atk 38 · Sp.Def 57 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Skiploom</td><td style="padding:5px;color:#212121;">Grass/Flying</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1456</td><td style="padding:5px;color:#212121;">Sleep Powder, Leech Seed, Cotton Spore, Mega Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 115 · Atk 50 · Def 55 · Sp.Atk 50 · Sp.Def 70 · Speed 85</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽10000</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Painter Daisy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Smeargle</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1135</td><td style="padding:5px;color:#212121;">Dynamic Punch, Dizzy Punch, Focus Punch, Mega Punch</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 50 · Def 65 · Sp.Atk 50 · Sp.Def 75 · Speed 105</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Painter Rayna</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Smeargle</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1135</td><td style="padding:5px;color:#212121;">Cross Chop, Megahorn, Double Edge, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 50 · Def 65 · Sp.Atk 50 · Sp.Def 75 · Speed 105</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Painter Celina</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Smeargle</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1135</td><td style="padding:5px;color:#212121;">Fly, Dig, Dive, Bounce</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 50 · Def 65 · Sp.Atk 50 · Sp.Def 75 · Speed 105</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽800</td></tr>
</table>

⬅️ **Prev:** [[54 - Four Island]] · ➡️ **Next:** [[56 - Six Island]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
