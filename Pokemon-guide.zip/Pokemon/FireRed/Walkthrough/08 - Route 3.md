# 08 — Route 3

*The climbing road east of Pewter, lined with eager trainers.*

![[08 - Route 3.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="07 - Pewter City" data-href="07 - Pewter City">Pewter City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="09 - Route 4" data-href="09 - Route 4">Route 4</a> → Mt. Moon</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">6/7/8</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">6/7</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">7</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">14%</td><td style="padding:5px;color:#212121;">6/7</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Jigglypuff</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">3/5/7</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Nidoran♀</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">6</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Oran Berry</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Nidoran♂</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Nidoran♀</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Jigglypuff</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Nidoran♀ → Nidorina → Nidoqueen** — keep **3**
> - **Nidoran♂ → Nidorino → Nidoking** — keep **3**
> - **Jigglypuff → Wigglytuff** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Catch Nidoran♂/♀ and Jigglypuff
> 2. Beat trainers 1–8 (numbered on the map) heading east
> 3. Continue north to Route 4

Route 3 is a trainer gauntlet climbing east from Pewter. Catch **Nidoran♂** (14%), **Jigglypuff** (10%), and — if you’re lucky — **Nidoran♀** (just 1%; the Safari Zone is an easier source later). 

Work east through the trainers (numbered west→east on the map):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 3</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Bug Catcher Colton</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">112</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 29 · Atk 11 · Def 12 · Sp.Atk 9 · Sp.Def 9 · Speed 14</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">111</td><td style="padding:5px;color:#212121;">Poison Sting, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 28 · Atk 12 · Def 11 · Sp.Atk 9 · Sp.Def 9 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">112</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 29 · Atk 11 · Def 12 · Sp.Atk 9 · Sp.Def 9 · Speed 14</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Youngster Ben</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">11</td><td style="padding:5px;color:#212121;">133</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 27 · Atk 17 · Def 12 · Sp.Atk 10 · Sp.Def 12 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">11</td><td style="padding:5px;color:#212121;">145</td><td style="padding:5px;color:#212121;">Wrap, Leer, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 28 · Atk 18 · Def 14 · Sp.Atk 13 · Sp.Def 16 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽176</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Lass Janice</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">105</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 26 · Atk 13 · Def 12 · Sp.Atk 11 · Sp.Def 11 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">105</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 26 · Atk 13 · Def 12 · Sp.Atk 11 · Sp.Def 11 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽144</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Bug Catcher Greg</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">99</td><td style="padding:5px;color:#212121;">Poison Sting, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 26 · Atk 11 · Def 10 · Sp.Atk 8 · Sp.Def 8 · Speed 14</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kakuna</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">136</td><td style="padding:5px;color:#212121;">Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 27 · Atk 9 · Def 14 · Sp.Atk 9 · Sp.Def 9 · Speed 11</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">102</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 27 · Atk 10 · Def 11 · Sp.Atk 8 · Sp.Def 8 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Metapod</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">9</td><td style="padding:5px;color:#212121;">138</td><td style="padding:5px;color:#212121;">Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 28 · Atk 8 · Def 14 · Sp.Atk 9 · Sp.Def 9 · Speed 10</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽108</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Youngster Calvin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">14</td><td style="padding:5px;color:#212121;">174</td><td style="padding:5px;color:#212121;">Peck, Growl, Leer, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 35 · Atk 21 · Def 13 · Sp.Atk 13 · Sp.Def 13 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽224</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Lass Sally</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">121</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 26 · Atk 16 · Def 12 · Sp.Atk 10 · Sp.Def 12 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♀</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">126</td><td style="padding:5px;color:#212121;">Growl, Scratch, Tail Whip</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 31 · Atk 14 · Def 15 · Sp.Atk 13 · Sp.Def 13 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽160</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Bug Catcher James</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">11</td><td style="padding:5px;color:#212121;">124</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 30 · Atk 11 · Def 12 · Sp.Atk 9 · Sp.Def 9 · Speed 14</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Metapod</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">11</td><td style="padding:5px;color:#212121;">169</td><td style="padding:5px;color:#212121;">Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 32 · Atk 9 · Def 17 · Sp.Atk 10 · Sp.Def 10 · Speed 11</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽132</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Lass Robin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Jigglypuff</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">14</td><td style="padding:5px;color:#212121;">228</td><td style="padding:5px;color:#212121;">Sing, Defense Curl, Pound, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 17 · Def 10 · Sp.Atk 17 · Sp.Def 12 · Speed 10</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽224</td></tr>
</table>

They’re low-level Normal/Bug/Poison mons — steady EXP for your team. At the top you reach the **Route 4 Pokémon Center** at Mt. Moon: **[[09 - Route 4]]**.

⬅️ **Prev:** [[07 - Pewter City]] · ➡️ **Next:** [[09 - Route 4]]

## Walkthrough Notes
- ACTUAL TRAINER ORDER
	- 3 should be 1
	- 1 should be 2
	- 2 should be 3
	- The others are correct