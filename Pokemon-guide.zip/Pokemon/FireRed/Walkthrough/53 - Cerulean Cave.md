# 53 — Cerulean Cave

*The endgame dungeon — the strongest wild Pokémon, and Mewtwo.*

![[53 - Cerulean Cave 1F.svg]]
*Cerulean Cave 1F*

![[53 - Cerulean Cave 2F.svg]]
*Cerulean Cave 2F*

![[53 - Cerulean Cave B1F.svg]]
*Cerulean Cave B1F*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance</td><td style="padding:5px;color:#212121;">Cerulean City (Surf, post-Champion)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">49</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Parasect</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">49/58</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">14%</td><td style="padding:5px;color:#212121;">46/55</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">11%</td><td style="padding:5px;color:#212121;">52/61</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ditto</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">11%</td><td style="padding:5px;color:#212121;">52/61</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">58</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Wobbuffet</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">55</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">65%</td><td style="padding:5px;color:#212121;">30–40/40–50</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">40–50/45–55</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🪨 Rock Smash 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">65%</td><td style="padding:5px;color:#212121;">30–40/40–50</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">40–50/45–55</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 2F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">49/58</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">49</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">52</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Parasect</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">14%</td><td style="padding:5px;color:#212121;">52/61</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">11%</td><td style="padding:5px;color:#212121;">55/64</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ditto</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">11%</td><td style="padding:5px;color:#212121;">55/64</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Wobbuffet</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">58</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">61</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🪨 Rock Smash 2F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">65%</td><td style="padding:5px;color:#212121;">35–45/45–55</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">45–55/50–60</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">58/67</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ditto</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">58/67</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">55</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Parasect</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">14%</td><td style="padding:5px;color:#212121;">55/64</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">11%</td><td style="padding:5px;color:#212121;">52/61</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">52</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">64</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Wobbuffet</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">61</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">65%</td><td style="padding:5px;color:#212121;">40–50/50–60</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">50–60/55–65</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🪨 Rock Smash B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">65%</td><td style="padding:5px;color:#212121;">40–50/50–60</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">50–60/55–65</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">16%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">1F: Nugget, Full Restore, Max Elixir · Hidden: Ultra Ball</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">2F: PP Up, Ultra Ball, Full Restore</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Mewtwo</td></tr>
</table>

> [!todo] Do this in order
> 1. Have the National Dex + both gems (Ruby & Sapphire) to enter
> 2. Surf in from Cerulean City
> 3. Catch the high-level wild Pokémon (Ditto, Chansey-tier rares)
> 4. Reach the bottom and catch Mewtwo (Lv 70) — use the Master Ball

Cerulean Cave opens only after you’re **Champion**, have the **National Dex**, and have given Celio **both gems**. Surf in from north Cerulean.

It holds the **strongest wild Pokémon in the game** (Level 46–64): Machoke, Golbat, Parasect, Magneton, Primeape, **Ditto**, Kadabra, Electrode, and Wobbuffet. Great for filling late dex slots.

At the very bottom waits **Mewtwo (Lv 70)** — the most powerful Pokémon in Kanto. **Use the Master Ball** (from Silph Co.) for a guaranteed catch, or save and grind Ultra Balls with sleep/paralysis if you saved the Master Ball for something else. This is the crown jewel of your Living Dex.

⬅️ **Prev:** [[52 - Power Plant]] · ➡️ **Next:** [[54 - Four Island]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
