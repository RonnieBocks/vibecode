# 09 — Route 4

*A dry plateau split by Mt. Moon.*

![[09 - Route 4.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="08 - Route 3" data-href="08 - Route 3">Route 3</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="11 - Cerulean City" data-href="11 - Cerulean City">Cerulean City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Cave</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="10 - Mt. Moon" data-href="10 - Mt. Moon">Mt. Moon</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">8/10/12</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">8/10/12</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ekans 🔴</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">6/8/10/12</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">10/12</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">84%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">TM05 Roar (east side, past Mt. Moon)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Great Ball</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Persim Berry</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Razz Berry</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Ekans 🔴</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Ekans → Arbok** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Heal & stock up at the Pokémon Center
> 2. Catch an Ekans
> 3. Enter Mt. Moon
> 4. On the east side: beat Lass Crissy & grab TM05 Roar

The **Pokémon Center** here is your last stop before the cave — heal and buy Poké Balls. A salesman offers a **Magikarp (500₽)** — skip unless you want an easy Gyarados project.

Catch a **🔴 Ekans** (FireRed exclusive → Arbok). One trainer waits on the **east side** (past Mt. Moon), near Cerulean:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINER — Route 4</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Lass Crissy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Paras</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">465</td><td style="padding:5px;color:#212121;">Poison Powder, Leech Life, Spore, Slash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 48 · Def 39 · Sp.Atk 32 · Sp.Def 39 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Paras</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">465</td><td style="padding:5px;color:#212121;">Poison Powder, Leech Life, Spore, Slash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 48 · Def 39 · Sp.Atk 32 · Sp.Def 39 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Parasect</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">849</td><td style="padding:5px;color:#212121;">Stun Spore, Poison Powder, Leech Life, Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 63 · Def 54 · Sp.Atk 42 · Sp.Def 54 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽496</td></tr>
</table>

Then enter **[[10 - Mt. Moon]]**. When you come out the far side you’ll be on east Route 4 — grab **TM05 Roar** and head **east to [[11 - Cerulean City]]**.

⬅️ **Prev:** [[08 - Route 3]] · ➡️ **Next:** [[10 - Mt. Moon]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
