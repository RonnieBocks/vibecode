# 37 — Saffron City

*The central metropolis — Fighting Dojo, Silph Co., and Sabrina.*

![[37 - Saffron City.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;">Route 5</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;">Route 6</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;">Route 7</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;">Route 8</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Building</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="38 - Silph Co." data-href="38 - Silph Co.">Silph Co.</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">TM29 Psychic (Mr. Psychic’s house)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hitmonlee OR Hitmonchan (Fighting Dojo — choose one)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">TM31 Brick Break (Copycat, for a Poké Doll — later)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Hitmonlee</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Hitmonchan (choose one)</td></tr>
</table>

> [!todo] Do this in order
> 1. Enter Saffron (give the gate guards a drink — Tea/soda)
> 2. Fighting Dojo: beat the Black Belts, then choose Hitmonlee or Hitmonchan
> 3. Free Silph Co. from Team Rocket (see [[38 - Silph Co.]])
> 4. Get TM29 Psychic from Mr. Psychic
> 5. Beat Sabrina for the Marsh Badge

Saffron’s gates are blocked by **thirsty guards** — give any one a **drink** (the **Tea** from Celadon Mansion, or a vending-machine soda) to get in. Team Rocket occupies the city until you clear **Silph Co.**

**Fighting Dojo** (bottom-right): beat the Black Belts and the Karate King, then pick your prize:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ FIGHTING DOJO</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Black Belt Hitoshi</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">583</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 115 · Atk 85 · Def 67 · Sp.Atk 57 · Sp.Def 57 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">490</td><td style="padding:5px;color:#212121;">Fury Swipes, Focus Energy, Seismic Toss, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 96 · Atk 85 · Def 57 · Sp.Atk 57 · Sp.Def 63 · Speed 79</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">988</td><td style="padding:5px;color:#212121;">Fury Swipes, Focus Energy, Seismic Toss, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 112 · Atk 101 · Def 73 · Sp.Atk 73 · Sp.Def 79 · Speed 94</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽744</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Black Belt Hideki</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">32</td><td style="padding:5px;color:#212121;">603</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 88 · Def 69 · Sp.Atk 59 · Sp.Def 59 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">32</td><td style="padding:5px;color:#212121;">1000</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 125 · Atk 101 · Def 81 · Sp.Atk 69 · Sp.Def 75 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Black Belt Aaron</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">36</td><td style="padding:5px;color:#212121;">1149</td><td style="padding:5px;color:#212121;">Focus Energy, Seismic Toss, Rage, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 128 · Atk 116 · Def 84 · Sp.Atk 84 · Sp.Def 91 · Speed 109</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽864</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Black Belt Mike</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">490</td><td style="padding:5px;color:#212121;">Fury Swipes, Focus Energy, Seismic Toss, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 96 · Atk 85 · Def 57 · Sp.Atk 57 · Sp.Def 63 · Speed 79</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">490</td><td style="padding:5px;color:#212121;">Fury Swipes, Focus Energy, Seismic Toss, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 96 · Atk 85 · Def 57 · Sp.Atk 57 · Sp.Def 63 · Speed 79</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">988</td><td style="padding:5px;color:#212121;">Fury Swipes, Focus Energy, Seismic Toss, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 112 · Atk 101 · Def 73 · Sp.Atk 73 · Sp.Def 79 · Speed 94</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽744</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Black Belt Koichi</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmonlee</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1101</td><td style="padding:5px;color:#212121;">Focus Energy, Hi Jump Kick, Mind Reader, Foresight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 121 · Atk 130 · Def 81 · Sp.Atk 67 · Sp.Def 123 · Speed 106</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmonchan</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1110</td><td style="padding:5px;color:#212121;">Thunder Punch, Ice Punch, Fire Punch, Sky Uppercut</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 121 · Atk 119 · Def 100 · Sp.Atk 67 · Sp.Def 123 · Speed 98</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽888</td></tr>
</table>

⚠️ **Choose ONE:** **Hitmonlee** (higher Attack, kicking moves) or **Hitmonchan** (punching moves, better bulk). The other is lost — trade/save-edit for it later.

**Mr. Psychic’s house** gives **TM29 Psychic** — a superb move. Clear **[[38 - Silph Co.]]** (Rocket takeover, rival, Giovanni, Lapras, Master Ball) — that also frees the city and unlocks the gym.

**Saffron Gym — Sabrina (Psychic).** A maze of **teleport tiles**; step through the pads to reach each trainer, then Sabrina:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ SAFFRON GYM — Sabrina (Marsh Badge)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Psychic Johan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">963</td><td style="padding:5px;color:#212121;">Psybeam, Reflect, Recover, Future Sight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 42 · Def 39 · Sp.Atk 94 · Sp.Def 63 · Speed 85</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">657</td><td style="padding:5px;color:#212121;">Water Gun, Confusion, Disable, Headbutt</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 112 · Atk 60 · Def 60 · Sp.Atk 45 · Sp.Def 45 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mr Mime</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">903</td><td style="padding:5px;color:#212121;">Reflect, Magical Leaf, Encore, Psybeam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 48 · Def 60 · Sp.Atk 82 · Sp.Def 94 · Speed 76</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">963</td><td style="padding:5px;color:#212121;">Psybeam, Reflect, Recover, Future Sight</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 42 · Def 39 · Sp.Atk 94 · Sp.Def 63 · Speed 85</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽620</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Psychic Tyron</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mr Mime</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">990</td><td style="padding:5px;color:#212121;">Magical Leaf, Encore, Psybeam, Recycle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 88 · Atk 52 · Def 66 · Sp.Atk 90 · Sp.Def 103 · Speed 83</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1056</td><td style="padding:5px;color:#212121;">Reflect, Recover, Future Sight, Role Play</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 88 · Atk 45 · Def 42 · Sp.Atk 103 · Sp.Def 69 · Speed 93</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽680</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Psychic Cameron</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">699</td><td style="padding:5px;color:#212121;">Water Gun, Confusion, Disable, Headbutt</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 64 · Def 64 · Sp.Atk 47 · Sp.Def 47 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">699</td><td style="padding:5px;color:#212121;">Water Gun, Confusion, Disable, Headbutt</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 64 · Def 64 · Sp.Atk 47 · Sp.Def 47 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowbro</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1159</td><td style="padding:5px;color:#212121;">Water Gun, Confusion, Disable, Headbutt</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 122 · Atk 71 · Def 94 · Sp.Atk 87 · Sp.Def 74 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽660</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Psychic Preston</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowbro</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1335</td><td style="padding:5px;color:#212121;">Disable, Headbutt, Amnesia, Withdraw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 81 · Def 107 · Sp.Atk 100 · Sp.Def 84 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽760</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Channeler Amanda</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">691</td><td style="padding:5px;color:#212121;">Night Shade, Confuse Ray, Dream Eater, Destiny Bond</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 28 · Def 25 · Sp.Atk 73 · Sp.Def 28 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">918</td><td style="padding:5px;color:#212121;">Night Shade, Confuse Ray, Shadow Punch, Dream Eater</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 39 · Def 35 · Sp.Atk 83 · Sp.Def 42 · Speed 69</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1088</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Channeler Stacy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1026</td><td style="padding:5px;color:#212121;">Night Shade, Confuse Ray, Shadow Punch, Dream Eater</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 43 · Def 39 · Sp.Atk 92 · Sp.Def 46 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1216</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Channeler Tasha</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">670</td><td style="padding:5px;color:#212121;">Night Shade, Confuse Ray, Dream Eater, Destiny Bond</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 28 · Def 24 · Sp.Atk 71 · Sp.Def 28 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">670</td><td style="padding:5px;color:#212121;">Night Shade, Confuse Ray, Dream Eater, Destiny Bond</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 28 · Def 24 · Sp.Atk 71 · Sp.Def 28 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">891</td><td style="padding:5px;color:#212121;">Night Shade, Confuse Ray, Shadow Punch, Dream Eater</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 38 · Def 34 · Sp.Atk 80 · Sp.Def 41 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1056</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Leader Sabrina</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1180</td><td style="padding:5px;color:#212121;">Psybeam, Reflect, Future Sight, Calm Mind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 31 · Def 27 · Sp.Atk 96 · Sp.Def 58 · Speed 84</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mr Mime</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1077</td><td style="padding:5px;color:#212121;">Barrier, Psybeam, Baton Pass, Calm Mind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 38 · Def 53 · Sp.Atk 79 · Sp.Def 93 · Speed 71</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Venomoth</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1123</td><td style="padding:5px;color:#212121;">Psybeam, Gust, Leech Life, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 101 · Atk 54 · Def 50 · Sp.Atk 73 · Sp.Def 62 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">43</td><td style="padding:5px;color:#212121;">1713</td><td style="padding:5px;color:#212121;">Psychic, Recover, Future Sight, Calm Mind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 100 · Atk 48 · Def 43 · Sp.Atk 121 · Sp.Def 78 · Speed 108</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽4300</td></tr>
</table>

Sabrina’s mons have low Defense — hit them with strong **physical** attacks, or use **Bug/Ghost/Dark** coverage. Her Alakazam is fast and hits hard, so consider paralysis. Winning gives the **Marsh Badge** (lets you use **Rock Smash**) and **TM04 Calm Mind**.

⬅️ **Prev:** [[36 - Safari Zone]] · ➡️ **Next:** [[38 - Silph Co.]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
