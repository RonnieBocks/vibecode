# 44 — Victory Road

*The final cave — Strength boulders, tough trainers, and the road to the League.*

![[44 - Victory Road 1F.svg]]
*1F*

![[44 - Victory Road 2F.svg]]
*2F*

![[44 - Victory Road 3F.svg]]
*3F*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance (Route 23)</td><td style="padding:5px;color:#212121;">Route 23 → Viridian</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Exit (top)</td><td style="padding:5px;color:#212121;">Indigo Plateau → <a class="internal-link" href="45 - Elite Four & Champion" data-href="45 - Elite Four & Champion">Elite Four & Champion</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">40/43/46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Arbok 🔴</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">44</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">44</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">44/46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">44/46</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 2F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Primeape</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">42</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">45/48</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Arbok 🔴</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">46/48</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">46/48</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 3F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">40/43/46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Arbok 🔴</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">44</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">44</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">44/46</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">44/46</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">1F: Rare Candy, TM02 Dragon Claw · Hidden: Ultra Ball, Full Restore</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">2F: Guard Spec., TM07 Hail, Full Heal, TM37 Sandstorm</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">3F: Max Revive, TM50 Overheat</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Machoke</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Primeape</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Arbok 🔴</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Marowak</td></tr>
</table>

> [!todo] Do this in order
> 1. Have all 8 badges (Route 23 gate checks them)
> 2. Use Strength to push boulders onto the switches
> 3. Beat the trainers (numbered on the maps)
> 4. Catch Machoke/Marowak/Arbok; grab Rare Candy & Max Revive
> 5. Climb to the exit → Indigo Plateau

First, get your **8th badge** at the **Viridian Gym (Giovanni)** — see [[03 - Viridian City]] — then head west through Route 22 (your rival rematches you there) and up **Route 23**, whose guards check for all **8 badges**.

**Victory Road** is a **Strength boulder puzzle**: push boulders onto the floor switches to open the barriers and reach the exit. It's full of strong trainers (numbered on the maps):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Victory Road</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Cooltrainer Rolando</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1044</td><td style="padding:5px;color:#212121;">Super Fang, Pursuit, Scary Face, Quick Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 115 · Def 97 · Sp.Atk 89 · Sp.Def 105 · Speed 128</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ivysaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1269</td><td style="padding:5px;color:#212121;">Razor Leaf, Sleep Powder, Sweet Scent, Synthesis</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 144 · Atk 99 · Def 99 · Sp.Atk 114 · Sp.Def 114 · Speed 97</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Wartortle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1287</td><td style="padding:5px;color:#212121;">Water Gun, Bite, Rapid Spin, Tail Whip</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 143 · Atk 99 · Def 114 · Sp.Atk 101 · Sp.Def 114 · Speed 95</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmeleon</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1278</td><td style="padding:5px;color:#212121;">Flamethrower, Slash, Smokescreen, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 142 · Atk 100 · Def 95 · Sp.Atk 114 · Sp.Def 101 · Speed 114</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charizard</td><td style="padding:5px;color:#212121;">Fire/Flying</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1881</td><td style="padding:5px;color:#212121;">Flamethrower, Wing Attack, Smokescreen, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 159 · Atk 117 · Def 112 · Sp.Atk 138 · Sp.Def 118 · Speed 131</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1512</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Cooltrainer Naomi</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1332</td><td style="padding:5px;color:#212121;">Fury Swipes, Screech, Faint Attack, Pay Day</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 148 · Atk 105 · Def 97 · Sp.Atk 101 · Sp.Def 101 · Speed 143</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ponyta</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1368</td><td style="padding:5px;color:#212121;">Agility, Take Down, Fire Spin, Stomp</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 136 · Atk 118 · Def 93 · Sp.Atk 101 · Sp.Def 101 · Speed 122</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rapidash</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1728</td><td style="padding:5px;color:#212121;">Fury Attack, Fire Spin, Stomp, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 148 · Atk 131 · Def 105 · Sp.Atk 114 · Sp.Def 114 · Speed 135</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">567</td><td style="padding:5px;color:#212121;">Flamethrower, Confuse Ray, Quick Attack, Imprison</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 125 · Atk 81 · Def 80 · Sp.Atk 89 · Sp.Def 101 · Speed 101</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ninetales</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1602</td><td style="padding:5px;color:#212121;">Safeguard, Will O Wisp, Confuse Ray, Fire Spin</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 155 · Atk 110 · Def 110 · Sp.Atk 115 · Sp.Def 131 · Speed 131</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1512</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Pokemaniac Dawson</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmeleon</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">1216</td><td style="padding:5px;color:#212121;">Metal Claw, Smokescreen, Scary Face, Flamethrower</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 108 · Atk 68 · Def 63 · Sp.Atk 81 · Sp.Def 69 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Lapras</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">1876</td><td style="padding:5px;color:#212121;">Confuse Ray, Perish Song, Ice Beam, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 166 · Atk 85 · Def 81 · Sp.Atk 85 · Sp.Def 93 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Lickitung</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">1087</td><td style="padding:5px;color:#212121;">Stomp, Wrap, Disable, Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 134 · Atk 61 · Def 77 · Sp.Atk 65 · Sp.Def 77 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1920</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Juggler Gregory</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mr Mime</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">48</td><td style="padding:5px;color:#212121;">1398</td><td style="padding:5px;color:#212121;">Psychic, Role Play, Double Slap, Encore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 96 · Atk 48 · Def 67 · Sp.Atk 101 · Sp.Def 120 · Speed 91</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1920</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Tamer Vincent</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">44</td><td style="padding:5px;color:#212121;">1395</td><td style="padding:5px;color:#212121;">Pay Day, Faint Attack, Screech, Fury Swipes</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 128 · Atk 84 · Def 75 · Sp.Atk 79 · Sp.Def 79 · Speed 123</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golduck</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">44</td><td style="padding:5px;color:#212121;">1639</td><td style="padding:5px;color:#212121;">Confusion, Screech, Psych Up, Fury Swipes</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 142 · Atk 94 · Def 91 · Sp.Atk 106 · Sp.Def 93 · Speed 97</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1760</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Black Belt Daisuke</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">43</td><td style="padding:5px;color:#212121;">1344</td><td style="padding:5px;color:#212121;">Foresight, Revenge, Vital Throw, Submission</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 164 · Atk 134 · Def 108 · Sp.Atk 91 · Sp.Def 99 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">43</td><td style="padding:5px;color:#212121;">810</td><td style="padding:5px;color:#212121;">Vital Throw, Submission, Cross Chop, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 156 · Atk 116 · Def 91 · Sp.Atk 78 · Sp.Def 78 · Speed 78</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">43</td><td style="padding:5px;color:#212121;">1344</td><td style="padding:5px;color:#212121;">Foresight, Revenge, Vital Throw, Submission</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 164 · Atk 134 · Def 108 · Sp.Atk 91 · Sp.Def 99 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1032</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Juggler Nelson</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">41</td><td style="padding:5px;color:#212121;">895</td><td style="padding:5px;color:#212121;">Meditate, Psychic, Psych Up, Swagger</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 100 · Atk 44 · Def 41 · Sp.Atk 40 · Sp.Def 78 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hypno</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">41</td><td style="padding:5px;color:#212121;">1449</td><td style="padding:5px;color:#212121;">Headbutt, Poison Gas, Meditate, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 120 · Atk 64 · Def 62 · Sp.Atk 64 · Sp.Def 99 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">41</td><td style="padding:5px;color:#212121;">1273</td><td style="padding:5px;color:#212121;">Recover, Future Sight, Role Play, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 83 · Atk 33 · Def 29 · Sp.Atk 103 · Sp.Def 62 · Speed 91</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">41</td><td style="padding:5px;color:#212121;">1273</td><td style="padding:5px;color:#212121;">Recover, Future Sight, Role Play, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 83 · Atk 33 · Def 29 · Sp.Atk 103 · Sp.Def 62 · Speed 91</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1640</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Cooltrainer Alexa</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">612</td><td style="padding:5px;color:#212121;">Light Screen, Cosmic Power, Double Slap, Encore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 152 · Atk 84 · Def 87 · Sp.Atk 97 · Sp.Def 101 · Speed 76</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Jigglypuff</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">684</td><td style="padding:5px;color:#212121;">Sing, Body Slam, Rollout, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 190 · Atk 84 · Def 63 · Sp.Atk 84 · Sp.Def 68 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Persian</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1332</td><td style="padding:5px;color:#212121;">Pay Day, Faint Attack, Bite, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 148 · Atk 105 · Def 97 · Sp.Atk 101 · Sp.Def 101 · Speed 143</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dewgong</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1584</td><td style="padding:5px;color:#212121;">Sheer Cold, Take Down, Rest, Aurora Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 169 · Atk 105 · Def 114 · Sp.Atk 105 · Sp.Def 126 · Speed 105</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Chansey</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">2295</td><td style="padding:5px;color:#212121;">Sing, Egg Bomb, Soft Boiled, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 304 · Atk 51 · Def 51 · Sp.Atk 76 · Sp.Def 135 · Speed 89</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1512</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Cooltrainer George</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggutor</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1908</td><td style="padding:5px;color:#212121;">Egg Bomb, Confusion, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 173 · Atk 126 · Def 118 · Sp.Atk 152 · Sp.Def 101 · Speed 93</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1467</td><td style="padding:5px;color:#212121;">Fury Swipes, Swift, Poison Sting, Sand Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 157 · Atk 131 · Def 139 · Sp.Atk 84 · Sp.Def 93 · Speed 101</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cloyster</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1827</td><td style="padding:5px;color:#212121;">Spike Cannon, Spikes, Aurora Beam, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 136 · Atk 126 · Def 198 · Sp.Atk 118 · Sp.Def 84 · Speed 105</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1350</td><td style="padding:5px;color:#212121;">Spark, Sonic Boom, Screech, Light Screen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 144 · Atk 89 · Def 105 · Sp.Atk 114 · Sp.Def 114 · Speed 164</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arcanine</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1917</td><td style="padding:5px;color:#212121;">Flame Wheel, Roar, Bite, Take Down</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 169 · Atk 139 · Def 114 · Sp.Atk 131 · Sp.Def 114 · Speed 126</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1512</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Cool Couple Ray & Tyra</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoqueen</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1870</td><td style="padding:5px;color:#212121;">Superpower, Body Slam, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 181 · Atk 123 · Def 128 · Sp.Atk 117 · Sp.Def 126 · Speed 118</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoking</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1879</td><td style="padding:5px;color:#212121;">Megahorn, Thrash, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 172 · Atk 132 · Def 119 · Sp.Atk 126 · Sp.Def 117 · Speed 126</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1080</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Cool Couple Ray & Tyra</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoqueen</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1870</td><td style="padding:5px;color:#212121;">Superpower, Body Slam, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 181 · Atk 123 · Def 128 · Sp.Atk 117 · Sp.Def 126 · Speed 118</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoking</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1879</td><td style="padding:5px;color:#212121;">Megahorn, Thrash, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 172 · Atk 132 · Def 119 · Sp.Atk 126 · Sp.Def 117 · Speed 126</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1080</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Cooltrainer Caroline</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">756</td><td style="padding:5px;color:#212121;">Razor Leaf, Acid, Stun Spore, Poison Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 136 · Atk 110 · Def 76 · Sp.Atk 105 · Sp.Def 72 · Speed 80</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weepinbell</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1359</td><td style="padding:5px;color:#212121;">Razor Leaf, Acid, Sleep Powder, Poison Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 148 · Atk 122 · Def 89 · Sp.Atk 118 · Sp.Def 84 · Speed 93</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Victreebel</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1719</td><td style="padding:5px;color:#212121;">Razor Leaf, Acid, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 161 · Atk 135 · Def 101 · Sp.Atk 131 · Sp.Def 97 · Speed 105</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Paras</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">630</td><td style="padding:5px;color:#212121;">Growth, Slash, Leech Life, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 123 · Atk 105 · Def 93 · Sp.Atk 84 · Sp.Def 93 · Speed 68</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Parasect</td><td style="padding:5px;color:#212121;">Bug/Grass</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1152</td><td style="padding:5px;color:#212121;">Spore, Slash, Leech Life, Poison Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 144 · Atk 126 · Def 114 · Sp.Atk 97 · Sp.Def 114 · Speed 72</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1512</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">13. Cooltrainer Colby</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kingler</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">41</td><td style="padding:5px;color:#212121;">1809</td><td style="padding:5px;color:#212121;">Guillotine, Stomp, Mud Shot, Bubble</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 137 · Atk 152 · Def 140 · Sp.Atk 87 · Sp.Def 87 · Speed 107</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1179</td><td style="padding:5px;color:#212121;">Body Slam, Double Slap, Water Gun, Hypnosis</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 148 · Atk 101 · Def 101 · Sp.Atk 89 · Sp.Def 89 · Speed 122</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacruel</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1845</td><td style="padding:5px;color:#212121;">Barrier, Wrap, Bubble Beam, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 161 · Atk 105 · Def 101 · Sp.Atk 114 · Sp.Def 147 · Speed 131</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1395</td><td style="padding:5px;color:#212121;">Water Gun, Smokescreen, Twister, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 101 · Def 126 · Sp.Atk 126 · Sp.Def 84 · Speed 118</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Blastoise</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">43</td><td style="padding:5px;color:#212121;">1935</td><td style="padding:5px;color:#212121;">Water Gun, Bite, Rapid Spin, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 163 · Atk 119 · Def 134 · Sp.Atk 121 · Sp.Def 138 · Speed 115</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1548</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">14. Cool Couple Ray & Tyra</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoqueen</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1870</td><td style="padding:5px;color:#212121;">Superpower, Body Slam, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 181 · Atk 123 · Def 128 · Sp.Atk 117 · Sp.Def 126 · Speed 118</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoking</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1879</td><td style="padding:5px;color:#212121;">Megahorn, Thrash, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 172 · Atk 132 · Def 119 · Sp.Atk 126 · Sp.Def 117 · Speed 126</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1080</td></tr>
</table>

Catch a **Machoke**, **Marowak**, or **🔴 Arbok** if you need them, and grab the **Rare Candy**, **Max Revive**, and strong TMs (Dragon Claw, Overheat). Stock up on healing before you climb out to the **Indigo Plateau** — there's no turning back easily once you challenge the League: [[45 - Elite Four & Champion]].

⬅️ **Prev:** [[43 - Pokémon Mansion]] · ➡️ **Next:** [[45 - Elite Four & Champion]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
