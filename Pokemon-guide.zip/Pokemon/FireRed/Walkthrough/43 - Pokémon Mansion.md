# 43 — Pokémon Mansion

*A burnt-out lab hiding the Secret Key — and Mewtwo's origins.*

![[43 - Pokémon Mansion 1F.svg]]
*1F*

![[43 - Pokémon Mansion 2F.svg]]
*2F*

![[43 - Pokémon Mansion 3F.svg]]
*3F*

![[43 - Pokémon Mansion B1F.svg]]
*B1F*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance / Exit</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="42 - Cinnabar Island" data-href="42 - Cinnabar Island">Cinnabar Island</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">28/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">32/36</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Growlithe 🔴</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">26/28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 2F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">28/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">32/36</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Growlithe 🔴</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">26/28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 3F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">28/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">32/36</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Growlithe 🔴</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">26/28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">32</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">28/30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">34/38</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ditto</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Growlithe 🔴</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">30/32</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">34</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">26</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">1F: Carbos, Escape Rope, Protein · Hidden: Moon Stone</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">2F: Calcium, Zinc, HP Up</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">3F: Max Potion, Iron · Hidden: Rare Candy</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B1F: TM22 Solar Beam, TM14 Blizzard, Full Restore, Secret Key · Hidden: Elixir</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Weezing</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Koffing → Weezing** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Flip the statue switches to open paths
> 2. Catch Growlithe/Grimer/Koffing/Weezing; grab the hidden Moon Stone
> 3. Beat the Burglars & Scientists (numbered on the maps)
> 4. Reach B1F for the Secret Key
> 5. Read the diaries (Mewtwo backstory), then return to Blaine

The abandoned mansion is a puzzle of hidden **statue switches** that open walls and staircases. It's full of Fire/Poison mons — catch a **Growlithe**, **Grimer/Koffing**, or wild **Weezing**, and grab the **hidden Moon Stone** on 1F.

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Pokémon Mansion</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Youngster Johnson</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">438</td><td style="padding:5px;color:#212121;">Bite, Glare, Screech, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 44 · Def 34 · Sp.Atk 31 · Sp.Def 40 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">438</td><td style="padding:5px;color:#212121;">Bite, Glare, Screech, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 44 · Def 34 · Sp.Atk 31 · Sp.Def 40 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">844</td><td style="padding:5px;color:#212121;">Quick Attack, Hyper Fang, Scary Face, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 60 · Def 45 · Sp.Atk 39 · Sp.Def 52 · Speed 70</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽544</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Scientist Ted</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">931</td><td style="padding:5px;color:#212121;">Screech, Sonic Boom, Spark, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 34 · Def 45 · Sp.Atk 51 · Sp.Def 51 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1074</td><td style="padding:5px;color:#212121;">Smog, Self Destruct, Sludge, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 57 · Def 74 · Sp.Atk 54 · Sp.Def 45 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1392</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Burglar Arnie</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">472</td><td style="padding:5px;color:#212121;">Metal Claw, Smokescreen, Scary Face, Flamethrower</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 70 · Atk 40 · Def 34 · Sp.Atk 45 · Sp.Def 39 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmeleon</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1033</td><td style="padding:5px;color:#212121;">Metal Claw, Smokescreen, Scary Face, Flamethrower</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 83 · Atk 48 · Def 44 · Sp.Atk 59 · Sp.Def 49 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2992</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Burglar Simon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ninetales</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1449</td><td style="padding:5px;color:#212121;">Ember, Quick Attack, Confuse Ray, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 103 · Atk 62 · Def 62 · Sp.Atk 66 · Sp.Def 81 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽3344</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Scientist Braydon</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">628</td><td style="padding:5px;color:#212121;">Sonic Boom, Thunder Wave, Spark, Lock On</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 59 · Atk 28 · Def 51 · Sp.Atk 67 · Sp.Def 41 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1138</td><td style="padding:5px;color:#212121;">Supersonic, Sonic Boom, Thunder Wave, Spark</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 44 · Def 67 · Sp.Atk 84 · Sp.Def 51 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">727</td><td style="padding:5px;color:#212121;">Sonic Boom, Spark, Self Destruct, Rollout</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 24 · Def 38 · Sp.Atk 41 · Sp.Def 41 · Speed 71</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1584</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Scientist Ivan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">648</td><td style="padding:5px;color:#212121;">Sonic Boom, Thunder Wave, Spark, Lock On</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 61 · Atk 28 · Def 52 · Sp.Atk 69 · Sp.Def 42 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1092</td><td style="padding:5px;color:#212121;">Sonic Boom, Spark, Self Destruct, Rollout</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 84 · Atk 39 · Def 52 · Sp.Atk 59 · Sp.Def 59 · Speed 100</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1632</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Burglar Lewis</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">663</td><td style="padding:5px;color:#212121;">Leer, Odor Sleuth, Take Down, Flame Wheel</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 52 · Def 35 · Sp.Atk 52 · Sp.Def 39 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ponyta</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1107</td><td style="padding:5px;color:#212121;">Ember, Stomp, Fire Spin, Take Down</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 62 · Def 42 · Sp.Atk 49 · Sp.Def 49 · Speed 66</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2992</td></tr>
</table>

Scattered **diaries** tell the story of a Pokémon found in Guyana and the experiment that created **Mewtwo** from it — foreshadowing the post-game legendary in Cerulean Cave.

Your goal is the **Secret Key** on **B1F**, which unlocks **Blaine's gym**. Grab the strong TMs here (Solar Beam, Blizzard) too, then head back to **[[42 - Cinnabar Island]]** for the badge.

⬅️ **Prev:** [[42 - Cinnabar Island]] · ➡️ **Next:** [[44 - Victory Road]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
