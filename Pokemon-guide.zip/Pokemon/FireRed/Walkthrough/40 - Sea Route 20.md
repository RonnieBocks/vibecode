# 40 — Sea Route 20

*The channel past Seafoam Islands to Cinnabar.*

![[40 - Sea Route 20.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="42 - Cinnabar Island" data-href="42 - Cinnabar Island">Cinnabar Island</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="39 - Sea Route 19" data-href="39 - Sea Route 19">Sea Route 19</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Cave</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="41 - Seafoam Islands" data-href="41 - Seafoam Islands">Seafoam Islands</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Stardust</td></tr>
</table>

> [!todo] Do this in order
> 1. Beat the Swimmers & trainers 1–10 (numbered on the map)
> 2. Optionally enter Seafoam Islands (Articuno)
> 3. Surf on to Cinnabar Island

More sea trainers line the route west:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Sea Route 20</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Swimmer F Melissa</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">511</td><td style="padding:5px;color:#212121;">Water Gun, Double Slap, Rain Dance, Body Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 65 · Atk 36 · Def 29 · Sp.Atk 29 · Sp.Def 29 · Speed 60</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">1128</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 90 · Atk 62 · Def 45 · Sp.Atk 45 · Sp.Def 54 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽124</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Picnicker Missy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">736</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 46 · Def 42 · Sp.Atk 26 · Sp.Def 36 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">1128</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 90 · Atk 62 · Def 45 · Sp.Atk 45 · Sp.Def 54 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽620</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Swimmer M Dean</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">795</td><td style="padding:5px;color:#212121;">Camouflage, Swift, Bubble Beam, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 36 · Def 43 · Sp.Atk 54 · Sp.Def 43 · Speed 64</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽140</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Swimmer F Nora</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">622</td><td style="padding:5px;color:#212121;">Icicle Spear, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 44 · Def 65 · Sp.Atk 32 · Sp.Def 20 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">622</td><td style="padding:5px;color:#212121;">Icicle Spear, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 44 · Def 65 · Sp.Atk 32 · Sp.Def 20 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cloyster</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">1305</td><td style="padding:5px;color:#212121;">Withdraw, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 70 · Atk 62 · Def 113 · Sp.Atk 56 · Sp.Def 32 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Bird Keeper Roger</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">1041</td><td style="padding:5px;color:#212121;">Growl, Leer, Fury Attack, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 59 · Def 44 · Sp.Atk 41 · Sp.Def 41 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">1041</td><td style="padding:5px;color:#212121;">Growl, Leer, Fury Attack, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 59 · Def 44 · Sp.Atk 41 · Sp.Def 41 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">726</td><td style="padding:5px;color:#212121;">Gust, Quick Attack, Whirlwind, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 77 · Atk 41 · Def 38 · Sp.Atk 35 · Sp.Def 35 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Swimmer F Tiffany</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1275</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 101 · Atk 69 · Def 50 · Sp.Atk 50 · Sp.Def 61 · Speed 52</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽140</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Picnicker Irene</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">675</td><td style="padding:5px;color:#212121;">Constrict, Acid, Bubble Beam, Wrap</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 29 · Def 26 · Sp.Atk 35 · Sp.Def 65 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">532</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 29 · Def 47 · Sp.Atk 47 · Sp.Def 20 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">642</td><td style="padding:5px;color:#212121;">Growl, Icy Wind, Aurora Beam, Rest</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 32 · Def 38 · Sp.Atk 32 · Sp.Def 47 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽600</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Swimmer F Shirley</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">996</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 44 · Def 62 · Sp.Atk 62 · Sp.Def 32 · Speed 56</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">532</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 29 · Def 47 · Sp.Atk 47 · Sp.Def 20 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">996</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 44 · Def 62 · Sp.Atk 62 · Sp.Def 32 · Speed 56</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Swimmer M Darrin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">498</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer, Water Gun</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 27 · Def 44 · Sp.Atk 44 · Sp.Def 19 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">498</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer, Water Gun</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 27 · Def 44 · Sp.Atk 44 · Sp.Def 19 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">930</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer, Water Gun</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 41 · Def 58 · Sp.Atk 58 · Sp.Def 30 · Speed 52</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">498</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer, Water Gun</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 27 · Def 44 · Sp.Atk 44 · Sp.Def 19 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽112</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Swimmer M Barry</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">643</td><td style="padding:5px;color:#212121;">Icicle Spear, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 59 · Atk 45 · Def 67 · Sp.Atk 32 · Sp.Def 20 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cloyster</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">31</td><td style="padding:5px;color:#212121;">1348</td><td style="padding:5px;color:#212121;">Withdraw, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 63 · Def 116 · Sp.Atk 57 · Sp.Def 32 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽124</td></tr>
</table>

Midway sits the entrance to the **[[41 - Seafoam Islands]]** (where **Articuno** waits). You can also just Surf past to **[[42 - Cinnabar Island]]**.

⬅️ **Prev:** [[39 - Sea Route 19]] · ➡️ **Next:** [[41 - Seafoam Islands]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
