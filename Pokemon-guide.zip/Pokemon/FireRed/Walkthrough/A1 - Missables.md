# ⚠️ A1 — Missables & One-Time Choices

*Everything you can permanently lose or only get once. Read before you reach each spot.*
Back to [[00 - Index & Basics]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚠️ GOLDEN RULE</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;"><b>SAVE before every static encounter below.</b> In FireRed a fainted legendary or Snorlax is gone for good — it does <b>not</b> respawn. If you knock one out (or run), soft-reset to your save and try again.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">TMs are <b>single-use</b> in FireRed (Gen 3). A one-time TM found in the world is one teach only — plan who learns it. Only the TMs sold at the Celadon Dept. Store 2F are unlimited.</td></tr>
</table>

## Static / one-time overworld Pokémon
<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">STATIC ENCOUNTERS — save first!</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Where</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Notes</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Snorlax</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="31 - Route 12" data-href="31 - Route 12">Route 12</a></td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">Blocks the path — wake it with the <b>Poké Flute</b>.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Snorlax</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="28 - Route 16" data-href="28 - Route 16">Route 16</a></td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">Second one, same method. Two Snorlax total in the game.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Articuno</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="41 - Seafoam Islands" data-href="41 - Seafoam Islands">Seafoam Islands B4F</a></td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">Legendary bird. Needs Surf + Strength puzzle.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Zapdos</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="52 - Power Plant" data-href="52 - Power Plant">Power Plant</a></td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">Legendary bird.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Moltres</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="48 - Mt. Ember" data-href="48 - Mt. Ember">Mt. Ember summit</a></td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">Legendary bird (post-game, Sevii).</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Mewtwo</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="53 - Cerulean Cave" data-href="53 - Cerulean Cave">Cerulean Cave B1F</a></td><td style="padding:5px;color:#212121;">70</td><td style="padding:5px;color:#212121;">Strongest catchable; <b>after</b> the Elite Four. Save your Master Ball.</td></tr>
</table>

## One-time gifts & pick-one forks
<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="3" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">GIFTS & CHOICES</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Gift / Choice</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Where</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Notes</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Starter — Bulbasaur / Charmander / Squirtle</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="01 - Pallet Town" data-href="01 - Pallet Town">Oak's Lab</a></td><td style="padding:5px;color:#212121;">Pick <b>1 of 3</b>. The other two are unobtainable in-game — breed with Ditto or save-edit for a Living Dex.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Fossil — Helix (Omanyte) <i>or</i> Dome (Kabuto)</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="10 - Mt. Moon" data-href="10 - Mt. Moon">Mt. Moon</a></td><td style="padding:5px;color:#212121;">Pick <b>1 of 2</b>; revive at Cinnabar Lab. Other fossil needs a trade / save-edit.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Old Amber → Aerodactyl</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="07 - Pewter City" data-href="07 - Pewter City">Pewter Museum</a></td><td style="padding:5px;color:#212121;">One only; revive at Cinnabar Lab.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Hitmonlee <i>or</i> Hitmonchan</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="37 - Saffron City" data-href="37 - Saffron City">Fighting Dojo</a></td><td style="padding:5px;color:#212121;">Pick <b>1 of 2</b>. Other needs a trade / save-edit.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Eevee</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="25 - Celadon City" data-href="25 - Celadon City">Celadon (Condominiums roof)</a></td><td style="padding:5px;color:#212121;">One only. Splits into Vaporeon/Jolteon/Flareon — see the Evolution-Item Budget.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Lapras</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="38 - Silph Co." data-href="38 - Silph Co.">Silph Co. 7F</a></td><td style="padding:5px;color:#212121;">Gift from a Silph employee after you clear the building.</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="09 - Route 4" data-href="09 - Route 4">Route 4 Pokémon Center</a></td><td style="padding:5px;color:#212121;">Salesman sells one for ₽500 (optional, not truly missable).</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Togepi (Egg)</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="55 - Five Island" data-href="55 - Five Island">Water Labyrinth, Five Island</a></td><td style="padding:5px;color:#212121;">Hatches from a one-time Egg gift (post-game).</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Master Ball</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="38 - Silph Co." data-href="38 - Silph Co.">Silph Co. president</a></td><td style="padding:5px;color:#212121;">Only <b>one</b> obtainable normally — save it for Mewtwo.</td></tr>
</table>

## What a solo Living Dex must plan around
For the full 151 with no trade partner, these one-of choices leave permanent gaps you'll close by <b>save-editing</b> (see [[A3 - Trades & Exclusives]]):
- The <b>2 starters</b> you didn't pick (or breed them from your starter's family via Ditto).
- The <b>fossil</b> you didn't revive (Omanyte ↔ Kabuto).
- The <b>Hitmon</b> you didn't pick (Hitmonlee ↔ Hitmonchan).
- <b>Mew</b> — event-only, never obtainable in normal play.


---
*Appendices index: [[00 - Index & Basics#📚 Appendices]] · Back to [[Pokemon FireRed]]*
