# 20 — Route 10

*The bluff above Rock Tunnel — and the Power Plant.*

![[20 - Route 10.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="19 - Route 9" data-href="19 - Route 9">Route 9</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="22 - Lavender Town" data-href="22 - Lavender Town">Lavender Town</a> (via Rock Tunnel)</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Cave</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="21 - Rock Tunnel" data-href="21 - Rock Tunnel">Rock Tunnel</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Building</td><td style="padding:5px;color:#212121;">Power Plant (Zapdos — later)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">13/16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">14/16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ekans 🔴</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">11/13/15/17</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">84%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Super Potion, Max Ether, Cheri Berry, Persim Berry, Nanab Berry</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Voltorb</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Voltorb → Electrode** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Heal at the Route 10 Pokémon Center
> 2. Catch a Voltorb
> 3. Beat trainers 1–6 (numbered on the map)
> 4. Enter Rock Tunnel (note the Power Plant for later)

Route 10 sits atop **Rock Tunnel**, with a **Pokémon Center** right by the cave — heal and stock up before going underground. Catch a **Voltorb** (→ Electrode) in the grass.

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 10</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Picnicker Heidi</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">351</td><td style="padding:5px;color:#212121;">Thunder Wave, Quick Attack, Double Team, Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 27 · Def 17 · Sp.Atk 25 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">291</td><td style="padding:5px;color:#212121;">Encore, Sing, Double Slap, Follow Me</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 23 · Def 24 · Sp.Atk 29 · Sp.Def 31 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽400</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Pokemaniac Mark</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">838</td><td style="padding:5px;color:#212121;">Stomp, Fury Attack, Scary Face, Rock Blast</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 94 · Atk 63 · Def 68 · Sp.Atk 31 · Sp.Def 31 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Lickitung</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">789</td><td style="padding:5px;color:#212121;">Defense Curl, Knock Off, Stomp, Wrap</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 99 · Atk 45 · Def 57 · Sp.Atk 48 · Sp.Def 57 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1392</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Picnicker Carol</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">247</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 23 · Def 21 · Sp.Atk 19 · Sp.Def 19 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">508</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 57 · Atk 30 · Def 28 · Sp.Atk 26 · Sp.Def 26 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽420</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Hiker Clark</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">387</td><td style="padding:5px;color:#212121;">Magnitude, Rock Throw, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 38 · Def 47 · Sp.Atk 17 · Sp.Def 17 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">486</td><td style="padding:5px;color:#212121;">Harden, Rock Throw, Bind, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 23 · Def 72 · Sp.Atk 17 · Sp.Def 23 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽756</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Hiker Trent</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">439</td><td style="padding:5px;color:#212121;">Screech, Bind, Rock Throw, Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 22 · Def 65 · Sp.Atk 16 · Sp.Def 22 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">544</td><td style="padding:5px;color:#212121;">Defense Curl, Mud Sport, Rock Throw, Magnitude</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 41 · Def 48 · Sp.Atk 22 · Sp.Def 22 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽684</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Pokemaniac Herman</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">372</td><td style="padding:5px;color:#212121;">Tail Whip, Bone Club, Headbutt, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 31 · Def 49 · Sp.Atk 27 · Sp.Def 31 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">423</td><td style="padding:5px;color:#212121;">Tackle, Growl, Water Gun, Confusion</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 37 · Def 37 · Sp.Atk 27 · Sp.Def 27 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽960</td></tr>
</table>

The **Power Plant** across the water holds **Zapdos** but needs Surf — come back later. For now, make sure a Pokémon knows **Flash**, then enter **[[21 - Rock Tunnel]]**.

⬅️ **Prev:** [[19 - Route 9]] · ➡️ **Next:** [[21 - Rock Tunnel]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
