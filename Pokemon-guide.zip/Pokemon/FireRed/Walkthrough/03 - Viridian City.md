# 03 — Viridian City

*The eternally green paradise — your first town.*

![[03 - Viridian City.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="05 - Route 2" data-href="05 - Route 2">Route 2</a> → Viridian Forest</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="02 - Route 1" data-href="02 - Route 1">Route 1</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="04 - Route 22" data-href="04 - Route 22">Route 22</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">20–25/25–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">20–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Potion — item ball (Poké Ball icon 🔴) in the grass patch in the town’s <b>north-west</b> (top-left of the map, by the Route 22 gate)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— none catchable yet (water needs a Rod/Surf)</td></tr>
</table>

> [!todo] Do this in order
> 1. Get the Potion (item ball in the north-west grass, by the Route 22 gate)
> 2. Get Oak’s Parcel at the Mart → deliver to Oak in Pallet
> 3. Return for your Pokédex + 5 Poké Balls
> 4. Get the old-man tutorial + Teachy TV
> 5. Head north to Route 2 (Viridian Forest)

Heal at the Center and grab the **Potion** — it’s an **item ball in the small grass patch in the north-west** (top-left of the map, next to the Route 22 gate), easy to miss. Enter the **Poké Mart** — the clerk hands you **Oak’s Parcel**; carry it **south to Pallet** and give it to Oak for your **Pokédex + 5 Poké Balls**. **Now** that you have the Pokédex, step into your **rival’s house** back in Pallet and talk to **Daisy** for the **Town Map** (she won’t give it any earlier).

Back in Viridian, the **old man** blocking the north exit now gives a **catching tutorial** and the **Teachy TV**, opening the path to **Route 2 → [[06 - Viridian Forest]]**. (The **Gym here stays locked until the endgame** — it's actually the **8th gym, Giovanni**; ignore it for now. Its full roster is at the **bottom of this page** for when you come back after Silph Co.)

 Cut trees hide a Move Tutor and side path for later. **Route 22** (west) is an optional early rival fight.

Head **north into [[05 - Route 2]]**.

## 🔒 Endgame — Viridian Gym (come back after 7 badges)
*Ignore this until the very end of the game: the Viridian Gym unlocks after you clear Silph Co. It's the **8th gym**, Giovanni (Ground), and leads into Victory Road. Roster for when you return:*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ VIRIDIAN GYM — Giovanni (Earth Badge) · endgame</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Tamer Jason</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">43</td><td style="padding:5px;color:#212121;">1243</td><td style="padding:5px;color:#212121;">Scary Face, Rock Blast, Horn Drill, Take Down</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 95 · Def 103 · Sp.Atk 48 · Sp.Def 48 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Tamer Cole</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">1228</td><td style="padding:5px;color:#212121;">Bite, Glare, Screech, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 111 · Atk 86 · Def 74 · Sp.Atk 71 · Sp.Def 82 · Speed 83</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tauros</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">1762</td><td style="padding:5px;color:#212121;">Scary Face, Pursuit, Swagger, Rest</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 123 · Atk 98 · Def 94 · Sp.Atk 51 · Sp.Def 75 · Speed 106</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1560</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Black Belt Atsushi</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">753</td><td style="padding:5px;color:#212121;">Revenge, Vital Throw, Submission, Cross Chop</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 146 · Atk 109 · Def 85 · Sp.Atk 73 · Sp.Def 73 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">1251</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 154 · Atk 125 · Def 101 · Sp.Atk 85 · Sp.Def 93 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽960</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Black Belt Kiyo</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">43</td><td style="padding:5px;color:#212121;">1344</td><td style="padding:5px;color:#212121;">Foresight, Revenge, Vital Throw, Submission</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 164 · Atk 134 · Def 108 · Sp.Atk 91 · Sp.Def 99 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1032</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Black Belt Takashi</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1188</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 146 · Atk 119 · Def 96 · Sp.Atk 81 · Sp.Def 88 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">715</td><td style="padding:5px;color:#212121;">Foresight, Revenge, Vital Throw, Submission</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 103 · Def 81 · Sp.Atk 69 · Sp.Def 69 · Speed 69</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1188</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 146 · Atk 119 · Def 96 · Sp.Atk 81 · Sp.Def 88 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽912</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Cooltrainer Samuel</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1291</td><td style="padding:5px;color:#212121;">Slash, Swift, Sand Attack, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 116 · Def 123 · Sp.Atk 75 · Sp.Def 82 · Speed 90</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1291</td><td style="padding:5px;color:#212121;">Slash, Swift, Sand Attack, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 139 · Atk 116 · Def 123 · Sp.Atk 75 · Sp.Def 82 · Speed 90</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1098</td><td style="padding:5px;color:#212121;">Take Down, Rock Blast, Fury Attack, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 146 · Atk 107 · Def 115 · Sp.Atk 65 · Sp.Def 65 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidorino</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">985</td><td style="padding:5px;color:#212121;">Fury Attack, Horn Attack, Poison Sting, Double Kick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 135 · Atk 100 · Def 88 · Sp.Atk 86 · Sp.Def 86 · Speed 94</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoking</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">1629</td><td style="padding:5px;color:#212121;">Thrash, Double Kick, Poison Sting, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 151 · Atk 115 · Def 104 · Sp.Atk 110 · Sp.Def 102 · Speed 110</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1404</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Cooltrainer Yuji</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1326</td><td style="padding:5px;color:#212121;">Slash, Swift, Sand Attack, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 143 · Atk 119 · Def 126 · Sp.Atk 77 · Sp.Def 84 · Speed 92</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1090</td><td style="padding:5px;color:#212121;">Rock Blast, Magnitude, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 127 · Atk 115 · Def 130 · Sp.Atk 77 · Sp.Def 77 · Speed 69</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">879</td><td style="padding:5px;color:#212121;">Dragon Breath, Sandstorm, Rock Throw, Bind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 112 · Atk 77 · Def 164 · Sp.Atk 65 · Sp.Def 77 · Speed 96</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1090</td><td style="padding:5px;color:#212121;">Rock Blast, Magnitude, Rollout, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 127 · Atk 115 · Def 130 · Sp.Atk 77 · Sp.Def 77 · Speed 69</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1009</td><td style="padding:5px;color:#212121;">Bonemerang, Headbutt, Leer, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 131 · Atk 103 · Def 126 · Sp.Atk 81 · Sp.Def 103 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1368</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Cooltrainer Warren</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">982</td><td style="padding:5px;color:#212121;">Bonemerang, Headbutt, Leer, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 128 · Atk 101 · Def 123 · Sp.Atk 79 · Sp.Def 101 · Speed 75</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">982</td><td style="padding:5px;color:#212121;">Bonemerang, Headbutt, Leer, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 128 · Atk 101 · Def 123 · Sp.Atk 79 · Sp.Def 101 · Speed 75</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1098</td><td style="padding:5px;color:#212121;">Take Down, Rock Blast, Fury Attack, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 146 · Atk 107 · Def 115 · Sp.Atk 65 · Sp.Def 65 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidorina</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">976</td><td style="padding:5px;color:#212121;">Fury Swipes, Bite, Poison Sting, Double Kick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 142 · Atk 92 · Def 96 · Sp.Atk 86 · Sp.Def 86 · Speed 87</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoqueen</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">39</td><td style="padding:5px;color:#212121;">1620</td><td style="padding:5px;color:#212121;">Body Slam, Bite, Poison Sting, Double Kick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 158 · Atk 107 · Def 111 · Sp.Atk 102 · Sp.Def 110 · Speed 103</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1404</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Leader Giovanni</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1300</td><td style="padding:5px;color:#212121;">Take Down, Rock Blast, Scary Face, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 127 · Atk 81 · Def 90 · Sp.Atk 32 · Sp.Def 32 · Speed 27</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dugtrio</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">42</td><td style="padding:5px;color:#212121;">1377</td><td style="padding:5px;color:#212121;">Slash, Sand Tomb, Mud Slap, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 72 · Def 47 · Sp.Atk 47 · Sp.Def 63 · Speed 105</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoqueen</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">44</td><td style="padding:5px;color:#212121;">1828</td><td style="padding:5px;color:#212121;">Body Slam, Double Kick, Poison Sting, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 133 · Atk 77 · Def 81 · Sp.Atk 71 · Sp.Def 79 · Speed 71</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoking</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">45</td><td style="padding:5px;color:#212121;">1879</td><td style="padding:5px;color:#212121;">Thrash, Double Kick, Poison Sting, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 127 · Atk 87 · Def 74 · Sp.Atk 81 · Sp.Def 72 · Speed 81</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">50</td><td style="padding:5px;color:#212121;">1446</td><td style="padding:5px;color:#212121;">Take Down, Rock Blast, Scary Face, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 140 · Atk 90 · Def 100 · Sp.Atk 35 · Sp.Def 35 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽5000</td></tr>
</table>

⬅️ **Prev:** [[02 - Route 1]] · ➡️ **Next:** [[04 - Route 22]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- ~~It says to find a potion in the West grass, but I can't find any grass or potion in the game, and it isn't shown on the map clearly. Either it's not listed, its hallucinated, or the symbols need to be improved to better represent what things are rather than just letters.~~ — ✅ Potion relocated to the north-west item ball; maps now use a 🔴 glyph + per-map legend
- ~~After Oak gives Red the Pokedex, then it's possible to obtain the Town Map from Daisy, not any earlier, so it should be part of the walkthrough here.~~ — ✅ prose now sends you back for the Pokédex first, then Daisy's Town Map
- ~~There is no need to disclose info for the Viridian Gym at this point in the walkthrough, it'll just intimidate new players and it's redundant anyway, as it should be shown later when it's actually relevant.~~ — ✅ Giovanni roster moved to a bottom 🔒 Endgame section