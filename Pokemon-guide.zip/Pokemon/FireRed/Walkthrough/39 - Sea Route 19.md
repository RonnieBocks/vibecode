# 39 — Sea Route 19

*The open water south of Fuchsia — Surf required.*

![[39 - Sea Route 19.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="35 - Fuchsia City" data-href="35 - Fuchsia City">Fuchsia City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="40 - Sea Route 20" data-href="40 - Sea Route 20">Sea Route 20</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">— none</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Seadra</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Horsea → Seadra** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Surf south from Fuchsia
> 2. Beat the Swimmers 1–10 (numbered on the map)
> 3. Surf west toward Seafoam / Cinnabar

Surf south from Fuchsia (needs **HM03 Surf** + the Soul Badge). The water is full of **Swimmers**:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Sea Route 19</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Swimmer M Richard</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">675</td><td style="padding:5px;color:#212121;">Constrict, Acid, Bubble Beam, Wrap</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 29 · Def 26 · Sp.Atk 35 · Sp.Def 65 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">622</td><td style="padding:5px;color:#212121;">Icicle Spear, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 44 · Def 65 · Sp.Atk 32 · Sp.Def 20 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Swimmer M Reece</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">688</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 65 · Atk 43 · Def 39 · Sp.Atk 25 · Sp.Def 34 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">514</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 28 · Def 45 · Sp.Atk 45 · Sp.Def 19 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">658</td><td style="padding:5px;color:#212121;">Recover, Camouflage, Swift, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 31 · Def 36 · Sp.Atk 45 · Sp.Def 36 · Speed 54</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽116</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Swimmer M Tony</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">532</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 29 · Def 47 · Sp.Atk 47 · Sp.Def 20 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">532</td><td style="padding:5px;color:#212121;">Smokescreen, Leer, Water Gun, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 29 · Def 47 · Sp.Atk 47 · Sp.Def 20 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Swimmer M David</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">688</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 65 · Atk 43 · Def 39 · Sp.Atk 25 · Sp.Def 34 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Shellder</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">601</td><td style="padding:5px;color:#212121;">Icicle Spear, Supersonic, Aurora Beam, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 42 · Def 63 · Sp.Atk 31 · Sp.Def 19 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1056</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 58 · Def 42 · Sp.Atk 42 · Sp.Def 51 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽116</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Swimmer M Douglas</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">480</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer, Water Gun</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 26 · Def 42 · Sp.Atk 42 · Sp.Def 18 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">607</td><td style="padding:5px;color:#212121;">Supersonic, Constrict, Acid, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 26 · Def 23 · Sp.Atk 32 · Sp.Def 59 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">607</td><td style="padding:5px;color:#212121;">Supersonic, Constrict, Acid, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 26 · Def 23 · Sp.Atk 32 · Sp.Def 59 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">642</td><td style="padding:5px;color:#212121;">Water Sport, Supersonic, Horn Attack, Flail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 61 · Atk 41 · Def 37 · Sp.Atk 23 · Sp.Def 32 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽108</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Swimmer M Matthew</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">495</td><td style="padding:5px;color:#212121;">Hypnosis, Water Gun, Double Slap, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 35 · Def 29 · Sp.Atk 29 · Sp.Def 29 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">841</td><td style="padding:5px;color:#212121;">Hypnosis, Water Gun, Double Slap, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 44 · Def 44 · Sp.Atk 35 · Sp.Def 35 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Swimmer M Axle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">607</td><td style="padding:5px;color:#212121;">Supersonic, Constrict, Acid, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 26 · Def 23 · Sp.Atk 32 · Sp.Def 59 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">607</td><td style="padding:5px;color:#212121;">Supersonic, Constrict, Acid, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 26 · Def 23 · Sp.Atk 32 · Sp.Def 59 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">612</td><td style="padding:5px;color:#212121;">Rapid Spin, Recover, Camouflage, Swift</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 29 · Def 34 · Sp.Atk 42 · Sp.Def 34 · Speed 50</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">480</td><td style="padding:5px;color:#212121;">Bubble, Smokescreen, Leer, Water Gun</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 26 · Def 42 · Sp.Atk 42 · Sp.Def 18 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tentacruel</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">1185</td><td style="padding:5px;color:#212121;">Supersonic, Constrict, Acid, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 42 · Def 40 · Sp.Atk 48 · Sp.Def 69 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽108</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Swimmer F Alice</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">712</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 45 · Def 41 · Sp.Atk 26 · Sp.Def 35 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">1092</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 88 · Atk 60 · Def 44 · Sp.Atk 44 · Sp.Def 53 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Swimmer F Anya</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">445</td><td style="padding:5px;color:#212121;">Hypnosis, Water Gun, Double Slap, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 32 · Def 26 · Sp.Atk 26 · Sp.Def 26 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">642</td><td style="padding:5px;color:#212121;">Water Sport, Supersonic, Horn Attack, Flail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 61 · Atk 41 · Def 37 · Sp.Atk 23 · Sp.Def 32 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">982</td><td style="padding:5px;color:#212121;">Water Sport, Supersonic, Horn Attack, Flail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 54 · Def 40 · Sp.Atk 40 · Sp.Def 48 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">642</td><td style="padding:5px;color:#212121;">Water Sport, Supersonic, Horn Attack, Flail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 61 · Atk 41 · Def 37 · Sp.Atk 23 · Sp.Def 32 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">27</td><td style="padding:5px;color:#212121;">445</td><td style="padding:5px;color:#212121;">Hypnosis, Water Gun, Double Slap, Rain Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 32 · Def 26 · Sp.Atk 26 · Sp.Def 26 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽108</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Swimmer F Connie</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">658</td><td style="padding:5px;color:#212121;">Recover, Camouflage, Swift, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 31 · Def 36 · Sp.Atk 45 · Sp.Def 36 · Speed 54</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">658</td><td style="padding:5px;color:#212121;">Recover, Camouflage, Swift, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 31 · Def 36 · Sp.Atk 45 · Sp.Def 36 · Speed 54</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Staryu</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">658</td><td style="padding:5px;color:#212121;">Recover, Camouflage, Swift, Bubble Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 31 · Def 36 · Sp.Atk 45 · Sp.Def 36 · Speed 54</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽116</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Sis And Bro Lia & Luc</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Goldeen</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">712</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 45 · Def 41 · Sp.Atk 26 · Sp.Def 35 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Seaking</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">30</td><td style="padding:5px;color:#212121;">1092</td><td style="padding:5px;color:#212121;">Supersonic, Horn Attack, Flail, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 88 · Atk 60 · Def 44 · Sp.Atk 44 · Sp.Def 53 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
</table>

Their Tentacool/Goldeen are weak to Electric/Grass. Fish here with the **Super Rod** for a rare **Seadra**. Continue **west to [[40 - Sea Route 20]]**.

⬅️ **Prev:** [[38 - Silph Co.]] · ➡️ **Next:** [[40 - Sea Route 20]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
