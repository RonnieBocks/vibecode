# 25 — Celadon City

*The city of rainbow dreams — department store, Game Corner, and Erika.*

![[25 - Celadon City.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;">Route 16</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="24 - Route 7" data-href="24 - Route 7">Route 7</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">99%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">30–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">99%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">30–40</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Ether (ground)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: PP Up</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Eevee — gift (Celadon Condominiums roof)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Coin Case (house SW) → Game Corner</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Evolution stones, TMs, stat items (Dept. Store)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Silph Scope (from the Rocket Hideout — see [[26 - Rocket Hideout]])</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Eevee — gift</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Porygon — Game Corner prize</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Eevee → Vaporeon → Jolteon → Flareon** — keep **4**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Heal; grab Eevee on the Condominiums roof
> 2. Shop the Dept. Store (stones, TMs, drinks→TMs)
> 3. Get the Coin Case, play the Game Corner (Porygon & prize mons)
> 4. Enter the Rocket Hideout via the poster switch → Silph Scope
> 5. Beat Erika for the Rainbow Badge

Celadon is the biggest city yet. Highlights:

- **Eevee** — a free gift on the **roof of the Condominiums** (top-left building). Grab it! (Water/Thunder/Fire Stones from the Dept. Store make Vaporeon/Jolteon/Flareon.)
- **Department Store** — evolution **stones** (4F), **TMs** (2F), **stat items** (5F), and rooftop **vending drinks** you give to a girl for **TM13/48/49**-tier prizes.
- **Coin Case** (from a man in the SW house) lets you play the **Game Corner** — prizes include **Porygon**, plus **Abra, Clefairy, Dratini, Scyther** (great catches for coins).
- Pick up the **Tea** (Celadon Mansion) to later pass the Saffron guards.

**Team Rocket** runs the Game Corner. Step on the poster switch (a grunt guards it):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TEAM ROCKET — Game Corner</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Team Rocket Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">496</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 52 · Atk 37 · Def 29 · Sp.Atk 25 · Sp.Def 33 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">231</td><td style="padding:5px;color:#212121;">Leech Life, Astonish, Supersonic, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 23 · Def 19 · Sp.Atk 17 · Sp.Def 21 · Speed 27</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽640</td></tr>
</table>

That opens the **[[26 - Rocket Hideout]]**, where you'll beat Giovanni and get the **Silph Scope** (needed for Lavender's Pokémon Tower).

**Celadon Gym — Erika (Grass).** Hidden behind trees; navigate to the leader past her trainers:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ CELADON GYM — Erika (Rainbow Badge)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Lass Kay</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">414</td><td style="padding:5px;color:#212121;">Sleep Powder, Poison Powder, Stun Spore, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 39 · Def 21 · Sp.Atk 37 · Sp.Def 18 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weepinbell</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">744</td><td style="padding:5px;color:#212121;">Wrap, Sleep Powder, Poison Powder, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 46 · Def 28 · Sp.Atk 44 · Sp.Def 25 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽368</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Lass Lisa</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">384</td><td style="padding:5px;color:#212121;">Poison Powder, Stun Spore, Sleep Powder, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 28 · Def 30 · Sp.Atk 39 · Sp.Def 34 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gloom</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">649</td><td style="padding:5px;color:#212121;">Sweet Scent, Poison Powder, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 34 · Def 37 · Sp.Atk 44 · Sp.Def 39 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽368</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Picnicker Tina</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bulbasaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">328</td><td style="padding:5px;color:#212121;">Vine Whip, Poison Powder, Sleep Powder, Razor Leaf</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 28 · Def 28 · Sp.Atk 36 · Sp.Def 36 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ivysaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">724</td><td style="padding:5px;color:#212121;">Vine Whip, Poison Powder, Sleep Powder, Razor Leaf</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 34 · Def 35 · Sp.Atk 43 · Sp.Def 43 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽480</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Beauty Bridget</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">351</td><td style="padding:5px;color:#212121;">Sweet Scent, Poison Powder, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 26 · Def 28 · Sp.Atk 36 · Sp.Def 32 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">378</td><td style="padding:5px;color:#212121;">Wrap, Sleep Powder, Poison Powder, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 52 · Atk 36 · Def 19 · Sp.Atk 34 · Sp.Def 17 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">351</td><td style="padding:5px;color:#212121;">Sweet Scent, Poison Powder, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 26 · Def 28 · Sp.Atk 36 · Sp.Def 32 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">378</td><td style="padding:5px;color:#212121;">Wrap, Sleep Powder, Poison Powder, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 52 · Atk 36 · Def 19 · Sp.Atk 34 · Sp.Def 17 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1512</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Beauty Tamia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">432</td><td style="padding:5px;color:#212121;">Sleep Powder, Poison Powder, Stun Spore, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 41 · Def 21 · Sp.Atk 38 · Sp.Def 19 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">432</td><td style="padding:5px;color:#212121;">Sleep Powder, Poison Powder, Stun Spore, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 41 · Def 21 · Sp.Atk 38 · Sp.Def 19 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1728</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Beauty Lori</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">504</td><td style="padding:5px;color:#212121;">Hypnosis, Reflect, Leech Seed, Confusion</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 24 · Def 43 · Sp.Atk 33 · Sp.Def 26 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1728</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Cooltrainer Mary</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">396</td><td style="padding:5px;color:#212121;">Wrap, Stun Spore, Poison Powder, Growth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 60 · Def 42 · Sp.Atk 57 · Sp.Def 40 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">367</td><td style="padding:5px;color:#212121;">Poison Powder, Stun Spore, Absorb, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 49 · Def 51 · Sp.Atk 60 · Sp.Def 55 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weepinbell</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">711</td><td style="padding:5px;color:#212121;">Vine Whip, Stun Spore, Poison Powder, Growth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 66 · Def 49 · Sp.Atk 64 · Sp.Def 46 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gloom</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">621</td><td style="padding:5px;color:#212121;">Absorb, Stun Spore, Poison Powder, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 55 · Def 57 · Sp.Atk 64 · Sp.Def 60 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ivysaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">664</td><td style="padding:5px;color:#212121;">Razor Leaf, Sleep Powder, Vine Whip, Leech Seed</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 54 · Def 54 · Sp.Atk 62 · Sp.Def 62 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽792</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Leader Erika</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Victreebel</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1186</td><td style="padding:5px;color:#212121;">Stun Spore, Acid, Poison Powder, Giga Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 65 · Def 42 · Sp.Atk 63 · Sp.Def 39 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tangela</td><td style="padding:5px;color:#212121;">Grass</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">853</td><td style="padding:5px;color:#212121;">Poison Powder, Constrict, Ingrain, Giga Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 65 · Atk 31 · Def 60 · Sp.Atk 53 · Sp.Def 24 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vileplume</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1143</td><td style="padding:5px;color:#212121;">Sleep Powder, Acid, Stun Spore, Giga Drain</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 51 · Def 54 · Sp.Atk 63 · Sp.Def 57 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2900</td></tr>
</table>

**Fire, Flying, Psychic, Ice, or Bug** beat her Grass/Poison team; watch **Sleep Powder** and Vileplume's Giga Drain. Your **Growlithe** (Route 7/8) or a Flying-type makes this easy. Winning gives the **Rainbow Badge** (lets you use **Strength**) and **TM19 Giga Drain**.

⬅️ **Prev:** [[24 - Route 7]] · ➡️ **Next:** [[26 - Rocket Hideout]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
