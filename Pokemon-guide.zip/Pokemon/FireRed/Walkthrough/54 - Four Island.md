# 54 — Four Island

*An icy isle — Icefall Cave, HM07 Waterfall, and the Day Care.*

![[54 - Four Island.svg]]
*Four Island*

![[54 - Icefall Cave 1F.svg]]
*Icefall Cave 1F*

![[54 - Icefall Cave B1F.svg]]
*Icefall Cave B1F*

![[54 - Icefall Cave Back.svg]]
*Icefall Cave Back*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Harbor</td><td style="padding:5px;color:#212121;">Ferry (Rainbow Pass)</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Cave</td><td style="padding:5px;color:#212121;">Icefall Cave</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Swinub</td><td style="padding:5px;color:#212121;">Ice/Ground</td><td style="padding:5px;color:#212121;">50%</td><td style="padding:5px;color:#212121;">23/25/27/29/31</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">45/48</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">45</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Delibird</td><td style="padding:5px;color:#212121;">Ice/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">30</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk BACK</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seel</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">43/45/47</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">45/48</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">40</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Dewgong</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">49/51/53</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">41</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf BACK</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">95%</td><td style="padding:5px;color:#212121;">5–20/20–35/35–45</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacruel</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">35–45</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Lapras</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">30–45</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod BACK</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod BACK</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">80%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod BACK</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Shellder 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Icefall Cave 1F: Ultra Ball, HM07 Waterfall</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B1F: Full Restore, NeverMeltIce</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Lorelei’s house & the Pokémon Day Care are in town</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— (Icefall’s Swinub/Delibird are post-National-Dex Johto mons; a rare wild Lapras appears on Surf)</td></tr>
</table>

> [!todo] Do this in order
> 1. Get HM07 Waterfall in Icefall Cave (1F)
> 2. Beat the Rocket inside
> 3. Catch a wild Lapras (Surf, 1%) if you like
> 4. Use the Day Care for breeding/leveling

Four Island opens once you have the **Rainbow Pass** (after the National Dex). Its **Icefall Cave** holds **HM07 Waterfall** on 1F — the last HM — and a lone Team Rocket Grunt:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TEAM ROCKET — Icefall Cave</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Team Rocket Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">439</td><td style="padding:5px;color:#212121;">Wing Attack, Confuse Ray, Air Cutter, Mean Look</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 39 · Def 31 · Sp.Atk 27 · Sp.Def 35 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">439</td><td style="padding:5px;color:#212121;">Wing Attack, Confuse Ray, Air Cutter, Mean Look</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 39 · Def 31 · Sp.Atk 27 · Sp.Def 35 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1392</td><td style="padding:5px;color:#212121;">Bite, Wing Attack, Confuse Ray, Air Cutter</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 105 · Atk 65 · Def 58 · Sp.Atk 54 · Sp.Def 62 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1216</td></tr>
</table>

The cave is full of Ice-types (Seel, Dewgong, plus Johto’s Swinub/Delibird now that you have the National Dex), and a rare **Lapras** appears on the Surf water in the back. Town also has **Lorelei’s house** and the **Pokémon Day Care** (great for breeding back your evolved-away pre-evolutions for the Living Dex). Then ferry on to **[[55 - Five Island]]**.

⬅️ **Prev:** [[53 - Cerulean Cave]] · ➡️ **Next:** [[55 - Five Island]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
