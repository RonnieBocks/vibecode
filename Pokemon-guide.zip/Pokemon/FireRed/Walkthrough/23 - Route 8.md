# 23 — Route 8

*A trainer-packed lane between Lavender and Saffron.*

![[23 - Route 8.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;">Saffron City (blocked) / Underground Path → <a class="internal-link" href="24 - Route 7" data-href="24 - Route 7">Route 7</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="22 - Lavender Town" data-href="22 - Lavender Town">Lavender Town</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">18/20</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">18/20</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Growlithe 🔴</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">15/16/17/18</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ekans 🔴</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">17/19</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Rawst Berry, Lum Berry, Leppa Berry</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Growlithe 🔴</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Growlithe → Arcanine** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Catch a Growlithe (FireRed exclusive)
> 2. Beat trainers 1–12 (numbered on the map)
> 3. Take the Underground Path west to Route 7

Route 8 links Lavender to the Saffron gate (blocked for now). Catch a **🔴 Growlithe** (Fire Stone → Arcanine, a great FireRed exclusive). Then work through the trainers (numbered on the map — note **Twins Eli & Anne** are a **double battle**):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 8</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Lass Paige</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♀</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">289</td><td style="padding:5px;color:#212121;">Double Kick, Poison Sting, Bite, Helping Hand</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 26 · Def 28 · Sp.Atk 23 · Sp.Def 23 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidorina</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">576</td><td style="padding:5px;color:#212121;">Tail Whip, Double Kick, Poison Sting, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 65 · Atk 33 · Def 35 · Sp.Atk 30 · Sp.Def 30 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽368</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Gamer Stan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">363</td><td style="padding:5px;color:#212121;">Bubble, Hypnosis, Water Gun, Double Slap</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 27 · Def 22 · Sp.Atk 22 · Sp.Def 22 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwag</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">363</td><td style="padding:5px;color:#212121;">Bubble, Hypnosis, Water Gun, Double Slap</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 27 · Def 22 · Sp.Atk 22 · Sp.Def 22 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Poliwhirl</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">616</td><td style="padding:5px;color:#212121;">Bubble, Hypnosis, Water Gun, Double Slap</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 33 · Def 33 · Sp.Atk 27 · Sp.Def 27 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1584</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Twins Eli & Anne</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">319</td><td style="padding:5px;color:#212121;">Sing, Double Slap, Follow Me, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 24 · Def 26 · Sp.Atk 31 · Sp.Def 33 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Jigglypuff</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">357</td><td style="padding:5px;color:#212121;">Defense Curl, Pound, Disable, Rollout</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 24 · Def 13 · Sp.Atk 24 · Sp.Def 16 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽264</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Twins Eli & Anne</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">319</td><td style="padding:5px;color:#212121;">Sing, Double Slap, Follow Me, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 24 · Def 26 · Sp.Atk 31 · Sp.Def 33 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Jigglypuff</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">357</td><td style="padding:5px;color:#212121;">Defense Curl, Pound, Disable, Rollout</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 24 · Def 13 · Sp.Atk 24 · Sp.Def 16 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽264</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Super Nerd Leslie</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">634</td><td style="padding:5px;color:#212121;">Sludge, Smokescreen, Smog, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 38 · Def 54 · Sp.Atk 36 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽624</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Lass Andrea</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">354</td><td style="padding:5px;color:#212121;">Scratch, Growl, Bite, Pay Day</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 26 · Def 21 · Sp.Atk 24 · Sp.Def 24 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">354</td><td style="padding:5px;color:#212121;">Scratch, Growl, Bite, Pay Day</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 26 · Def 21 · Sp.Atk 24 · Sp.Def 24 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">354</td><td style="padding:5px;color:#212121;">Scratch, Growl, Bite, Pay Day</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 26 · Def 21 · Sp.Atk 24 · Sp.Def 24 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽384</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Super Nerd Glenn</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">423</td><td style="padding:5px;color:#212121;">Harden, Disable, Sludge, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 40 · Def 27 · Sp.Atk 22 · Sp.Def 27 · Speed 16</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Muk</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">739</td><td style="padding:5px;color:#212121;">Harden, Disable, Sludge, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 51 · Def 38 · Sp.Atk 33 · Sp.Def 49 · Speed 27</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">423</td><td style="padding:5px;color:#212121;">Harden, Disable, Sludge, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 40 · Def 27 · Sp.Atk 22 · Sp.Def 27 · Speed 16</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽528</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Lass Megan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">223</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 22 · Def 20 · Sp.Atk 18 · Sp.Def 18 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">231</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 26 · Def 18 · Sp.Atk 14 · Sp.Def 18 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">243</td><td style="padding:5px;color:#212121;">Peck, Focus Energy, Double Kick, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 26 · Def 20 · Sp.Atk 20 · Sp.Def 20 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">280</td><td style="padding:5px;color:#212121;">Scratch, Growl, Bite, Pay Day</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 22 · Def 18 · Sp.Atk 20 · Sp.Def 20 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">333</td><td style="padding:5px;color:#212121;">Tail Whip, Thunder Wave, Quick Attack, Double Team</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 25 · Def 16 · Sp.Atk 24 · Sp.Def 20 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽304</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Super Nerd Aidan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">441</td><td style="padding:5px;color:#212121;">Sonic Boom, Screech, Tackle, Charge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 17 · Def 25 · Sp.Atk 27 · Sp.Def 27 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Sludge, Smog, Tackle, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 31 · Def 43 · Sp.Atk 29 · Sp.Def 23 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">441</td><td style="padding:5px;color:#212121;">Sonic Boom, Screech, Tackle, Charge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 17 · Def 25 · Sp.Atk 27 · Sp.Def 27 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">381</td><td style="padding:5px;color:#212121;">Sonic Boom, Supersonic, Thunder Shock, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 19 · Def 33 · Sp.Atk 43 · Sp.Def 27 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽480</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Lass Julia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">319</td><td style="padding:5px;color:#212121;">Sing, Double Slap, Follow Me, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 24 · Def 26 · Sp.Atk 31 · Sp.Def 33 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">319</td><td style="padding:5px;color:#212121;">Sing, Double Slap, Follow Me, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 24 · Def 26 · Sp.Atk 31 · Sp.Def 33 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽352</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Gamer Rich</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">468</td><td style="padding:5px;color:#212121;">Roar, Ember, Leer, Odor Sleuth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 38 · Def 26 · Sp.Atk 38 · Sp.Def 29 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Vulpix</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">324</td><td style="padding:5px;color:#212121;">Roar, Quick Attack, Will O Wisp, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 52 · Atk 24 · Def 24 · Sp.Atk 29 · Sp.Def 36 · Speed 36</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1728</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Biker Ricardo</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">537</td><td style="padding:5px;color:#212121;">Sludge, Smog, Tackle, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 33 · Def 46 · Sp.Atk 31 · Sp.Def 24 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">537</td><td style="padding:5px;color:#212121;">Sludge, Smog, Tackle, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 33 · Def 46 · Sp.Atk 31 · Sp.Def 24 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">442</td><td style="padding:5px;color:#212121;">Minimize, Sludge, Disable, Pound</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 41 · Def 28 · Sp.Atk 23 · Sp.Def 28 · Speed 16</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽460</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">13. Biker Jaren</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">462</td><td style="padding:5px;color:#212121;">Harden, Disable, Sludge, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 43 · Def 29 · Sp.Atk 24 · Sp.Def 29 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">462</td><td style="padding:5px;color:#212121;">Harden, Disable, Sludge, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 43 · Def 29 · Sp.Atk 24 · Sp.Def 29 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽480</td></tr>
</table>

The gate west into **Saffron** is blocked (thirsty guards). Instead take the **Underground Path** house to reach **[[24 - Route 7]]** and Celadon.

⬅️ **Prev:** [[22 - Lavender Town]] · ➡️ **Next:** [[24 - Route 7]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
