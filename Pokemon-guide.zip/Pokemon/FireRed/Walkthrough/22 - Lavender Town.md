# 22 — Lavender Town

*A somber town of remembrance — and a haunted tower.*

![[22 - Lavender Town.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="20 - Route 10" data-href="20 - Route 10">Route 10</a> (via Rock Tunnel)</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;">Route 8 → Celadon</td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;">Route 12 (Snorlax — later)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">(Pokémon Tower items come later, once you have the Silph Scope)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— none yet (Tower catches need the Silph Scope)</td></tr>
</table>

> [!todo] Do this in order
> 1. Heal & buy Great Balls at the Mart
> 2. Note the Pokémon Tower (locked until the Silph Scope)
> 3. Head west to Route 8 → Celadon

Lavender Town is a quiet place built around the **Pokémon Tower**, a memorial for departed Pokémon. The **Mart** sells **Great Balls** for the first time — stock up.

Inside the **Tower**, ghosts block your way and you can’t identify them yet — you need the **Silph Scope**, which you’ll get from the Team Rocket Hideout in **Celadon**. So the Tower (and its Gastly/Haunter/Cubone catches + the rival battle + the trapped **Mr. Fuji**) waits until after Celadon.

For now, head **west onto Route 8** toward **Celadon City** and the fourth gym.

⬅️ **Prev:** [[21 - Rock Tunnel]] · ➡️ **Next:** [[23 - Route 8]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
