# 26 — Rocket Hideout

*Team Rocket’s lair beneath the Game Corner — and Giovanni.*

![[26 - Rocket Hideout B1F.svg]]
*B1F*

![[26 - Rocket Hideout B2F.svg]]
*B2F*

![[26 - Rocket Hideout B3F.svg]]
*B3F*

![[26 - Rocket Hideout B4F.svg]]
*B4F*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance / Exit</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="25 - Celadon City" data-href="25 - Celadon City">Celadon City</a> (Game Corner)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B1F: Escape Rope, Hyper Potion</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B2F: Moon Stone, TM12 Taunt, X Speed, Super Potion</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B3F: Rare Candy, TM21 Frustration, Blackglasses, Hidden Nugget</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B4F: Silph Scope, Lift Key, TM49 Snatch, Max Ether, Calcium, Hidden Nest/Net Ball</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— none</td></tr>
</table>

> [!todo] Do this in order
> 1. Ride the arrow-tile mazes down through B1F–B4F
> 2. Beat the Rocket grunts (numbered on the maps)
> 3. Grab the items (Moon Stone, Rare Candy, TMs)
> 4. Beat Giovanni → get the Silph Scope
> 5. Escape and head to Lavender’s Pokémon Tower

Beneath the Game Corner, the Rocket Hideout is a four-floor maze of **arrow-tile conveyor puzzles**. Grab the **Lift Key** (B4F) to use the elevator between floors. Work down through the grunts (numbered on the floor maps):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TEAM ROCKET — Hideout</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">522</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 39 · Def 30 · Sp.Atk 26 · Sp.Def 34 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">522</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 39 · Def 30 · Sp.Atk 26 · Sp.Def 34 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">459</td><td style="padding:5px;color:#212121;">Disable, Confusion, Headbutt, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 25 · Def 23 · Sp.Atk 23 · Sp.Def 42 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">396</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Karate Chop, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 38 · Def 26 · Sp.Atk 19 · Sp.Def 19 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">385</td><td style="padding:5px;color:#212121;">Minimize, Sludge, Disable, Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 37 · Def 25 · Sp.Atk 21 · Sp.Def 25 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Smog, Tackle, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 31 · Def 43 · Sp.Atk 29 · Sp.Def 23 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Smog, Tackle, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 31 · Def 43 · Sp.Atk 29 · Sp.Def 23 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽640</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">423</td><td style="padding:5px;color:#212121;">Minimize, Sludge, Disable, Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 40 · Def 27 · Sp.Atk 22 · Sp.Def 27 · Speed 16</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">537</td><td style="padding:5px;color:#212121;">Sludge, Smog, Tackle, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 33 · Def 46 · Sp.Atk 31 · Sp.Def 24 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽704</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">231</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 26 · Def 18 · Sp.Atk 14 · Sp.Def 18 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">471</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 35 · Def 27 · Sp.Atk 24 · Sp.Def 31 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">471</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 35 · Def 27 · Sp.Atk 24 · Sp.Def 31 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">231</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 26 · Def 18 · Sp.Atk 14 · Sp.Def 18 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽608</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">196</td><td style="padding:5px;color:#212121;">Bite, Astonish, Supersonic, Leech Life</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 20 · Def 16 · Sp.Atk 15 · Sp.Def 18 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">414</td><td style="padding:5px;color:#212121;">Smog, Tackle, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 27 · Def 37 · Sp.Atk 25 · Sp.Def 20 · Speed 16</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">327</td><td style="padding:5px;color:#212121;">Sludge, Disable, Harden, Pound</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 32 · Def 22 · Sp.Atk 18 · Sp.Def 22 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">196</td><td style="padding:5px;color:#212121;">Bite, Astonish, Supersonic, Leech Life</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 20 · Def 16 · Sp.Atk 15 · Sp.Def 18 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">17</td><td style="padding:5px;color:#212121;">421</td><td style="padding:5px;color:#212121;">Hyper Fang, Quick Attack, Tail Whip, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 32 · Def 25 · Sp.Atk 22 · Sp.Def 28 · Speed 37</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽544</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">396</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Karate Chop, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 38 · Def 26 · Sp.Atk 19 · Sp.Def 19 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">396</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Karate Chop, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 38 · Def 26 · Sp.Atk 19 · Sp.Def 19 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">243</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 27 · Def 19 · Sp.Atk 15 · Sp.Def 19 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">496</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 52 · Atk 37 · Def 29 · Sp.Atk 25 · Sp.Def 33 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">436</td><td style="padding:5px;color:#212121;">Hypnosis, Disable, Confusion, Headbutt</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 24 · Def 23 · Sp.Atk 22 · Sp.Def 41 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽640</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">513</td><td style="padding:5px;color:#212121;">Tackle, Smog, Self Destruct, Sludge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 32 · Def 44 · Sp.Atk 30 · Sp.Def 23 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">243</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 23 · Def 19 · Sp.Atk 17 · Sp.Def 21 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">304</td><td style="padding:5px;color:#212121;">Leer, Poison Sting, Bite, Glare</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 32 · Def 25 · Sp.Atk 23 · Sp.Def 29 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandshrew</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">457</td><td style="padding:5px;color:#212121;">Defense Curl, Sand Attack, Poison Sting, Slash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 39 · Def 44 · Sp.Atk 14 · Sp.Def 18 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">724</td><td style="padding:5px;color:#212121;">Leer, Poison Sting, Bite, Glare</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 44 · Def 36 · Sp.Atk 34 · Sp.Def 41 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽736</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandshrew</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">457</td><td style="padding:5px;color:#212121;">Defense Curl, Sand Attack, Poison Sting, Slash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 39 · Def 44 · Sp.Atk 14 · Sp.Def 18 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">304</td><td style="padding:5px;color:#212121;">Leer, Poison Sting, Bite, Glare</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 32 · Def 25 · Sp.Atk 23 · Sp.Def 29 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">802</td><td style="padding:5px;color:#212121;">Scratch, Defense Curl, Sand Attack, Poison Sting</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 51 · Def 55 · Sp.Atk 25 · Sp.Def 30 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽736</td></tr>
</table>

On **B4F** you face **Giovanni** for the first time:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ BOSS — Giovanni (Rocket Hideout)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Giovanni</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">577</td><td style="padding:5px;color:#212121;">Bind, Rock Throw, Harden, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 115 · Atk 90 · Def 147 · Sp.Atk 82 · Sp.Def 90 · Speed 102</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">693</td><td style="padding:5px;color:#212121;">Tail Whip, Stomp, Fury Attack, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 132 · Atk 105 · Def 110 · Sp.Atk 79 · Sp.Def 79 · Speed 77</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kangaskhan</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1087</td><td style="padding:5px;color:#212121;">Bite, Tail Whip, Fake Out, Mega Punch</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 172 · Atk 132 · Def 123 · Sp.Atk 100 · Sp.Def 123 · Speed 129</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2900</td></tr>
</table>

His Ground team is handled by **Water/Grass/Ice**; Kangaskhan hits hard, so heal up. Beating him leaves behind the **Silph Scope**.

With the Silph Scope, head back to **[[22 - Lavender Town]]** and clear the **Pokémon Tower** (Gastly/Haunter/Cubone, a rival battle, the ghost Marowak, and Mr. Fuji → the **Poké Flute**).

⬅️ **Prev:** [[25 - Celadon City]] · ➡️ **Next:** [[27 - Pokémon Tower]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
