# 38 — Silph Co.

*Team Rocket’s eleven-floor takeover — and a rematch with Giovanni.*

![[38 - Silph Co. 1F.svg]]
*1F*

![[38 - Silph Co. 2F.svg]]
*2F*

![[38 - Silph Co. 3F.svg]]
*3F*

![[38 - Silph Co. 4F.svg]]
*4F*

![[38 - Silph Co. 5F.svg]]
*5F*

![[38 - Silph Co. 6F.svg]]
*6F*

![[38 - Silph Co. 7F.svg]]
*7F*

![[38 - Silph Co. 8F.svg]]
*8F*

![[38 - Silph Co. 9F.svg]]
*9F*

![[38 - Silph Co. 10F.svg]]
*10F*

![[38 - Silph Co. 11F.svg]]
*11F*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance / Exit</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="37 - Saffron City" data-href="37 - Saffron City">Saffron City</a> (1F)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">3F: Hyper Potion</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">4F: Max Revive, Escape Rope, Full Heal, TM41 Torment</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">5F: Protein, TM01 Focus Punch, Card Key</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">6F: HP Up, X Special</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">7F: Calcium, TM08 Bulk Up · Lapras (gift from a Silph worker)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">8F: Iron</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">10F: Carbos, Ultra Ball, Rare Candy</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">11F: Zinc · Master Ball (from the Silph president)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Lapras — gift (7F)</td></tr>
</table>

> [!todo] Do this in order
> 1. Climb via stairs/teleporters; grab the Card Key (5F) to open locked doors
> 2. Beat the Rockets & Scientists (numbered on the floor maps)
> 3. Beat the rival on 7F
> 4. Accept the free Lapras from a rescued worker (7F)
> 5. Beat Giovanni on 11F → the president gives you the Master Ball
> 6. Leave — Saffron is freed and Sabrina’s gym opens

Silph Co. is Team Rocket’s HQ — eleven floors of grunts and scientists, connected by stairs and **teleport pads**. Grab the **Card Key** on **5F** to open the locked doors that shortcut the maze.

Work up through the trainers (numbered on the floor maps):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TEAM ROCKET & SCIENTISTS — Silph Co.</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">915</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 45 · Def 40 · Sp.Atk 37 · Sp.Def 42 · Speed 50</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">288</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 27 · Def 22 · Sp.Atk 20 · Sp.Def 25 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">288</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 27 · Def 22 · Sp.Atk 20 · Sp.Def 25 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">621</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 45 · Def 35 · Sp.Atk 30 · Sp.Def 40 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">288</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 27 · Def 22 · Sp.Atk 20 · Sp.Def 25 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">540</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Bonemerang, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 34 · Def 60 · Sp.Atk 28 · Sp.Def 34 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">334</td><td style="padding:5px;color:#212121;">Supersonic, Bite, Wing Attack, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 31 · Def 25 · Sp.Atk 22 · Sp.Def 28 · Speed 36</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽928</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Scientist Jerry</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">534</td><td style="padding:5px;color:#212121;">Supersonic, Sonic Boom, Thunder Wave, Spark</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 52 · Atk 24 · Def 44 · Sp.Atk 58 · Sp.Def 35 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">618</td><td style="padding:5px;color:#212121;">Screech, Sonic Boom, Spark, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 21 · Def 33 · Sp.Atk 35 · Sp.Def 35 · Speed 61</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">966</td><td style="padding:5px;color:#212121;">Supersonic, Sonic Boom, Thunder Wave, Spark</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 38 · Def 58 · Sp.Atk 72 · Sp.Def 44 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1344</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Scientist Connor</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">501</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 77 · Atk 46 · Def 31 · Sp.Atk 25 · Sp.Def 31 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">963</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 51 · Def 67 · Sp.Atk 49 · Sp.Def 41 · Speed 36</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">634</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 38 · Def 54 · Sp.Atk 36 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">963</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 51 · Def 67 · Sp.Atk 49 · Sp.Def 41 · Speed 36</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1248</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">696</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 50 · Def 38 · Sp.Atk 33 · Sp.Def 44 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hypno</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">990</td><td style="padding:5px;color:#212121;">Disable, Confusion, Headbutt, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 45 · Def 44 · Sp.Atk 45 · Sp.Def 69 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">696</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 50 · Def 38 · Sp.Atk 33 · Sp.Def 44 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽896</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Scientist Jose</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">931</td><td style="padding:5px;color:#212121;">Spark, Sonic Boom, Screech, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 34 · Def 45 · Sp.Atk 51 · Sp.Def 51 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1074</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 57 · Def 74 · Sp.Atk 54 · Sp.Def 45 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1392</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Scientist Rodney</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1060</td><td style="padding:5px;color:#212121;">Screech, Sonic Boom, Spark, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 38 · Def 51 · Sp.Atk 57 · Sp.Def 57 · Speed 97</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1584</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">372</td><td style="padding:5px;color:#212121;">Poison Sting, Bite, Glare, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 57 · Atk 38 · Def 29 · Sp.Atk 27 · Sp.Def 35 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">324</td><td style="padding:5px;color:#212121;">Supersonic, Bite, Wing Attack, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 30 · Def 24 · Sp.Atk 21 · Sp.Def 27 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">522</td><td style="padding:5px;color:#212121;">Headbutt, Leer, Focus Energy, Bonemerang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 33 · Def 58 · Sp.Atk 27 · Sp.Def 33 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽896</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">546</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 51 · Def 34 · Sp.Atk 25 · Sp.Def 25 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">633</td><td style="padding:5px;color:#212121;">Confusion, Headbutt, Poison Gas, Meditate</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 32 · Def 31 · Sp.Atk 29 · Sp.Def 57 · Speed 29</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽928</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Scientist Beau</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">897</td><td style="padding:5px;color:#212121;">Spark, Thunder Wave, Sonic Boom, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 36 · Def 54 · Sp.Atk 67 · Sp.Def 41 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">634</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 38 · Def 54 · Sp.Atk 36 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">963</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 51 · Def 67 · Sp.Atk 49 · Sp.Def 41 · Speed 36</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">495</td><td style="padding:5px;color:#212121;">Spark, Thunder Wave, Sonic Boom, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 49 · Atk 23 · Def 41 · Sp.Atk 54 · Sp.Def 33 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1248</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hypno</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1165</td><td style="padding:5px;color:#212121;">Confusion, Headbutt, Poison Gas, Meditate</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 99 · Atk 53 · Def 51 · Sp.Atk 53 · Sp.Def 80 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1056</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Juggler Dalton</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">900</td><td style="padding:5px;color:#212121;">Disable, Psybeam, Reflect, Recover</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 25 · Def 22 · Sp.Atk 74 · Sp.Def 45 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mr Mime</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">844</td><td style="padding:5px;color:#212121;">Reflect, Magical Leaf, Encore, Psybeam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 31 · Def 42 · Sp.Atk 63 · Sp.Def 74 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1160</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">13. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1039</td><td style="padding:5px;color:#212121;">Poison Sting, Bite, Glare, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 61 · Def 50 · Sp.Atk 47 · Sp.Def 57 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1056</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">14. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">546</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 51 · Def 34 · Sp.Atk 25 · Sp.Def 25 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">906</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 63 · Def 45 · Sp.Atk 34 · Sp.Def 39 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽928</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">15. Scientist Taylor</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">550</td><td style="padding:5px;color:#212121;">Spark, Sonic Boom, Screech, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 20 · Def 30 · Sp.Atk 32 · Sp.Def 32 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">610</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 37 · Def 52 · Sp.Atk 35 · Sp.Def 27 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">862</td><td style="padding:5px;color:#212121;">Thunder Wave, Sonic Boom, Supersonic, Thunder Shock</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 35 · Def 52 · Sp.Atk 65 · Sp.Def 40 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">475</td><td style="padding:5px;color:#212121;">Thunder Wave, Sonic Boom, Supersonic, Thunder Shock</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 22 · Def 40 · Sp.Atk 52 · Sp.Def 32 · Speed 27</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">610</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 37 · Def 52 · Sp.Atk 35 · Sp.Def 27 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1200</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">16. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">324</td><td style="padding:5px;color:#212121;">Supersonic, Bite, Wing Attack, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 30 · Def 24 · Sp.Atk 21 · Sp.Def 27 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">324</td><td style="padding:5px;color:#212121;">Supersonic, Bite, Wing Attack, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 30 · Def 24 · Sp.Atk 21 · Sp.Def 27 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1026</td><td style="padding:5px;color:#212121;">Supersonic, Bite, Wing Attack, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 49 · Def 44 · Sp.Atk 41 · Sp.Def 47 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽896</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">17. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">645</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 47 · Def 36 · Sp.Atk 31 · Sp.Def 41 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">300</td><td style="padding:5px;color:#212121;">Supersonic, Bite, Wing Attack, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 28 · Def 23 · Sp.Atk 20 · Sp.Def 25 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">952</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 75 · Atk 46 · Def 41 · Sp.Atk 38 · Sp.Def 44 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">316</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 34 · Def 23 · Sp.Atk 18 · Sp.Def 23 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽832</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">18. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">540</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Bonemerang, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 34 · Def 60 · Sp.Atk 28 · Sp.Def 34 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">540</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Bonemerang, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 34 · Def 60 · Sp.Atk 28 · Sp.Def 34 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽928</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">19. Scientist Joshua</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">931</td><td style="padding:5px;color:#212121;">Screech, Sonic Boom, Spark, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 34 · Def 45 · Sp.Atk 51 · Sp.Def 51 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Muk</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">975</td><td style="padding:5px;color:#212121;">Disable, Sludge, Minimize, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 99 · Atk 65 · Def 48 · Sp.Atk 42 · Sp.Def 63 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1392</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">20. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandshrew</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">577</td><td style="padding:5px;color:#212121;">Defense Curl, Sand Attack, Poison Sting, Slash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 48 · Def 54 · Sp.Atk 16 · Sp.Def 22 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandslash</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1012</td><td style="padding:5px;color:#212121;">Defense Curl, Sand Attack, Poison Sting, Slash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 63 · Def 68 · Sp.Atk 31 · Sp.Def 36 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽928</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">21. Scientist Parker</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">558</td><td style="padding:5px;color:#212121;">Disable, Sludge, Minimize, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 51 · Def 34 · Sp.Atk 28 · Sp.Def 34 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Electrode</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">931</td><td style="padding:5px;color:#212121;">Screech, Sonic Boom, Spark, Self Destruct</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 34 · Def 45 · Sp.Atk 51 · Sp.Def 51 · Speed 86</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1392</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">22. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">645</td><td style="padding:5px;color:#212121;">Scary Face, Hyper Fang, Quick Attack, Tail Whip</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 64 · Atk 47 · Def 36 · Sp.Atk 31 · Sp.Def 41 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">819</td><td style="padding:5px;color:#212121;">Glare, Bite, Poison Sting, Leer</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 49 · Def 40 · Sp.Atk 38 · Sp.Def 46 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">634</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 38 · Def 54 · Sp.Atk 36 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">952</td><td style="padding:5px;color:#212121;">Wing Attack, Bite, Astonish, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 75 · Atk 46 · Def 41 · Sp.Atk 38 · Sp.Def 44 · Speed 51</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽832</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">23. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1038</td><td style="padding:5px;color:#212121;">Smog, Self Destruct, Sludge, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 55 · Def 72 · Sp.Atk 52 · Sp.Def 44 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1026</td><td style="padding:5px;color:#212121;">Supersonic, Bite, Wing Attack, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 49 · Def 44 · Sp.Atk 41 · Sp.Def 47 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">684</td><td style="padding:5px;color:#212121;">Smog, Self Destruct, Sludge, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 41 · Def 58 · Sp.Atk 38 · Sp.Def 30 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽896</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">24. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">612</td><td style="padding:5px;color:#212121;">Confusion, Headbutt, Poison Gas, Meditate</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 71 · Atk 31 · Def 30 · Sp.Atk 29 · Sp.Def 55 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">540</td><td style="padding:5px;color:#212121;">Disable, Sludge, Minimize, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 49 · Def 33 · Sp.Atk 27 · Sp.Def 33 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">528</td><td style="padding:5px;color:#212121;">Karate Chop, Seismic Toss, Foresight, Revenge</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 77 · Atk 49 · Def 33 · Sp.Atk 24 · Sp.Def 24 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽896</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">25. Scientist Ed</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Voltorb</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">618</td><td style="padding:5px;color:#212121;">Spark, Sonic Boom, Screech, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 21 · Def 33 · Sp.Atk 35 · Sp.Def 35 · Speed 61</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">684</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Tackle, Smog</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 41 · Def 58 · Sp.Atk 38 · Sp.Def 30 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magneton</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">966</td><td style="padding:5px;color:#212121;">Spark, Thunder Wave, Sonic Boom, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 38 · Def 58 · Sp.Atk 72 · Sp.Def 44 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1344</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">26. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1026</td><td style="padding:5px;color:#212121;">Supersonic, Bite, Wing Attack, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 49 · Def 44 · Sp.Atk 41 · Sp.Def 47 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">612</td><td style="padding:5px;color:#212121;">Confusion, Headbutt, Poison Gas, Meditate</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 71 · Atk 31 · Def 30 · Sp.Atk 29 · Sp.Def 55 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hypno</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">990</td><td style="padding:5px;color:#212121;">Disable, Confusion, Headbutt, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 85 · Atk 45 · Def 44 · Sp.Atk 45 · Sp.Def 69 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽896</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">27. Scientist Travis</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Magnemite</td><td style="padding:5px;color:#212121;">Electric/Steel</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">552</td><td style="padding:5px;color:#212121;">Supersonic, Sonic Boom, Thunder Wave, Spark</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 25 · Def 45 · Sp.Atk 60 · Sp.Def 36 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">708</td><td style="padding:5px;color:#212121;">Smog, Self Destruct, Sludge, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 42 · Def 60 · Sp.Atk 39 · Sp.Def 31 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1392</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">28. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machoke</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">1032</td><td style="padding:5px;color:#212121;">Seismic Toss, Foresight, Revenge, Vital Throw</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 71 · Def 51 · Sp.Atk 38 · Sp.Def 44 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1056</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">29. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">304</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 50 · Atk 33 · Def 22 · Sp.Atk 17 · Sp.Def 22 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">304</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 50 · Atk 33 · Def 22 · Sp.Atk 17 · Sp.Def 22 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">288</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 27 · Def 22 · Sp.Atk 20 · Sp.Def 25 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">304</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 50 · Atk 33 · Def 22 · Sp.Atk 17 · Sp.Def 22 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">331</td><td style="padding:5px;color:#212121;">Poison Sting, Bite, Glare, Screech</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 52 · Atk 35 · Def 27 · Sp.Atk 25 · Sp.Def 32 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽800</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">30. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">32</td><td style="padding:5px;color:#212121;">595</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Bonemerang, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 37 · Def 65 · Sp.Atk 30 · Sp.Def 37 · Speed 27</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">32</td><td style="padding:5px;color:#212121;">699</td><td style="padding:5px;color:#212121;">Headbutt, Poison Gas, Meditate, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 35 · Def 33 · Sp.Atk 32 · Sp.Def 62 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Marowak</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">32</td><td style="padding:5px;color:#212121;">849</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Bonemerang, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 56 · Def 75 · Sp.Atk 37 · Sp.Def 56 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1024</td></tr>
</table>

On **7F** your rival challenges you:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ RIVAL — Silph Co. 7F</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Bulbasaur</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1363</td><td style="padding:5px;color:#212121;">Quick Attack, Whirlwind, Wing Attack, Feather Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 145 · Atk 101 · Def 97 · Sp.Atk 93 · Sp.Def 93 · Speed 109</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">798</td><td style="padding:5px;color:#212121;">Confusion, Stun Spore, Poison Powder, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 131 · Atk 73 · Def 103 · Sp.Atk 88 · Sp.Def 77 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1605</td><td style="padding:5px;color:#212121;">Bite, Dragon Rage, Leer, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 146 · Atk 127 · Def 95 · Sp.Atk 82 · Sp.Def 110 · Speed 96</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1395</td><td style="padding:5px;color:#212121;">Reflect, Recover, Future Sight, Calm Mind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 75 · Def 71 · Sp.Atk 134 · Sp.Def 99 · Speed 124</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charizard</td><td style="padding:5px;color:#212121;">Fire/Flying</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">1791</td><td style="padding:5px;color:#212121;">Smokescreen, Scary Face, Flamethrower, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 172 · Atk 132 · Def 127 · Sp.Atk 152 · Sp.Def 133 · Speed 145</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1440</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Charmander</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1363</td><td style="padding:5px;color:#212121;">Quick Attack, Whirlwind, Wing Attack, Feather Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 145 · Atk 101 · Def 97 · Sp.Atk 93 · Sp.Def 93 · Speed 109</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">741</td><td style="padding:5px;color:#212121;">Odor Sleuth, Take Down, Flame Wheel, Helping Hand</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 127 · Atk 96 · Def 77 · Sp.Atk 96 · Sp.Def 81 · Speed 88</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">735</td><td style="padding:5px;color:#212121;">Leech Seed, Confusion, Stun Spore, Poison Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 122 · Atk 68 · Def 96 · Sp.Atk 82 · Sp.Def 71 · Speed 68</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1395</td><td style="padding:5px;color:#212121;">Reflect, Recover, Future Sight, Calm Mind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 75 · Def 71 · Sp.Atk 134 · Sp.Def 99 · Speed 124</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Blastoise</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">1800</td><td style="padding:5px;color:#212121;">Water Gun, Bite, Rapid Spin, Protect</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 173 · Atk 131 · Def 145 · Sp.Atk 133 · Sp.Def 149 · Speed 127</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1440</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Squirtle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1363</td><td style="padding:5px;color:#212121;">Quick Attack, Whirlwind, Wing Attack, Feather Dance</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 145 · Atk 101 · Def 97 · Sp.Atk 93 · Sp.Def 93 · Speed 109</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">38</td><td style="padding:5px;color:#212121;">1741</td><td style="padding:5px;color:#212121;">Bite, Dragon Rage, Leer, Twister</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 158 · Atk 138 · Def 103 · Sp.Atk 88 · Sp.Def 119 · Speed 104</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">682</td><td style="padding:5px;color:#212121;">Leer, Odor Sleuth, Take Down, Flame Wheel</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 89 · Def 71 · Sp.Atk 89 · Sp.Def 75 · Speed 82</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1395</td><td style="padding:5px;color:#212121;">Reflect, Recover, Future Sight, Calm Mind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 118 · Atk 75 · Def 71 · Sp.Atk 134 · Sp.Def 99 · Speed 124</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Venusaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">40</td><td style="padding:5px;color:#212121;">1782</td><td style="padding:5px;color:#212121;">Poison Powder, Sleep Powder, Razor Leaf, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 174 · Atk 130 · Def 131 · Sp.Atk 145 · Sp.Def 145 · Speed 129</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1440</td></tr>
</table>

Also on 7F, a rescued **Silph worker gives you a Lapras** (Lv 25) — a fantastic Water/Ice catch. Grab the **stat items** scattered around (Protein, Calcium, HP Up, Carbos, Iron, Zinc) and the **Rare Candy** (10F).

On **11F**, **Giovanni** makes his stand:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ BOSS — Giovanni (Silph Co. 11F)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Giovanni</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidorino</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">934</td><td style="padding:5px;color:#212121;">Poison Sting, Horn Attack, Helping Hand, Fury Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 184 · Atk 150 · Def 139 · Sp.Atk 138 · Sp.Def 138 · Speed 145</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kangaskhan</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">35</td><td style="padding:5px;color:#212121;">1312</td><td style="padding:5px;color:#212121;">Tail Whip, Fake Out, Mega Punch, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 206 · Atk 159 · Def 148 · Sp.Atk 120 · Sp.Def 148 · Speed 155</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhyhorn</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">37</td><td style="padding:5px;color:#212121;">1069</td><td style="padding:5px;color:#212121;">Stomp, Fury Attack, Scary Face, Rock Blast</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 198 · Atk 160 · Def 167 · Sp.Atk 119 · Sp.Def 119 · Speed 116</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoqueen</td><td style="padding:5px;color:#212121;">Poison/Ground</td><td style="padding:5px;color:#212121;">41</td><td style="padding:5px;color:#212121;">1704</td><td style="padding:5px;color:#212121;">Tail Whip, Double Kick, Poison Sting, Body Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 227 · Atk 174 · Def 178 · Sp.Atk 169 · Sp.Def 177 · Speed 169</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽4100</td></tr>
</table>

His Ground/Poison team (Nidoqueen L41 ace) folds to **Water, Grass, Ice, and Psychic**. Beat him and he flees; the **Silph president** thanks you with the **Master Ball** — the one 100%-catch ball, best saved for **Mewtwo**. Saffron is freed, and **Sabrina’s gym** ([[37 - Saffron City]]) is now open.

⬅️ **Prev:** [[37 - Saffron City]] · ➡️ **Next:** [[39 - Sea Route 19]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
