# 27 — Pokémon Tower

*A seven-floor memorial haunted by ghosts, Rocket thugs, and a grieving Marowak.*

![[27 - Pokémon Tower 1F.svg]]
*1F*

![[27 - Pokémon Tower 2F.svg]]
*2F*

![[27 - Pokémon Tower 3F.svg]]
*3F*

![[27 - Pokémon Tower 4F.svg]]
*4F*

![[27 - Pokémon Tower 5F.svg]]
*5F*

![[27 - Pokémon Tower 6F.svg]]
*6F*

![[27 - Pokémon Tower 7F.svg]]
*7F*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance / Exit</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="22 - Lavender Town" data-href="22 - Lavender Town">Lavender Town</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 3F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">90%</td><td style="padding:5px;color:#212121;">13/14/15/16/17/18/19</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">9%</td><td style="padding:5px;color:#212121;">15/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">20</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 4F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">86%</td><td style="padding:5px;color:#212121;">13/14/15/16/17/18/19</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">20</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">9%</td><td style="padding:5px;color:#212121;">15/17</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 5F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">86%</td><td style="padding:5px;color:#212121;">13/14/15/16/17/18/19</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">20</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">9%</td><td style="padding:5px;color:#212121;">15/17</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 6F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">85%</td><td style="padding:5px;color:#212121;">14/15/16/17/18/19</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">6%</td><td style="padding:5px;color:#212121;">21/23</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">9%</td><td style="padding:5px;color:#212121;">17/19</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 7F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">75%</td><td style="padding:5px;color:#212121;">15/16/17/18/19</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">23/25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">17/19</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">3F: Escape Rope</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">4F: Elixir, Awakening, Great Ball</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">5F: Nugget, Cleanse Tag</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">5F hidden: Big Mushroom</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">6F: Rare Candy, X Accuracy</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">7F hidden: Soothe Bell</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Poké Flute (from Mr. Fuji, top floor)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Gastly</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Haunter</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Cubone</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Gastly → Haunter → Gengar ⛓** — keep **3**
> - **Cubone → Marowak** — keep **2**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Make sure you have the Silph Scope (from [[26 - Rocket Hideout]])
> 2. Beat the rival on 2F
> 3. Catch Gastly & Cubone (Haunter deeper up)
> 4. Beat the Channelers on 3F–6F
> 5. Defeat the ghost Marowak on 7F
> 6. Beat the three Team Rocket Grunts
> 7. Free Mr. Fuji → Poké Flute
> 8. Leave and use the Poké Flute to wake sleeping Snorlax

You need the **Silph Scope** (from the [[26 - Rocket Hideout]]) to see the ghosts here — without it, unidentified spirits block your path.

On **2F**, your rival is waiting:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ RIVAL — Pokémon Tower 2F</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Bulbasaur</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">604</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 60 · Def 57 · Sp.Atk 55 · Sp.Def 55 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">483</td><td style="padding:5px;color:#212121;">Hypnosis, Reflect, Leech Seed, Confusion</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 83 · Atk 46 · Def 64 · Sp.Atk 55 · Sp.Def 48 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">1008</td><td style="padding:5px;color:#212121;">Thrash, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 95 · Atk 82 · Def 61 · Sp.Atk 53 · Sp.Def 71 · Speed 62</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">621</td><td style="padding:5px;color:#212121;">Teleport, Kinesis, Confusion, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 39 · Def 37 · Sp.Atk 73 · Sp.Def 53 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmeleon</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">760</td><td style="padding:5px;color:#212121;">Growl, Ember, Metal Claw, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 89 · Atk 62 · Def 59 · Sp.Atk 70 · Sp.Def 62 · Speed 70</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽900</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Charmander</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">604</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 60 · Def 57 · Sp.Atk 55 · Sp.Def 55 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">448</td><td style="padding:5px;color:#212121;">Roar, Ember, Leer, Odor Sleuth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 60 · Def 48 · Sp.Atk 60 · Sp.Def 51 · Speed 55</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggcute</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">462</td><td style="padding:5px;color:#212121;">Hypnosis, Reflect, Leech Seed, Confusion</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 80 · Atk 44 · Def 62 · Sp.Atk 53 · Sp.Def 46 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">621</td><td style="padding:5px;color:#212121;">Teleport, Kinesis, Confusion, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 39 · Def 37 · Sp.Atk 73 · Sp.Def 53 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Wartortle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">765</td><td style="padding:5px;color:#212121;">Withdraw, Water Gun, Bite, Rapid Spin</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 89 · Atk 61 · Def 70 · Sp.Atk 62 · Sp.Def 70 · Speed 59</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽900</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Squirtle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">604</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 91 · Atk 60 · Def 57 · Sp.Atk 55 · Sp.Def 55 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">1054</td><td style="padding:5px;color:#212121;">Thrash, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 99 · Atk 85 · Def 64 · Sp.Atk 55 · Sp.Def 74 · Speed 65</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Growlithe</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">429</td><td style="padding:5px;color:#212121;">Roar, Ember, Leer, Odor Sleuth</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 78 · Atk 57 · Def 46 · Sp.Atk 57 · Sp.Def 49 · Speed 53</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kadabra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">621</td><td style="padding:5px;color:#212121;">Teleport, Kinesis, Confusion, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 66 · Atk 39 · Def 37 · Sp.Atk 73 · Sp.Def 53 · Speed 67</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ivysaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">754</td><td style="padding:5px;color:#212121;">Vine Whip, Poison Powder, Sleep Powder, Razor Leaf</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 90 · Atk 61 · Def 61 · Sp.Atk 70 · Sp.Def 70 · Speed 60</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽900</td></tr>
</table>

From **3F up**, the floors swarm with **Gastly** (catch one → Haunter → Gengar) and **Cubone** (→ Marowak); **Haunter** appears more often the higher you climb. The **Channelers** here send out Ghost-types — bring a strong physical attacker or Normal-resisted coverage; their Gastly/Haunter can inflict status:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ CHANNELERS & ROCKETS — Pokémon Tower</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Channeler Hope</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">468</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 21 · Def 18 · Sp.Atk 51 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽736</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Channeler Carly</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 21 · Def 19 · Sp.Atk 53 · Sp.Def 21 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Channeler Patricia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">447</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 20 · Def 18 · Sp.Atk 49 · Sp.Def 20 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽704</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Channeler Laurel</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">468</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 21 · Def 18 · Sp.Atk 51 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">468</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 21 · Def 18 · Sp.Atk 51 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽736</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Channeler Paula</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 21 · Def 19 · Sp.Atk 53 · Sp.Def 21 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Channeler Jody</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">447</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 20 · Def 18 · Sp.Atk 49 · Sp.Def 20 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽704</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Channeler Ruth</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">447</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 20 · Def 18 · Sp.Atk 49 · Sp.Def 20 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽704</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Channeler Tammy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">621</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 53 · Atk 28 · Def 25 · Sp.Atk 57 · Sp.Def 30 · Speed 48</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽736</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Channeler Karina</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 21 · Def 19 · Sp.Atk 53 · Sp.Def 21 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Channeler Janae</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">447</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 20 · Def 18 · Sp.Atk 49 · Sp.Def 20 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽704</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Channeler Jennifer</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 21 · Def 19 · Sp.Atk 53 · Sp.Def 21 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Channeler Emilia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">24</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 21 · Def 19 · Sp.Atk 53 · Sp.Def 21 · Speed 43</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽768</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">13. Channeler Angelica</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">447</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 20 · Def 18 · Sp.Atk 49 · Sp.Def 20 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">447</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 20 · Def 18 · Sp.Atk 49 · Sp.Def 20 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gastly</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">447</td><td style="padding:5px;color:#212121;">Spite, Curse, Night Shade, Confuse Ray</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 45 · Atk 20 · Def 18 · Sp.Atk 49 · Sp.Def 20 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽704</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">14. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">265</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 25 · Def 21 · Sp.Atk 18 · Sp.Def 23 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">280</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 30 · Def 21 · Sp.Atk 16 · Sp.Def 21 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">571</td><td style="padding:5px;color:#212121;">Tail Whip, Quick Attack, Hyper Fang, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 42 · Def 32 · Sp.Atk 28 · Sp.Def 37 · Speed 49</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">265</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 25 · Def 21 · Sp.Atk 18 · Sp.Def 23 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽736</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">15. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">634</td><td style="padding:5px;color:#212121;">Smog, Self Destruct, Sludge, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 38 · Def 54 · Sp.Atk 36 · Sp.Def 28 · Speed 23</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Drowzee</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">567</td><td style="padding:5px;color:#212121;">Disable, Confusion, Headbutt, Poison Gas</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 29 · Def 28 · Sp.Atk 27 · Sp.Def 51 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽832</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">16. Team Rocket Grunt Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">288</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 27 · Def 22 · Sp.Atk 20 · Sp.Def 25 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">288</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 27 · Def 22 · Sp.Atk 20 · Sp.Def 25 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">915</td><td style="padding:5px;color:#212121;">Astonish, Supersonic, Bite, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 45 · Def 40 · Sp.Atk 37 · Sp.Def 42 · Speed 50</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽800</td></tr>
</table>

On **7F**, a **ghost Marowak (Lv 30)** — Cubone's grieving mother — attacks. You **can't catch it**; just defeat it to calm the spirit. Then three **Team Rocket Grunts** are holding **Mr. Fuji** — beat them (they're in the trainers table above) and talk to Mr. Fuji, who gives you the **Poké Flute**.

The Poké Flute wakes the **Snorlax** blocking Routes 12 and 16 (each is a one-time catch — save before waking them). Head out and continue toward **Fuchsia** via the Cycling Road or Route 12.

⬅️ **Prev:** [[26 - Rocket Hideout]] · ➡️ **Next:** [[28 - Route 16]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
