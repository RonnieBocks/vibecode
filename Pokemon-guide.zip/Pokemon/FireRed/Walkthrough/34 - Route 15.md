# 34 — Route 15

*The final stretch into Fuchsia from the east.*

![[34 - Route 15.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">West</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="35 - Fuchsia City" data-href="35 - Fuchsia City">Fuchsia City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="33 - Route 14" data-href="33 - Route 14">Route 14</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Oddish 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">22/24/26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Venonat</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">24/26</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">25/27</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Ditto</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">29</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gloom 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">28/30</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">TM18 Rain Dance</td></tr>
</table>

> [!todo] Do this in order
> 1. Grab TM18 Rain Dance
> 2. Beat the trainers 1–10 (numbered on the map)
> 3. Enter Fuchsia City

The last route before Fuchsia. Grab **TM18 Rain Dance** (upper path).

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 15</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Picnicker Yazmin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">522</td><td style="padding:5px;color:#212121;">Sleep Powder, Poison Powder, Stun Spore, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 48 · Def 25 · Sp.Atk 45 · Sp.Def 22 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">484</td><td style="padding:5px;color:#212121;">Poison Powder, Stun Spore, Sleep Powder, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 65 · Atk 34 · Def 36 · Sp.Atk 48 · Sp.Def 42 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Tangela</td><td style="padding:5px;color:#212121;">Grass</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1030</td><td style="padding:5px;color:#212121;">Growth, Poison Powder, Vine Whip, Bind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 36 · Def 71 · Sp.Atk 63 · Sp.Def 28 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽580</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Picnicker Celia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">33</td><td style="padding:5px;color:#212121;">480</td><td style="padding:5px;color:#212121;">Minimize, Defense Curl, Metronome, Cosmic Power</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 89 · Atk 34 · Def 36 · Sp.Atk 44 · Sp.Def 47 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽660</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Bird Keeper Edwin</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">628</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 68 · Atk 36 · Def 33 · Sp.Atk 31 · Sp.Def 31 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Farfetchd</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">523</td><td style="padding:5px;color:#212121;">Leer, Fury Attack, Knock Off, Fury Cutter</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 63 · Atk 38 · Def 33 · Sp.Atk 35 · Sp.Def 37 · Speed 36</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">534</td><td style="padding:5px;color:#212121;">Pursuit, Fury Attack, Tri Attack, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 49 · Def 28 · Sp.Atk 23 · Sp.Def 23 · Speed 44</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">306</td><td style="padding:5px;color:#212121;">Gust, Quick Attack, Whirlwind, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 28 · Def 25 · Sp.Atk 23 · Sp.Def 23 · Speed 34</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽624</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Bird Keeper Chester</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dodrio</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">948</td><td style="padding:5px;color:#212121;">Pursuit, Fury Attack, Tri Attack, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 71 · Atk 66 · Def 44 · Sp.Atk 38 · Sp.Def 38 · Speed 61</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">576</td><td style="padding:5px;color:#212121;">Pursuit, Fury Attack, Tri Attack, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 57 · Atk 52 · Def 30 · Sp.Atk 24 · Sp.Def 24 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">576</td><td style="padding:5px;color:#212121;">Pursuit, Fury Attack, Tri Attack, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 57 · Atk 52 · Def 30 · Sp.Atk 24 · Sp.Def 24 · Speed 47</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽672</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Picnicker Kindra</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gloom</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">792</td><td style="padding:5px;color:#212121;">Poison Powder, Stun Spore, Sleep Powder, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 71 · Atk 41 · Def 44 · Sp.Atk 52 · Sp.Def 47 · Speed 27</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">468</td><td style="padding:5px;color:#212121;">Poison Powder, Stun Spore, Sleep Powder, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 63 · Atk 33 · Def 35 · Sp.Atk 47 · Sp.Def 41 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">468</td><td style="padding:5px;color:#212121;">Poison Powder, Stun Spore, Sleep Powder, Acid</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 63 · Atk 33 · Def 35 · Sp.Atk 47 · Sp.Def 41 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽560</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Beauty Olivia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bulbasaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">397</td><td style="padding:5px;color:#212121;">Poison Powder, Sleep Powder, Razor Leaf, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 65 · Atk 33 · Def 33 · Sp.Atk 42 · Sp.Def 42 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ivysaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">876</td><td style="padding:5px;color:#212121;">Poison Powder, Sleep Powder, Razor Leaf, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 40 · Def 41 · Sp.Atk 51 · Sp.Def 51 · Speed 39</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2088</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Picnicker Becky</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pikachu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">508</td><td style="padding:5px;color:#212121;">Quick Attack, Double Team, Slam, Thunderbolt</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 59 · Atk 36 · Def 22 · Sp.Atk 34 · Sp.Def 28 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Raichu</td><td style="padding:5px;color:#212121;">Electric</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">757</td><td style="padding:5px;color:#212121;">Thunder Shock, Tail Whip, Quick Attack, Thunderbolt</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 73 · Atk 57 · Def 36 · Sp.Atk 57 · Sp.Def 51 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽580</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Beauty Grace</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeotto</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">702</td><td style="padding:5px;color:#212121;">Gust, Quick Attack, Whirlwind, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 75 · Atk 39 · Def 36 · Sp.Atk 34 · Sp.Def 34 · Speed 46</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Wigglytuff</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">676</td><td style="padding:5px;color:#212121;">Sing, Disable, Defense Curl, Double Slap</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 120 · Atk 45 · Def 31 · Sp.Atk 48 · Sp.Def 34 · Speed 31</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽2088</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Biker Alex</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">684</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 41 · Def 58 · Sp.Atk 38 · Sp.Def 30 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">540</td><td style="padding:5px;color:#212121;">Screech, Minimize, Sludge, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 49 · Def 33 · Sp.Atk 27 · Sp.Def 33 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">28</td><td style="padding:5px;color:#212121;">1038</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 74 · Atk 55 · Def 72 · Sp.Atk 52 · Sp.Def 44 · Speed 38</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽560</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Biker Ernest</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">610</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 37 · Def 52 · Sp.Atk 35 · Sp.Def 27 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">610</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 37 · Def 52 · Sp.Atk 35 · Sp.Def 27 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weezing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">925</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 67 · Atk 50 · Def 65 · Sp.Atk 47 · Sp.Def 40 · Speed 35</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Koffing</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">610</td><td style="padding:5px;color:#212121;">Smokescreen, Sludge, Smog, Tackle</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 37 · Def 52 · Sp.Atk 35 · Sp.Def 27 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Grimer</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">481</td><td style="padding:5px;color:#212121;">Minimize, Sludge, Disable, Pound</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 75 · Atk 45 · Def 30 · Sp.Atk 25 · Sp.Def 30 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽500</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Crush Kin Ron & Mya</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmonchan</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">870</td><td style="padding:5px;color:#212121;">Mach Punch, Thunder Punch, Ice Punch, Fire Punch</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 80 · Def 65 · Sp.Atk 39 · Sp.Def 83 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmonlee</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">862</td><td style="padding:5px;color:#212121;">Jump Kick, Brick Break, Focus Energy, Hi Jump Kick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 82 · Atk 89 · Def 50 · Sp.Atk 39 · Sp.Def 83 · Speed 69</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
</table>

Then head **west into [[35 - Fuchsia City]]**.

⬅️ **Prev:** [[33 - Route 14]] · ➡️ **Next:** [[35 - Fuchsia City]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
