# 12 — Route 24

*Nugget Bridge — five trainers, a Rocket, and a golden prize.*

![[12 - Route 24.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="11 - Cerulean City" data-href="11 - Cerulean City">Cerulean City</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="13 - Route 25" data-href="13 - Route 25">Route 25</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">7</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">7</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">11/13</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Oddish 🔴</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">25%</td><td style="padding:5px;color:#212121;">12/13/14</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Abra</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">8/10/12</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Kakuna</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">8</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Metapod</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">8</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">84%</td><td style="padding:5px;color:#212121;">15–25/25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">TM45 Attract</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Nugget (from the Rocket — sells for ₽5,000)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Hidden: Pecha Berry</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Oddish 🔴</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Abra</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Oddish → Gloom → Vileplume** — keep **3**
> - **Abra → Kadabra → Alakazam ⛓** — keep **3**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Beat the bridge trainers 1–6 (numbered on the map)
> 2. Beat the Rocket → get the Nugget
> 3. Catch Abra (throw a ball turn 1!) and Oddish
> 4. Grab TM45 Attract, then head east

**Nugget Bridge:** six trainers back-to-back (numbered south→north on the map), no healing between — heal in Cerulean first:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ NUGGET BRIDGE — Trainers</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Bug Catcher Cale</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Caterpie</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">112</td><td style="padding:5px;color:#212121;">Tackle, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 29 · Atk 11 · Def 12 · Sp.Atk 9 · Sp.Def 9 · Speed 14</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Weedle</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">111</td><td style="padding:5px;color:#212121;">Poison Sting, String Shot</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 28 · Atk 12 · Def 11 · Sp.Atk 9 · Sp.Def 9 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Metapod</td><td style="padding:5px;color:#212121;">Bug</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">153</td><td style="padding:5px;color:#212121;">Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 30 · Atk 9 · Def 16 · Sp.Atk 10 · Sp.Def 10 · Speed 11</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Kakuna</td><td style="padding:5px;color:#212121;">Bug/Poison</td><td style="padding:5px;color:#212121;">10</td><td style="padding:5px;color:#212121;">151</td><td style="padding:5px;color:#212121;">Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 29 · Atk 10 · Def 15 · Sp.Atk 10 · Sp.Def 10 · Speed 12</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽120</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Lass Ali</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">12</td><td style="padding:5px;color:#212121;">141</td><td style="padding:5px;color:#212121;">Tackle, Sand Attack, Gust</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 31 · Atk 15 · Def 14 · Sp.Atk 13 · Sp.Def 13 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">12</td><td style="padding:5px;color:#212121;">199</td><td style="padding:5px;color:#212121;">Absorb, Sweet Scent</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 32 · Atk 17 · Def 18 · Sp.Atk 23 · Sp.Def 20 · Speed 12</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">12</td><td style="padding:5px;color:#212121;">216</td><td style="padding:5px;color:#212121;">Vine Whip, Growth, Wrap</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 34 · Atk 23 · Def 13 · Sp.Atk 21 · Sp.Def 12 · Speed 14</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽192</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Youngster Timmy</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Sandshrew</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">14</td><td style="padding:5px;color:#212121;">279</td><td style="padding:5px;color:#212121;">Scratch, Defense Curl, Sand Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 38 · Atk 26 · Def 28 · Sp.Atk 10 · Sp.Def 13 · Speed 16</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">14</td><td style="padding:5px;color:#212121;">186</td><td style="padding:5px;color:#212121;">Wrap, Leer, Poison Sting, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 33 · Atk 21 · Def 17 · Sp.Atk 16 · Sp.Def 20 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽224</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Lass Reli</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♂</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">205</td><td style="padding:5px;color:#212121;">Leer, Peck, Focus Energy, Double Kick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 23 · Def 17 · Sp.Atk 17 · Sp.Def 17 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Nidoran♀</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">16</td><td style="padding:5px;color:#212121;">201</td><td style="padding:5px;color:#212121;">Growl, Scratch, Tail Whip, Double Kick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 43 · Atk 20 · Def 21 · Sp.Atk 17 · Sp.Def 17 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽256</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Camper Shane</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">14</td><td style="padding:5px;color:#212121;">171</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 32 · Atk 20 · Def 14 · Sp.Atk 12 · Sp.Def 14 · Speed 25</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">14</td><td style="padding:5px;color:#212121;">186</td><td style="padding:5px;color:#212121;">Wrap, Leer, Poison Sting, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 33 · Atk 21 · Def 17 · Sp.Atk 16 · Sp.Def 20 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽280</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Camper Ethan</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">18</td><td style="padding:5px;color:#212121;">285</td><td style="padding:5px;color:#212121;">Leer, Low Kick, Karate Chop, Fury Swipes</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 42 · Atk 33 · Def 17 · Sp.Atk 17 · Sp.Def 21 · Speed 30</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽360</td></tr>
</table>

At the top, a **Team Rocket** member gives you a **Nugget** (sell for ₽5,000) and tries to recruit you — refuse and battle him:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TEAM ROCKET — Nugget Bridge</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Team Rocket Grunt</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Ekans</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">15</td><td style="padding:5px;color:#212121;">198</td><td style="padding:5px;color:#212121;">Wrap, Leer, Poison Sting, Bite</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 35 · Atk 23 · Def 18 · Sp.Atk 17 · Sp.Def 21 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">15</td><td style="padding:5px;color:#212121;">172</td><td style="padding:5px;color:#212121;">Leech Life, Astonish, Supersonic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 37 · Atk 18 · Def 15 · Sp.Atk 14 · Sp.Def 17 · Speed 21</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽480</td></tr>
</table>

Catch **Abra** (⚠️ throw a ball on turn 1 — it Teleports away) and **🔴 Oddish**. Grab **TM45 Attract**, then head **east to [[13 - Route 25]]**.

⬅️ **Prev:** [[11 - Cerulean City]] · ➡️ **Next:** [[13 - Route 25]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
