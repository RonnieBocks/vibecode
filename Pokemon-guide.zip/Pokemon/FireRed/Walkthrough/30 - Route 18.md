# 30 — Route 18

*The short eastern gate into Fuchsia City.*

![[30 - Route 18.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="29 - Route 17" data-href="29 - Route 17">Route 17</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">East</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="35 - Fuchsia City" data-href="35 - Fuchsia City">Fuchsia City</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Grass</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">20/22</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Doduo</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">24/26/28</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Raticate</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">25/29</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">25/27/29</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">22</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">(in-game trade in the gatehouse: Golduck → Lickitung)</td></tr>
</table>

> [!todo] Do this in order
> 1. Beat the Bird Keepers 1–3
> 2. Do the Lickitung trade in the gatehouse
> 3. Enter Fuchsia City

The bottom of the Cycling Road. Three **Bird Keepers** guard it:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Route 18</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Bird Keeper Wilton</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">360</td><td style="padding:5px;color:#212121;">Leer, Fury Attack, Pursuit, Aerial Ace</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 39 · Def 22 · Sp.Atk 22 · Sp.Def 22 · Speed 45</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">29</td><td style="padding:5px;color:#212121;">1006</td><td style="padding:5px;color:#212121;">Growl, Leer, Fury Attack, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 76 · Atk 57 · Def 42 · Sp.Atk 40 · Sp.Def 40 · Speed 63</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽696</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Bird Keeper Ramiro</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dodrio</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">34</td><td style="padding:5px;color:#212121;">1150</td><td style="padding:5px;color:#212121;">Pursuit, Fury Attack, Tri Attack, Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 84 · Atk 79 · Def 52 · Sp.Atk 45 · Sp.Def 45 · Speed 73</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽816</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Bird Keeper Jacob</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">322</td><td style="padding:5px;color:#212121;">Leer, Fury Attack, Pursuit, Aerial Ace</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 36 · Def 20 · Sp.Atk 21 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">322</td><td style="padding:5px;color:#212121;">Leer, Fury Attack, Pursuit, Aerial Ace</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 36 · Def 20 · Sp.Atk 21 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Fearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">901</td><td style="padding:5px;color:#212121;">Growl, Leer, Fury Attack, Pursuit</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 69 · Atk 51 · Def 38 · Sp.Atk 36 · Sp.Def 36 · Speed 57</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Spearow</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">26</td><td style="padding:5px;color:#212121;">322</td><td style="padding:5px;color:#212121;">Leer, Fury Attack, Pursuit, Aerial Ace</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 56 · Atk 36 · Def 20 · Sp.Atk 21 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽624</td></tr>
</table>

In the **gatehouse**, a boy trades his **Lickitung** for your **Golduck** — a free dex entry if you have a spare Golduck. Then head **east into [[35 - Fuchsia City]]**.

⬅️ **Prev:** [[29 - Route 17]] · ➡️ **Next:** [[31 - Route 12]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
