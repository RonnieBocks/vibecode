# 01 — Pallet Town

*A tranquil town of white and green — where every journey begins.*

![[01 - Pallet Town.svg]]

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">North</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="02 - Route 1" data-href="02 - Route 1">Route 1</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">South (Surf)</td><td style="padding:5px;color:#212121;">Sea Route 21 → Cinnabar</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🏄 Surf</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Tentacool</td><td style="padding:5px;color:#212121;">Water/Poison</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10/10–20/20–30/30–35/35–40</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Old Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">100%</td><td style="padding:5px;color:#212121;">5–10</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Good Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">60%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Magikarp</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Krabby</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">20%</td><td style="padding:5px;color:#212121;">5–15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🎣 Super Rod</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Horsea</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Shellder 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">40%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">15–25</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Seadra</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">4%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Psyduck 🔴</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">1%</td><td style="padding:5px;color:#212121;">25–35</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Potion (your bedroom PC)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Town Map (Rival’s house — Daisy)</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">Pokédex + 5 Poké Balls (from Oak, after the Parcel)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Bulbasaur</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Squirtle</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Charmander (choose one)</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Your starter's line** (Bulbasaur / Charmander / Squirtle → its 3 stages) — you get **one** starter, so keep **3** of your line by breeding spares with Ditto later; the other two lines are save-edit ([[A3 - Trades & Exclusives]]).
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Grab the Potion from your bedroom PC
> 2. Choose your starter in Oak’s Lab
> 3. Win the rival battle
> 4. Head north to Route 1
> *(The Town Map comes later — Daisy only gives it once you have the Pokédex, after the Viridian parcel run.)*

Start in your bedroom and take the **Potion** from the **PC** (top-left). Head downstairs — Mom heals you any time — and go out.

Try to leave north; **Prof. Oak** stops you and leads you to his **Lab**. Pick your starter (left **Bulbasaur**, middle **Squirtle**, right **Charmander**); your rival takes the one that beats it and challenges you:

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ RIVAL — Oak’s Lab</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Bulbasaur</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">5</td><td style="padding:5px;color:#212121;">69</td><td style="padding:5px;color:#212121;">Scratch, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 18 · Atk 10 · Def 9 · Sp.Atk 11 · Sp.Def 10 · Speed 11</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽80</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Charmander</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Squirtle</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">5</td><td style="padding:5px;color:#212121;">70</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 19 · Atk 9 · Def 11 · Sp.Atk 10 · Sp.Def 11 · Speed 9</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽80</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Squirtle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bulbasaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">5</td><td style="padding:5px;color:#212121;">67</td><td style="padding:5px;color:#212121;">Tackle, Growl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 19 · Atk 9 · Def 9 · Sp.Atk 11 · Sp.Def 11 · Speed 9</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽80</td></tr>
</table>

Spam your damaging move (heal with your Potion if needed) to win — you’ll reach about **Level 6**. Then head **north to [[02 - Route 1]]**.

> [!note] You’ll be back — and *then* get the Town Map
> **Daisy won’t give you the Town Map yet** — she only offers it **after you have the Pokédex**. That happens when you buy at the Viridian Mart, get handed **Oak’s Parcel**, and deliver it back to **Oak here** (he gives you and your rival the **Pokédex + 5 Poké Balls**). *After* that, pop into your **rival’s house** next door and talk to **Daisy** for the **Town Map**. See [[03 - Viridian City]] for the parcel run.

➡️ **Next:** [[02 - Route 1]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- ~~I actually recieved 67 XP for my first rival battle, Squirtle VS Bulbasaur, not 45. I did grow to level 6. I did get $80 for winning.~~ — ✅ trainer-exp ×1.5 bug fixed guide-wide — rival Bulbasaur now shows 67
- ~~Daisy will not offer Red the map until after the Parcel has been returned to Oak and he tasks Red and Blue with completing the Pokedex.~~ — ✅ Town Map step moved to after the Pokédex/parcel run
- 
