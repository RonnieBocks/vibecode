# 45 — Elite Four & Champion

*The Indigo Plateau — five straight battles for the title.*



<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance</td><td style="padding:5px;color:#212121;">Victory Road / Indigo Plateau Pokémon Center</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">(Heal & stock up at the Plateau Pokémon Center — the last shop before the gauntlet)</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">— none</td></tr>
</table>

> [!todo] Do this in order
> 1. Heal & buy Full Restores / Revives at the Plateau Center
> 2. Beat Lorelei (Ice)
> 3. Beat Bruno (Fighting/Rock)
> 4. Beat Agatha (Ghost/Poison)
> 5. Beat Lance (Dragon/Flying)
> 6. Beat the Champion (your rival)

The League is **five battles back-to-back with no healing between** — use items mid-fight. Every Elite's ace holds a Sitrus Berry, and they all carry Full Restores. Heal and stock **Full Restores/Revives** at the Plateau Pokémon Center first.

**1) Lorelei — Ice**

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ ELITE FOUR — Lorelei (Ice)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Lorelei</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dewgong</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">52</td><td style="padding:5px;color:#212121;">1960</td><td style="padding:5px;color:#212121;">Rest, Sheer Cold, Take Down, Ice Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 285 · Atk 207 · Def 218 · Sp.Atk 207 · Sp.Def 233 · Speed 207</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cloyster</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">51</td><td style="padding:5px;color:#212121;">2218</td><td style="padding:5px;color:#212121;">Aurora Beam, Protect, Spikes, Spike Cannon</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 239 · Atk 229 · Def 316 · Sp.Atk 219 · Sp.Def 178 · Speed 203</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowbro</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">52</td><td style="padding:5px;color:#212121;">1827</td><td style="padding:5px;color:#212121;">Headbutt, Amnesia, Withdraw, Psychic</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 290 · Atk 213 · Def 249 · Sp.Atk 239 · Sp.Def 218 · Speed 166</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Jynx</td><td style="padding:5px;color:#212121;">Ice/Psychic</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">1584</td><td style="padding:5px;color:#212121;">Ice Punch, Mean Look, Fake Tears, Body Slam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 269 · Atk 194 · Def 177 · Sp.Atk 264 · Sp.Def 242 · Speed 242</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Lapras</td><td style="padding:5px;color:#212121;">Water/Ice</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">2533</td><td style="padding:5px;color:#212121;">Ice Beam, Rain Dance, Safeguard, Hydro Pump</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 339 · Atk 231 · Def 226 · Sp.Atk 231 · Sp.Def 242 · Speed 204</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽5400</td></tr>
</table>

Electric and Fighting hit hard; her mons are part-Water, so avoid Ice-on-Ice. Watch Lapras's Confuse Ray.

**2) Bruno — Fighting/Rock**

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ ELITE FOUR — Bruno (Fighting)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Bruno</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">51</td><td style="padding:5px;color:#212121;">1179</td><td style="padding:5px;color:#212121;">Dragon Breath, Sandstorm, Slam, Iron Tail</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 224 · Atk 178 · Def 295 · Sp.Atk 163 · Sp.Def 178 · Speed 203</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmonchan</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">53</td><td style="padding:5px;color:#212121;">1590</td><td style="padding:5px;color:#212121;">Sky Uppercut, Mega Punch, Detect, Counter</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 248 · Atk 248 · Def 221 · Sp.Atk 174 · Sp.Def 254 · Speed 218</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Hitmonlee</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">53</td><td style="padding:5px;color:#212121;">1578</td><td style="padding:5px;color:#212121;">Foresight, Endure, Mega Kick, Reversal</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 248 · Atk 264 · Def 193 · Sp.Atk 174 · Sp.Def 254 · Speed 229</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">1249</td><td style="padding:5px;color:#212121;">Sandstorm, Slam, Iron Tail, Sand Tomb</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 236 · Atk 188 · Def 312 · Sp.Atk 172 · Sp.Def 188 · Speed 215</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machamp</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">56</td><td style="padding:5px;color:#212121;">2316</td><td style="padding:5px;color:#212121;">Vital Throw, Submission, Cross Chop, Scary Face</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 306 · Atk 290 · Def 234 · Sp.Atk 217 · Sp.Def 240 · Speed 206</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽5600</td></tr>
</table>

**Psychic** wrecks his Fighting types; strong Water/Grass beat his Onix. His Onix are frail specially.

**3) Agatha — Ghost/Poison**

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ ELITE FOUR — Agatha (Ghost/Poison)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Agatha</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gengar</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">2197</td><td style="padding:5px;color:#212121;">Dream Eater, Destiny Bond, Shadow Ball, Nightmare</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 263 · Atk 210 · Def 204 · Sp.Atk 280 · Sp.Def 221 · Speed 258</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Golbat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">1978</td><td style="padding:5px;color:#212121;">Confuse Ray, Air Cutter, Mean Look, Poison Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 280 · Atk 226 · Def 215 · Sp.Atk 210 · Sp.Def 221 · Speed 237</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Haunter</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">53</td><td style="padding:5px;color:#212121;">1431</td><td style="padding:5px;color:#212121;">Dream Eater, Destiny Bond, Shadow Ball, Nightmare</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 243 · Atk 190 · Def 185 · Sp.Atk 259 · Sp.Def 195 · Speed 238</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arbok</td><td style="padding:5px;color:#212121;">Poison</td><td style="padding:5px;color:#212121;">56</td><td style="padding:5px;color:#212121;">1764</td><td style="padding:5px;color:#212121;">Stockpile, Swallow, Spit Up, Haze</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 273 · Atk 240 · Def 222 · Sp.Atk 217 · Sp.Def 233 · Speed 234</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gengar</td><td style="padding:5px;color:#212121;">Ghost/Poison</td><td style="padding:5px;color:#212121;">58</td><td style="padding:5px;color:#212121;">2361</td><td style="padding:5px;color:#212121;">Dream Eater, Destiny Bond, Shadow Ball, Nightmare</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 282 · Atk 225 · Def 219 · Sp.Atk 300 · Sp.Def 237 · Speed 277</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽5800</td></tr>
</table>

**Psychic** is super-effective, but her Gengars carry Confuse Ray + Double Team — consider paralysis and a Persim/Full Heal.

**4) Lance — Dragon/Flying**

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ ELITE FOUR — Lance (Dragon)</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">Lance</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">56</td><td style="padding:5px;color:#212121;">2568</td><td style="padding:5px;color:#212121;">Hydro Pump, Rain Dance, Dragon Dance, Hyper Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 312 · Atk 285 · Def 233 · Sp.Atk 212 · Sp.Def 257 · Speed 235</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dragonair</td><td style="padding:5px;color:#212121;">Dragon</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">1665</td><td style="padding:5px;color:#212121;">Dragon Rage, Slam, Agility, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 264 · Atk 230 · Def 210 · Sp.Atk 215 · Sp.Def 215 · Speed 215</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dragonair</td><td style="padding:5px;color:#212121;">Dragon</td><td style="padding:5px;color:#212121;">54</td><td style="padding:5px;color:#212121;">1665</td><td style="padding:5px;color:#212121;">Dragon Rage, Slam, Agility, Safeguard</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 264 · Atk 230 · Def 210 · Sp.Atk 215 · Sp.Def 215 · Speed 215</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Aerodactyl</td><td style="padding:5px;color:#212121;">Rock/Flying</td><td style="padding:5px;color:#212121;">58</td><td style="padding:5px;color:#212121;">2509</td><td style="padding:5px;color:#212121;">Ancient Power, Scary Face, Take Down, Hyper Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 305 · Atk 271 · Def 225 · Sp.Atk 219 · Sp.Def 237 · Speed 300</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Dragonite</td><td style="padding:5px;color:#212121;">Dragon/Flying</td><td style="padding:5px;color:#212121;">60</td><td style="padding:5px;color:#212121;">2802</td><td style="padding:5px;color:#212121;">Slam, Agility, Safeguard, Wing Attack</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 329 · Atk 315 · Def 269 · Sp.Atk 275 · Sp.Def 275 · Speed 251</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽6000</td></tr>
</table>

**Ice** (and Electric for Gyarados/Aerodactyl) is the answer; his Dragonite is the big threat.

**5) Champion — your Rival**

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ CHAMPION — Rival</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Bulbasaur</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2173</td><td style="padding:5px;color:#212121;">Whirlwind, Wing Attack, Feather Dance, Agility</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 317 · Atk 249 · Def 243 · Sp.Atk 238 · Sp.Def 238 · Speed 262</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">57</td><td style="padding:5px;color:#212121;">2271</td><td style="padding:5px;color:#212121;">Future Sight, Calm Mind, Psychic, Trick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 275 · Atk 207 · Def 201 · Sp.Atk 304 · Sp.Def 247 · Speed 287</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhydon</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2578</td><td style="padding:5px;color:#212121;">Rock Blast, Horn Drill, Take Down, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 343 · Atk 308 · Def 297 · Sp.Atk 208 · Sp.Def 208 · Speed 202</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggutor</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2679</td><td style="padding:5px;color:#212121;">Hypnosis, Confusion, Stomp, Egg Bomb</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 331 · Atk 267 · Def 255 · Sp.Atk 302 · Sp.Def 232 · Speed 220</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">61</td><td style="padding:5px;color:#212121;">2796</td><td style="padding:5px;color:#212121;">Hydro Pump, Rain Dance, Dragon Dance, Hyper Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 342 · Atk 313 · Def 256 · Sp.Atk 233 · Sp.Def 282 · Speed 259</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charizard</td><td style="padding:5px;color:#212121;">Fire/Flying</td><td style="padding:5px;color:#212121;">63</td><td style="padding:5px;color:#212121;">2821</td><td style="padding:5px;color:#212121;">Flamethrower, Wing Attack, Slash, Dragon Rage</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 331 · Atk 271 · Def 263 · Sp.Atk 302 · Sp.Def 272 · Speed 291</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽6300</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Charmander</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2173</td><td style="padding:5px;color:#212121;">Whirlwind, Wing Attack, Feather Dance, Agility</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 317 · Atk 249 · Def 243 · Sp.Atk 238 · Sp.Def 238 · Speed 262</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">57</td><td style="padding:5px;color:#212121;">2271</td><td style="padding:5px;color:#212121;">Future Sight, Calm Mind, Psychic, Trick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 275 · Atk 207 · Def 201 · Sp.Atk 304 · Sp.Def 247 · Speed 287</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhydon</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2578</td><td style="padding:5px;color:#212121;">Rock Blast, Horn Drill, Take Down, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 343 · Atk 308 · Def 297 · Sp.Atk 208 · Sp.Def 208 · Speed 202</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arcanine</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2692</td><td style="padding:5px;color:#212121;">Roar, Ember, Odor Sleuth, Extreme Speed</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 325 · Atk 285 · Def 249 · Sp.Atk 273 · Sp.Def 249 · Speed 267</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Exeggutor</td><td style="padding:5px;color:#212121;">Grass/Psychic</td><td style="padding:5px;color:#212121;">61</td><td style="padding:5px;color:#212121;">2770</td><td style="padding:5px;color:#212121;">Hypnosis, Confusion, Stomp, Egg Bomb</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 342 · Atk 276 · Def 264 · Sp.Atk 313 · Sp.Def 239 · Speed 227</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Blastoise</td><td style="padding:5px;color:#212121;">Water</td><td style="padding:5px;color:#212121;">63</td><td style="padding:5px;color:#212121;">2835</td><td style="padding:5px;color:#212121;">Rapid Spin, Protect, Rain Dance, Skull Bash</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 333 · Atk 270 · Def 291 · Sp.Atk 272 · Sp.Def 297 · Speed 263</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽6300</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">If you chose Squirtle</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgeot</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2173</td><td style="padding:5px;color:#212121;">Whirlwind, Wing Attack, Feather Dance, Agility</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 317 · Atk 249 · Def 243 · Sp.Atk 238 · Sp.Def 238 · Speed 262</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Alakazam</td><td style="padding:5px;color:#212121;">Psychic</td><td style="padding:5px;color:#212121;">57</td><td style="padding:5px;color:#212121;">2271</td><td style="padding:5px;color:#212121;">Future Sight, Calm Mind, Psychic, Trick</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 275 · Atk 207 · Def 201 · Sp.Atk 304 · Sp.Def 247 · Speed 287</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rhydon</td><td style="padding:5px;color:#212121;">Ground/Rock</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2578</td><td style="padding:5px;color:#212121;">Rock Blast, Horn Drill, Take Down, Earthquake</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 343 · Atk 308 · Def 297 · Sp.Atk 208 · Sp.Def 208 · Speed 202</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Gyarados</td><td style="padding:5px;color:#212121;">Water/Flying</td><td style="padding:5px;color:#212121;">59</td><td style="padding:5px;color:#212121;">2704</td><td style="padding:5px;color:#212121;">Hydro Pump, Rain Dance, Dragon Dance, Hyper Beam</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 331 · Atk 302 · Def 248 · Sp.Atk 226 · Sp.Def 273 · Speed 251</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Arcanine</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">61</td><td style="padding:5px;color:#212121;">2784</td><td style="padding:5px;color:#212121;">Roar, Ember, Odor Sleuth, Extreme Speed</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 336 · Atk 294 · Def 258 · Sp.Atk 282 · Sp.Def 258 · Speed 276</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Venusaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">63</td><td style="padding:5px;color:#212121;">2808</td><td style="padding:5px;color:#212121;">Razor Leaf, Sweet Scent, Growth, Synthesis</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 334 · Atk 268 · Def 270 · Sp.Atk 291 · Sp.Def 291 · Speed 266</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽6300</td></tr>
</table>

His team is led by his starter's final form. Since you chose **Squirtle**, his ace is **Venusaur — which resists your Blastoise**, so bring Fire/Flying/Ice/Psychic for it, Electric for Gyarados/Pidgeot, and a Fighting/Rock answer for the rest. Beat him and you're the **Champion** — Oak registers your Pokédex upgrade to the **National Dex** and the post-game opens (Cerulean Cave → Mewtwo, plus the rest of the Sevii Islands).

⬅️ **Prev:** [[44 - Victory Road]] · ➡️ **Next (post-game):** [[46 - One Island]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
