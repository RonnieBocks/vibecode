# 21 — Rock Tunnel

*A pitch-black maze of Hikers and rock Pokémon — bring Flash.*

![[21 - Rock Tunnel 1F.svg]]
*1F*

![[21 - Rock Tunnel B1F.svg]]
*B1F*

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="2" style="background:#b71c1c;color:#fff;padding:7px;text-align:center;font-size:1.05em;">CONNECTIONS</th></tr>
<tr><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Direction</th><th style="background:#b71c1c;color:#fff;padding:5px;text-align:left;">Leads To</th></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Entrance (Route 10)</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="20 - Route 10" data-href="20 - Route 10">Route 10</a></td></tr>
<tr style="background:#fbe9e9;"><td style="padding:5px;color:#212121;">Exit (south)</td><td style="padding:5px;color:#212121;"><a class="internal-link" href="22 - Lavender Town" data-href="22 - Lavender Town">Lavender Town</a></td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="4" style="background:#1565c0;color:#fff;padding:7px;text-align:center;font-size:1.05em;">WILD POKÉMON</th></tr>
<tr><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Rate</th><th style="background:#1565c0;color:#fff;padding:5px;text-align:left;">Levels</th></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk 1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">15/16</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">15/16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">13/15</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🌿 Walk B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Zubat</td><td style="padding:5px;color:#212121;">Poison/Flying</td><td style="padding:5px;color:#212121;">30%</td><td style="padding:5px;color:#212121;">15/16</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">35%</td><td style="padding:5px;color:#212121;">15/16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Mankey</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">15%</td><td style="padding:5px;color:#212121;">16/17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">17</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">10%</td><td style="padding:5px;color:#212121;">13/15/17</td></tr>
<tr><th colspan="4" style="background:#5c8fd6;color:#fff;padding:5px;text-align:left;">🪨 Rock Smash B1F</th></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">95%</td><td style="padding:5px;color:#212121;">5–20/10–20/15–30</td></tr>
<tr style="background:#e6f0fb;"><td style="padding:5px;color:#212121;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">5%</td><td style="padding:5px;color:#212121;">25–40/30–40</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#ef6c00;color:#fff;padding:7px;text-align:center;font-size:1.05em;">ITEMS</th></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">1F: Repel, Pearl, Escape Rope</td></tr>
<tr style="background:#fcefe2;"><td style="padding:5px;color:#212121;">B1F: Revive, Max Ether</td></tr>
</table>

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="1" style="background:#6a1b9a;color:#fff;padding:7px;text-align:center;font-size:1.05em;">NEW POKÉMON</th></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Machop</td></tr>
<tr style="background:#f3ebf8;"><td style="padding:5px;color:#212121;">Onix</td></tr>
</table>

> [!tip] 🏠 Living Dex — catch spares here
> For a Living Dex you hold **every stage at once**, so catch extra of each new line (one ends up at each stage; evolve the spares). ⛓ = final stage needs a trade.
> - **Machop → Machoke → Machamp ⛓** — keep **3**
> *Evolve spares with the right level/stone/trade — see [[A2 - Evolution Item Budget]] & [[A3 - Trades & Exclusives]].*

> [!todo] Do this in order
> 1. Use Flash immediately
> 2. Catch a Machop and an Onix
> 3. Beat trainers 1–15 (numbered on the maps)
> 4. Grab the items
> 5. Exit south to Lavender Town

Rock Tunnel is dark — **use Flash the moment you enter** or you’ll barely see. Catch a **Machop** (→ the excellent Machamp line) and an **Onix**. It’s a maze packed with Hikers and Pokémaniacs (numbered across both floors):

<table style="border-collapse:collapse;width:100%;">
<tr><th colspan="5" style="background:#303f9f;color:#fff;padding:7px;text-align:center;font-size:1.05em;">⚔️ TRAINERS — Rock Tunnel</th></tr>
<tr><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Pokémon</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Type</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Lv.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Exp.</th><th style="background:#303f9f;color:#fff;padding:5px;text-align:left;">Moves</th></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">1. Hiker Lenny</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">349</td><td style="padding:5px;color:#212121;">Defense Curl, Mud Sport, Rock Throw, Magnitude</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 35 · Def 43 · Sp.Atk 16 · Sp.Def 16 · Speed 12</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">357</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Karate Chop, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 35 · Def 24 · Sp.Atk 18 · Sp.Def 18 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">349</td><td style="padding:5px;color:#212121;">Defense Curl, Mud Sport, Rock Throw, Magnitude</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 35 · Def 43 · Sp.Atk 16 · Sp.Def 16 · Speed 12</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">349</td><td style="padding:5px;color:#212121;">Defense Curl, Mud Sport, Rock Throw, Magnitude</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 35 · Def 43 · Sp.Atk 16 · Sp.Def 16 · Speed 12</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽684</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">2. Pokemaniac Ashton</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">427</td><td style="padding:5px;color:#212121;">Bone Club, Headbutt, Leer, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 34 · Def 55 · Sp.Atk 30 · Sp.Def 34 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">23</td><td style="padding:5px;color:#212121;">487</td><td style="padding:5px;color:#212121;">Tackle, Growl, Water Gun, Confusion</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 81 · Atk 41 · Def 41 · Sp.Atk 30 · Sp.Def 30 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1104</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">3. Hiker Lucas</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">387</td><td style="padding:5px;color:#212121;">Magnitude, Rock Throw, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 38 · Def 47 · Sp.Atk 17 · Sp.Def 17 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">603</td><td style="padding:5px;color:#212121;">Magnitude, Rock Throw, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 44 · Def 53 · Sp.Atk 23 · Sp.Def 23 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽756</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">4. Hiker Oliver</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">462</td><td style="padding:5px;color:#212121;">Screech, Bind, Rock Throw, Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 23 · Def 69 · Sp.Atk 17 · Sp.Def 23 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">462</td><td style="padding:5px;color:#212121;">Screech, Bind, Rock Throw, Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 23 · Def 69 · Sp.Atk 17 · Sp.Def 23 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">367</td><td style="padding:5px;color:#212121;">Defense Curl, Mud Sport, Rock Throw, Magnitude</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 37 · Def 45 · Sp.Atk 17 · Sp.Def 17 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">5. Picnicker Leah</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">396</td><td style="padding:5px;color:#212121;">Wrap, Sleep Powder, Poison Powder, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 38 · Def 20 · Sp.Atk 35 · Sp.Def 18 · Speed 22</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Clefairy</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">319</td><td style="padding:5px;color:#212121;">Sing, Double Slap, Follow Me, Minimize</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 62 · Atk 24 · Def 26 · Sp.Atk 31 · Sp.Def 33 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽440</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">6. Picnicker Ariana</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">223</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 22 · Def 20 · Sp.Atk 18 · Sp.Def 18 · Speed 26</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">231</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 26 · Def 18 · Sp.Atk 14 · Sp.Def 18 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Rattata</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">231</td><td style="padding:5px;color:#212121;">Tackle, Tail Whip, Quick Attack, Hyper Fang</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 40 · Atk 26 · Def 18 · Sp.Atk 14 · Sp.Def 18 · Speed 32</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bellsprout</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">19</td><td style="padding:5px;color:#212121;">342</td><td style="padding:5px;color:#212121;">Wrap, Sleep Powder, Poison Powder, Stun Spore</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 33 · Def 18 · Sp.Atk 31 · Sp.Def 16 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽380</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">7. Picnicker Dana</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">295</td><td style="padding:5px;color:#212121;">Scratch, Growl, Bite, Pay Day</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 23 · Def 19 · Sp.Atk 21 · Sp.Def 21 · Speed 41</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">333</td><td style="padding:5px;color:#212121;">Sweet Scent, Poison Powder, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 48 · Atk 25 · Def 27 · Sp.Atk 35 · Sp.Def 31 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">235</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 46 · Atk 23 · Def 21 · Sp.Atk 19 · Sp.Def 19 · Speed 27</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽400</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">8. Hiker Eric</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Machop</td><td style="padding:5px;color:#212121;">Fighting</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">376</td><td style="padding:5px;color:#212121;">Leer, Focus Energy, Karate Chop, Seismic Toss</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 58 · Atk 37 · Def 25 · Sp.Atk 19 · Sp.Def 19 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Onix</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">462</td><td style="padding:5px;color:#212121;">Screech, Bind, Rock Throw, Harden</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 44 · Atk 23 · Def 69 · Sp.Atk 17 · Sp.Def 23 · Speed 33</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽720</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">9. Pokemaniac Cooper</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">423</td><td style="padding:5px;color:#212121;">Tackle, Growl, Water Gun, Confusion</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 37 · Def 37 · Sp.Atk 27 · Sp.Def 27 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">423</td><td style="padding:5px;color:#212121;">Tackle, Growl, Water Gun, Confusion</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 37 · Def 37 · Sp.Atk 27 · Sp.Def 27 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">20</td><td style="padding:5px;color:#212121;">423</td><td style="padding:5px;color:#212121;">Tackle, Growl, Water Gun, Confusion</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 72 · Atk 37 · Def 37 · Sp.Atk 27 · Sp.Def 27 · Speed 17</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽960</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">10. Hiker Dudley</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">387</td><td style="padding:5px;color:#212121;">Magnitude, Rock Throw, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 38 · Def 47 · Sp.Atk 17 · Sp.Def 17 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">387</td><td style="padding:5px;color:#212121;">Magnitude, Rock Throw, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 38 · Def 47 · Sp.Atk 17 · Sp.Def 17 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Graveler</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">603</td><td style="padding:5px;color:#212121;">Magnitude, Rock Throw, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 54 · Atk 44 · Def 53 · Sp.Atk 23 · Sp.Def 23 · Speed 19</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽756</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">11. Hiker Allen</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Geodude</td><td style="padding:5px;color:#212121;">Rock/Ground</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">460</td><td style="padding:5px;color:#212121;">Magnitude, Rock Throw, Mud Sport, Defense Curl</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 45 · Def 55 · Sp.Atk 20 · Sp.Def 20 · Speed 15</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽900</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">12. Picnicker Sofia</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Jigglypuff</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">342</td><td style="padding:5px;color:#212121;">Defense Curl, Pound, Disable, Rollout</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 79 · Atk 23 · Def 13 · Sp.Atk 23 · Sp.Def 15 · Speed 13</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Pidgey</td><td style="padding:5px;color:#212121;">Normal/Flying</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">247</td><td style="padding:5px;color:#212121;">Sand Attack, Gust, Quick Attack, Whirlwind</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 23 · Def 21 · Sp.Atk 19 · Sp.Def 19 · Speed 28</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Meowth</td><td style="padding:5px;color:#212121;">Normal</td><td style="padding:5px;color:#212121;">21</td><td style="padding:5px;color:#212121;">310</td><td style="padding:5px;color:#212121;">Scratch, Growl, Bite, Pay Day</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 47 · Atk 23 · Def 19 · Sp.Atk 21 · Sp.Def 21 · Speed 42</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽420</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">13. Pokemaniac Steve</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Charmander</td><td style="padding:5px;color:#212121;">Fire</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">306</td><td style="padding:5px;color:#212121;">Growl, Ember, Metal Claw, Smokescreen</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 55 · Atk 34 · Def 30 · Sp.Atk 38 · Sp.Def 33 · Speed 40</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Cubone</td><td style="padding:5px;color:#212121;">Ground</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">409</td><td style="padding:5px;color:#212121;">Bone Club, Headbutt, Leer, Focus Energy</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 60 · Atk 33 · Def 53 · Sp.Atk 29 · Sp.Def 33 · Speed 27</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1056</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">14. Picnicker Martha</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Oddish</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">367</td><td style="padding:5px;color:#212121;">Sweet Scent, Poison Powder, Stun Spore, Sleep Powder</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 27 · Def 29 · Sp.Atk 38 · Sp.Def 33 · Speed 18</td></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Bulbasaur</td><td style="padding:5px;color:#212121;">Grass/Poison</td><td style="padding:5px;color:#212121;">22</td><td style="padding:5px;color:#212121;">301</td><td style="padding:5px;color:#212121;">Vine Whip, Poison Powder, Sleep Powder, Razor Leaf</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 51 · Atk 26 · Def 26 · Sp.Atk 33 · Sp.Def 33 · Speed 24</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽440</td></tr>
<tr><th colspan="5" style="background:#5c6bc0;color:#fff;padding:5px;text-align:left;">15. Pokemaniac Winston</th></tr>
<tr style="background:#e9ebf7;"><td rowspan="2" style="padding:5px;color:#212121;font-weight:bold;">Slowpoke</td><td style="padding:5px;color:#212121;">Water/Psychic</td><td style="padding:5px;color:#212121;">25</td><td style="padding:5px;color:#212121;">529</td><td style="padding:5px;color:#212121;">Growl, Water Gun, Confusion, Disable</td></tr>
<tr style="background:#e9ebf7;"><td colspan="4" style="padding:5px;color:#212121;">HP 87 · Atk 45 · Def 45 · Sp.Atk 32 · Sp.Def 32 · Speed 20</td></tr>
<tr style="background:#e9ebf7;"><td style="padding:5px;color:#212121;font-weight:bold;">Reward</td><td colspan="4" style="padding:5px;color:#212121;">₽1200</td></tr>
</table>

Their Geodude/Onix are weak to your Water/Grass; watch the Pokémaniacs’ higher-level mons. Grab the items on each floor, then take the **south exit to [[22 - Lavender Town]]**.

⬅️ **Prev:** [[20 - Route 10]] · ➡️ **Next:** [[22 - Lavender Town]]

## Walkthrough Notes
*Jot observations as you play — I'll fold fixes into the guide and ~~strike through~~ notes once addressed.*
- 
