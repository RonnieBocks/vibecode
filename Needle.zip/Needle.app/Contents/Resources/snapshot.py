#!/usr/bin/env python3
"""Snapshot Music.app playlists and track state to a timestamped folder.

    python3 snapshot.py             take one now (recorded as manual)
    python3 snapshot.py --scheduled the nightly run; marks the day's anchor point
    python3 snapshot.py --list      show what's been taken
    python3 snapshot.py --prune 30  keep only the newest 30

Read-only: never modifies the library. Writes JSON plus a plain .txt
listing per playlist you can read with no tooling at all.
"""
import collections, json, os, re, shutil, subprocess, sys, datetime

APP_SUPPORT = os.path.expanduser("~/Library/Application Support/Needle")
ROOT = os.path.join(APP_SUPPORT, "snapshots")
FIELDS = "pid name artist albumartist album genre year plays rating added played".split()

def osa(script, timeout=1800):
    r = subprocess.run(["osascript", "-"], input=script, capture_output=True,
                       text=True, timeout=timeout)
    if not (r.stdout or "").strip() and r.stderr:
        raise RuntimeError(r.stderr.strip())
    return r.stdout.strip()

TRACKS = r'''
tell application "Music"
  set L to library playlist 1
  set rawA to date added of every track of L
  set rawP to played date of every track of L
end tell
on fmt(dl)
  set o to {}
  repeat with v in dl
    try
      set d to contents of v
      set end of o to ((year of d) as text) & "-" & (text -2 thru -1 of ("0" & ((month of d) as integer as text))) & "-" & (text -2 thru -1 of ("0" & ((day of d) as text)))
    on error
      set end of o to ""
    end try
  end repeat
  return o
end fmt
set aL to my fmt(rawA)
set pL to my fmt(rawP)
set AppleScript's text item delimiters to "<|>"
tell application "Music"
  set L to library playlist 1
  set o to {}
  set end of o to ((count of tracks of L) as text)
  set end of o to (persistent ID of every track of L) as text
  set end of o to (name of every track of L) as text
  set end of o to (artist of every track of L) as text
  set end of o to (album artist of every track of L) as text
  set end of o to (album of every track of L) as text
  set end of o to (genre of every track of L) as text
  set end of o to (year of every track of L) as text
  set end of o to (played count of every track of L) as text
  set end of o to (rating of every track of L) as text
end tell
set end of o to (aL as text)
set end of o to (pL as text)
set AppleScript's text item delimiters to "<@>"
return o as text'''

PLAYLISTS = r'''
set AppleScript's text item delimiters to "<,>"
tell application "Music"
  set o to {}
  repeat with p in user playlists
    set par to ""
    try
      set par to name of parent of p
    end try
    set sk to ""
    try
      set sk to (special kind of p) as text
    end try
    set sm to "false"
    try
      if smart of p then set sm to "true"
    end try
    set ids to ""
    if (count of tracks of p) > 0 then set ids to ((persistent ID of every track of p) as text)
    set end of o to (name of p) & "<=>" & par & "<=>" & sk & "<=>" & sm & "<=>" & ((count of tracks of p) as text) & "<=>" & ids
  end repeat
  set f to {}
  repeat with x in folder playlists
    set fp to ""
    try
      set fp to name of parent of x
    end try
    set end of f to (name of x) & "<=>" & fp
  end repeat
  set AppleScript's text item delimiters to "<@>"
  return (o as text) & "<##>" & (f as text)
end tell'''

def rollup(stamp, tracks, pls):
    """Append a compact line to history.jsonl. Never pruned - this is the long
    memory. Snapshots are the detail; this is the trend."""
    by = {p["name"]: p["count"] for p in pls}
    # Minutes are plays x duration. Apple exposes no listening time, so this is
    # the same estimate Replay and Superfan use. Recorded cumulatively, so any
    # window's listening is a subtraction and survives snapshot pruning.
    gen = collections.Counter((t.get("genre") or "").strip() or "(none)" for t in tracks)
    dec = collections.Counter(
        f"{int(t['year'])//10*10}s" for t in tracks
        if str(t.get("year", "")).strip().isdigit() and int(t["year"]) > 1900)
    rec = {"t": stamp,
           "src": "scheduled" if "--scheduled" in sys.argv else "manual",
           "tracks": len(tracks),
           "plays": sum(int(x["plays"] or 0) for x in tracks),
           "everPlayed": sum(1 for x in tracks if int(x["plays"] or 0) > 0),
           "rated": sum(1 for x in tracks if int(x["rating"] or 0) > 0),
           "playlists": len(pls),
           # Record whatever is in the Listening folder rather than a fixed
           # list of names - zones get renamed, and a whitelist silently drops
           # any zone it has not been told about (Familiar was missing for
           # exactly this reason). The dashboard maps old names to new.
           "zones": {p["name"]: p["count"] for p in pls
                     if (p.get("parent") or "") == "Listening"},
           "artists": {p["name"]: p["count"] for p in pls
                       if (p.get("parent") or "") == "Artists"},
           # cumulative plays per artist, so a week-over-week recap can be built
           # from history alone - snapshots get pruned, history never does
           # Every artist with at least one play, not a top-N slice. Truncating
           # these to "top 60" silently corrupted week-over-week deltas: the two
           # dicts kept different sets, so an artist could be present in one
           # baseline and absent from the other, and a missing baseline reads as
           # zero - which reported a lifetime total as one week's listening.
           "genres": dict(gen),
           "decades": dict(dec)}
    with open(os.path.join(APP_SUPPORT, "history.jsonl"), "a") as f:
        f.write(json.dumps(rec) + "\n")
    return rec


def back_up_history(keep=14):
    """Rotate a daily copy of history.jsonl.

    With only two snapshots kept, this file is the sole record of how the
    library has moved - every graph reads it and nothing can rebuild it. It is
    tiny (tens of KB), so a fortnight of dated copies is cheap insurance against
    the one file whose loss would be unrecoverable.
    """
    src = os.path.join(APP_SUPPORT, "history.jsonl")
    if not os.path.exists(src): return
    d = os.path.join(APP_SUPPORT, "archive", "history-backups")
    os.makedirs(d, exist_ok=True)
    today = datetime.datetime.now().strftime("%Y%m%d")
    dest = os.path.join(d, f"history-{today}.jsonl")
    if not os.path.exists(dest) or os.path.getsize(dest) != os.path.getsize(src):
        shutil.copy(src, dest + ".partial"); os.replace(dest + ".partial", dest)
    old = sorted(x for x in os.listdir(d) if x.startswith("history-"))
    for x in old[:-keep]:
        os.remove(os.path.join(d, x))

def retain(keep=2):
    """Keep the current library snapshot and one backup.

    Two is what a comparison needs. The trend lives in history.jsonl, which
    carries the per-zone counts for every day and is never pruned, so an older
    snapshot adds nothing a graph can draw from.
    """
    snaps = sorted(x for x in os.listdir(ROOT)
                   if os.path.isdir(os.path.join(ROOT, x)) and not x.endswith(".partial"))
    # Exactly one per day: if a day ever ends up with more than one, keep the
    # newest. The guard in __main__ should prevent it, but this makes the
    # invariant true by construction rather than by hoping.
    newest_of_day = {}
    for x in snaps: newest_of_day[x[:8]] = x
    dupes = [x for x in snaps if newest_of_day[x[:8]] != x]
    doomed = dict.fromkeys([x for x in os.listdir(ROOT) if x.endswith(".partial")] + \
             dupes + snaps[:-keep])
    freed = 0
    for x in doomed:
        d = os.path.join(ROOT, x)
        freed += sum(os.path.getsize(os.path.join(dp, f))
                     for dp, _, fs in os.walk(d) for f in fs)
        shutil.rmtree(d, ignore_errors=True)
    if doomed:
        print(f"retain: removed {len(doomed)} snapshot(s) "
              f"({len(dupes)} same-day duplicate(s)), freed {freed/1048576:.0f} MB")
    return len(doomed)

ZONES = r'''
set AppleScript's text item delimiters to "<@>"
tell application "Music"
  set o to {}
  repeat with p in user playlists
    try
      if (name of (parent of p)) is "Listening" then
        set end of o to (name of p) & "<=>" & ((count of tracks of p) as text)
      end if
    end try
  end repeat
end tell
return o as text
'''

ZONES_FILE = os.path.join(APP_SUPPORT, "zones.json")

def write_zones(counts):
    """The Listening stream: its own file, on its own cadence.

    Kept apart from snapshots on purpose. These six numbers can be re-read in
    half a second on demand, while a full library read is a once-a-day event.
    Holding them inside the snapshot tied the cheap reading to the expensive
    one - which is why a relaunch used to throw away the newer counts.
    """
    rec = {"t": datetime.datetime.now().strftime("%Y%m%d-%H%M%S"), "zones": counts}
    tmp = ZONES_FILE + ".partial"
    with open(tmp, "w") as fh: json.dump(rec, fh)
    os.replace(tmp, ZONES_FILE)
    return rec

def zones_only():
    """Just the six Listening counts, as JSON on stdout.

    A whole snapshot reads 3,500 tracks and takes about four seconds. This asks
    Music for six numbers and nothing else, so the Home page can be brought up
    to date without touching history.jsonl or writing a snapshot - the one-a-day
    rule stays intact.
    """
    out = {}
    for bit in osa(ZONES).strip().split("<@>"):
        if "<=>" not in bit: continue
        name, count = bit.rsplit("<=>", 1)
        try: out[name.strip()] = int(count)
        except ValueError: pass
    if out: write_zones(out)
    print(json.dumps(out))
    return out

def taken_today():
    today = datetime.datetime.now().strftime("%Y%m%d")
    return [x for x in os.listdir(ROOT)
            if x.startswith(today) and os.path.isdir(os.path.join(ROOT, x))
            and not x.endswith(".partial")]

def take():
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    final = os.path.join(ROOT, stamp)
    out = final + ".partial"
    shutil.rmtree(out, ignore_errors=True)
    os.makedirs(out, exist_ok=True)
    raw = osa(TRACKS).rstrip("\n").split("<@>")
    cnt = int(raw[0]); cols = [c.split("<|>") for c in raw[1:]]
    if not all(len(c) == cnt for c in cols):
        shutil.rmtree(out, ignore_errors=True)
        raise RuntimeError(f"column misalignment {[len(c) for c in cols]} vs {cnt} - snapshot discarded")
    tracks = [dict(zip(FIELDS, v)) for v in zip(*cols)]
    json.dump(tracks, open(f"{out}/tracks.json", "w"))
    praw = osa(PLAYLISTS).split("<##>")
    pls = []
    for b in praw[0].split("<@>"):
        if "<=>" not in b: continue
        p = b.split("<=>")
        pls.append({"name": p[0], "parent": p[1], "special": p[2], "smart": p[3] == "true",
                    "count": int(p[4]), "ids": [x for x in p[5].split("<,>") if x]})
    folders = [{"name": b.split("<=>")[0], "parent": b.split("<=>")[1]}
               for b in praw[1].split("<@>") if "<=>" in b]
    json.dump({"playlists": pls, "folders": folders}, open(f"{out}/playlists.json", "w"))
    ex = os.path.join(out, "playlists"); os.makedirs(ex, exist_ok=True)
    by_id = {t["pid"]: t for t in tracks}
    for p in pls:
        if p["special"] and p["special"] != "none": continue
        safe = re.sub(r"[/:]", "-", p["name"])[:80] or "untitled"
        with open(f"{ex}/{safe}.txt", "w") as f:
            f.write(f"{p['name']}   ({'smart' if p['smart'] else 'static'}, {p['count']} tracks, "
                    f"folder: {p['parent'] or '(top)'})\n\n")
            for i in p["ids"]:
                t = by_id.get(i)
                f.write(f"{t['name']}\t{t['artist']}\t{t['album']}\n" if t else f"(gone from library: {i})\n")
    # only now is it complete - move it into place atomically
    shutil.rmtree(final, ignore_errors=True)
    os.rename(out, final)
    rollup(stamp, tracks, pls)
    # a full read refreshes the Listening stream too, so the two never disagree
    write_zones({p["name"]: p["count"] for p in pls
                 if (p.get("parent") or "") == "Listening"})
    back_up_history()
    print(f"snapshot {stamp}: {cnt} tracks | {len(pls)} playlists "
          f"({sum(1 for p in pls if p['smart'])} smart) | {len(folders)} folders")
    return final

def listing():
    if not os.path.isdir(ROOT): print("no snapshots yet"); return
    for s in sorted(os.listdir(ROOT)):
        d = os.path.join(ROOT, s)
        if not os.path.isdir(d) or s.endswith(".partial"): continue
        try:
            pl = json.load(open(f"{d}/playlists.json")); tr = json.load(open(f"{d}/tracks.json"))
            print(f"   {s}   {len(tr):>5} tracks   {len(pl['playlists']):>3} playlists   {len(pl['folders'])} folders")
        except Exception:
            print(f"   {s}   (incomplete)")

if __name__ == "__main__":
    if "--zones" in sys.argv: zones_only()
    elif "--retain" in sys.argv:
        i = sys.argv.index("--retain")
        retain(int(sys.argv[i + 1]) if len(sys.argv) > i + 1 and sys.argv[i + 1].isdigit() else 2)
    elif "--list" in sys.argv: listing()
    elif "--prune" in sys.argv:
        keep = int(sys.argv[sys.argv.index("--prune") + 1])
        snaps = sorted(x for x in os.listdir(ROOT)
                       if os.path.isdir(os.path.join(ROOT, x)) and not x.endswith(".partial"))
        for s in [x for x in os.listdir(ROOT) if x.endswith(".partial")] + snaps[:-keep]:
            shutil.rmtree(os.path.join(ROOT, s), ignore_errors=True); print(f"removed {s}")
    else:
        # One snapshot a day. Opening the app again the same day rebuilds the
        # view from the morning's capture rather than taking another; Cmd-R
        # passes --force when you want a fresh read.
        if "--force" not in sys.argv and taken_today():
            print(f"snapshot already taken today ({taken_today()[0]}) - skipping")
            retain(2)
            sys.exit(0)
        take()
        retain(2)
