#!/usr/bin/env python3
"""Build a local HTML dashboard from the newest snapshot (or a named one).

    python3 dashboard.py              use newest snapshot
    python3 dashboard.py 20260828-151339
    python3 dashboard.py --open       build and open it

Writes dashboard.html into Application Support. Self-contained: no network, no
dependencies. Re-run after any snapshot to refresh.

Layout: the page is locked to the viewport and never scrolls. Type size is
solved at runtime - the largest root font size at which no panel overflows -
so the same page reads well on a laptop and on a large display.
"""
import collections, datetime, json, os, re, subprocess, sys, html

# Listening zones have been renamed twice already. Canonical name first, then
# every historical spelling, so snapshots taken under an old name keep
# resolving into the same series instead of breaking the history chart.
ZONE_ALIASES = [
    ("Unplayed",   ["Unplayed", "Inbox"]),
    ("Rotation",   ["Rotation"]),
    ("Dormant",    ["Dormant", "Archived", "Second Chance"]),
    ("Familiar",   ["Familiar", "Familar"]),
    ("Repertoire", ["Repertoire", "Canon"]),
    ("Not For Me", ["Not For Me", "Dislike", "Disliked"]),
]

def zone_key(name):
    """Drop a leading order prefix ('1 Unplayed') so numbered playlists match."""
    return re.sub(r"^\s*\d+\s*[.\-)]?\s*", "", name or "").strip()

APP_SUPPORT = os.path.expanduser("~/Library/Application Support/Needle")
SNAPS = os.path.join(APP_SUPPORT, "snapshots")

def newest():
    xs = sorted(d for d in os.listdir(SNAPS) if os.path.isdir(os.path.join(SNAPS, d)))
    if not xs: sys.exit("no snapshots found - run snapshot.py first")
    return xs[-1]

def build(stamp):
    d = os.path.join(SNAPS, stamp)
    tracks = json.load(open(f"{d}/tracks.json"))
    pl = json.load(open(f"{d}/playlists.json"))
    for t in tracks:
        t["plays"] = int(t["plays"] or 0); t["rating"] = int(t["rating"] or 0)
    today = datetime.date.today()
    def age(s):
        try: return (today - datetime.date.fromisoformat(s)).days
        except Exception: return None

    n = len(tracks)
    plays = sum(t["plays"] for t in tracks)
    byname = {p["name"]: p for p in pl["playlists"]}

    # every playlist gets a home: parentless ones land under "Library"
    folders = collections.defaultdict(list)
    for p in pl["playlists"]:
        folders[p["parent"] or "Library"].append(p)

    bykey = {zone_key(p["name"]): p for p in pl["playlists"]}
    zones = []
    for canon, names in ZONE_ALIASES:
        for nm in names:
            if nm in bykey:
                zones.append((canon, bykey[nm]["count"])); break

    depth = collections.Counter(t["plays"] for t in tracks)
    depth_rows = [(str(k) if k < 13 else "13+", sum(v for kk, v in depth.items() if kk >= 13) if k == 13 else depth[k])
                  for k in list(range(0, 13)) + [13]]

    dec = collections.Counter(int(t["year"]) // 10 * 10 for t in tracks
                              if str(t["year"]).strip().isdigit() and int(t["year"]) > 1900)
    gen = collections.Counter((t["genre"] or "").strip() or "(none)" for t in tracks)
    ap, an = collections.Counter(), collections.Counter()
    for t in tracks:
        k = (t.get("albumartist") or "").strip() or (t["artist"] or "").strip() or "(unknown)"
        ap[k] += t["plays"]; an[k] += 1
    added = collections.Counter((t.get("added") or "")[:7] for t in tracks if t.get("added"))
    hist = []
    hp = os.path.join(os.path.dirname(SNAPS), "history.jsonl")
    if os.path.exists(hp):
        for line in open(hp):
            line = line.strip()
            if line:
                try: hist.append(json.loads(line))
                except Exception: pass
    lastplayed = [age(t.get("played")) for t in tracks if age(t.get("played")) is not None]

    # folders in a stable, meaningful order; biggest content first, Library last
    order = sorted(folders.keys(), key=lambda f: (f == "Library", -len(folders[f]), f))
    # Per-playlist make-up. Snapshots carry each playlist's member ids, so the
    # same artist/genre/decade breakdown the whole library gets can be computed
    # for any one playlist.
    by_pid = {t["pid"]: t for t in tracks}
    def breakdown(ids):
        who, gee, dee = collections.Counter(), collections.Counter(), collections.Counter()
        for i in ids:
            t = by_pid.get(i)
            if not t: continue
            who[(t.get("albumartist") or "").strip() or (t.get("artist") or "").strip() or "(unknown)"] += 1
            gee[(t.get("genre") or "").strip() or "(none)"] += 1
            y = str(t.get("year") or "").strip()
            if y.isdigit() and int(y) > 1900: dee[f"{int(y)//10*10}s"] += 1
        # No cap. "All artists" has to mean all of them, and a top-20 slice made
        # the Whole library view quietly wrong about what is in it.
        top = lambda c: [{"name": k, "count": v} for k, v in c.most_common()]
        return {"artists": top(who), "genres": top(gee),
                "decades": [{"name": k, "count": dee[k]} for k in sorted(dee)]}
    comps = [{"name": "Whole library", "count": n, "folder": "",
              **breakdown([t["pid"] for t in tracks])}]
    for q in sorted(pl["playlists"], key=lambda x: -x["count"]):
        ids = q.get("ids") or []
        if not ids or (q.get("special") or "none") not in ("none", ""): continue
        comps.append({"name": q["name"], "count": q["count"],
                      # parentless playlists group under Library; only the
                      # whole-library entry keeps an empty folder
                      "folder": q.get("parent") or "Library", **breakdown(ids)})

    art = {p["name"]: p["count"] for p in pl["playlists"]
           if (p.get("parent") or "") == "Artists"}
    art_desc = sorted(art.items(), key=lambda x: -x[1])
    # every artist in the library by track count, not just the handful with a
    # playlist - the Library page asks what the music is made of
    artists_all = sorted(an.items(), key=lambda x: (-x[1], x[0]))
    genres_all = gen.most_common()

    data = {
      "stamp": stamp, "generated": datetime.datetime.now().strftime("%d %b %Y, %H:%M"),
      "totals": {
        "tracks": n, "plays": plays, "perTrack": round(plays / n, 2),
        "everPlayed": sum(1 for t in tracks if t["plays"] > 0),
        "never": sum(1 for t in tracks if t["plays"] == 0),
        "rated": sum(1 for t in tracks if t["rating"] > 0),
        "playlists": len(pl["playlists"]), "folders": len(pl["folders"]),
        "played7": sum(1 for a in lastplayed if a <= 7),
        "played30": sum(1 for a in lastplayed if a <= 30),
      },
      "zones": zones,
      "zoneOrder": [c for c, _ in ZONE_ALIASES],
      "zoneAliases": {c: n for c, n in ZONE_ALIASES},
      "depth": depth_rows,
      "decades": [(f"{k}s", dec[k]) for k in sorted(dec)],
      "genres": gen.most_common(10),
      "artistsByPlays": [(a, ap[a], an[a]) for a, _ in ap.most_common(15)],
      "added": sorted(added.items())[-10:],
      "history": hist,
      "folderOrder": order,
      "folders": {f: sorted([(p["name"], p["count"], p["smart"]) for p in folders[f]],
                            key=lambda x: -x[1]) for f in order},
      "compositions": comps,
      "artistsNow": art_desc,
      "artistsAllNow": artists_all,
      "genresAllNow": genres_all,
      "topArtists": [k for k, _ in art_desc[:10]],
      "genresNow": gen.most_common(12),
      "decadesNow": [(f"{k}s", dec[k]) for k in sorted(dec)],
      "topGenres": [g for g, _ in gen.most_common(8)],
      # snapshot.py records decades keyed "2010s"; match that exactly or every
      # decade series resolves to zero. Eight most populous, in chronological
      # order, so the colour ramp does not have to repeat itself.
      "topDecades": [f"{k}s" for k in sorted(k for k, _ in dec.most_common(8))],
    }
    return data

TEMPLATE = r"""<!-- generated by dashboard.py - do not hand-edit -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Needle</title>
<style>
/* ---------------------------------------------------------------------
   Apple system palette. Light is the grouped-background convention:
   a tinted page with white cards floating on it, no borders anywhere -
   separation comes from fill and a one-pixel shadow, never an outline.
   ------------------------------------------------------------------ */
:root{
  --bg:#f2f2f7; --card:#ffffff; --card-2:#f7f7fa; --fill:#78788020; --fill-2:#7878801f;
  --ink:#000000; --ink-2:#3c3c4399; --ink-3:#3c3c434d;
  --sep:#3c3c4326; --sidebar:#ececf0; --sel:#00000010;
  --blue:#007aff; --green:#34c759; --indigo:#5856d6; --orange:#ff9500;
  --pink:#ff2d55; --purple:#af52de; --teal:#30b0c7; --red:#ff3b30;
  --accent:#e0342f;
  --shadow:0 .5px 1.5px #0000001f, 0 0 0 .5px #0000000a;
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --bg:#1c1c1e; --card:#2c2c2e; --card-2:#333336; --fill:#7878805c; --fill-2:#78788040;
  --ink:#ffffff; --ink-2:#ebebf599; --ink-3:#ebebf54d;
  --sep:#54545899; --sidebar:#232325; --sel:#ffffff14;
  --blue:#0a84ff; --green:#30d158; --indigo:#5e5ce6; --orange:#ff9f0a;
  --pink:#ff375f; --purple:#bf5af2; --teal:#40c8e0; --red:#ff453a;
  --accent:#ff453a;
  --shadow:none;
}}
:root[data-theme="dark"]{
  --bg:#1c1c1e; --card:#2c2c2e; --card-2:#333336; --fill:#7878805c; --fill-2:#78788040;
  --ink:#ffffff; --ink-2:#ebebf599; --ink-3:#ebebf54d;
  --sep:#54545899; --sidebar:#232325; --sel:#ffffff14;
  --blue:#0a84ff; --green:#30d158; --indigo:#5e5ce6; --orange:#ff9f0a;
  --pink:#ff375f; --purple:#bf5af2; --teal:#40c8e0; --red:#ff453a;
  --accent:#ff453a;
  --shadow:none;
}
*{box-sizing:border-box}
html{font-size:17px}
html,body{height:100%;overflow:hidden}
body{margin:0;background:var(--bg);color:var(--ink);
 font:1rem/1.47 -apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif;
 -webkit-font-smoothing:antialiased;letter-spacing:-.01em}

/* ---- shell: fixed source list, content is the only thing that moves ---- */
.app{display:grid;grid-template-columns:auto minmax(0,1fr);height:100dvh}
.sidebar{width:13.5rem;background:var(--sidebar);display:flex;flex-direction:column;
 padding:.9rem .65rem .7rem;gap:.15rem;min-height:0}
.brand{display:flex;align-items:center;gap:.5rem;padding:.15rem .5rem 1rem}
.mark{width:1.7rem;height:1.7rem;border-radius:.42rem;flex:none;display:block}
.brand b{font-size:.98rem;font-weight:600;letter-spacing:-.02em}
.navsec{font-size:.68rem;font-weight:600;color:var(--ink-3);text-transform:uppercase;
 letter-spacing:.05em;padding:.85rem .6rem .3rem}
.navrow{display:flex;align-items:center;gap:.55rem;padding:.32rem .6rem;border-radius:.42rem;
 font-size:.87rem;color:var(--ink);cursor:pointer;user-select:none;border:0;background:none;
 font-family:inherit;width:100%;text-align:left;letter-spacing:-.01em}
.navrow:hover{background:var(--sel)}
.navrow[aria-current="page"]{background:var(--fill-2);font-weight:590}
.navrow svg{width:1.02rem;height:1.02rem;flex:none;color:var(--ink-2)}
.navrow[aria-current="page"] svg{color:var(--accent)}
.navrow .n{margin-left:auto;font-size:.78rem;color:var(--ink-3);
 font-variant-numeric:tabular-nums}
.sidefoot{margin-top:auto;padding:.7rem .6rem 0;font-size:.7rem;color:var(--ink-3);
 line-height:1.35}

.content{min-width:0;min-height:0;overflow-y:auto;overflow-x:hidden;
 padding:1.5rem 1.7rem 1.5rem;display:flex;flex-direction:column;gap:1rem}
.pagehead{flex:none;display:flex;align-items:flex-end;justify-content:space-between;
 gap:1rem;flex-wrap:wrap}
h1{margin:0;font-size:1.72rem;font-weight:700;letter-spacing:-.025em;line-height:1.1}
.pagesub{color:var(--ink-2);font-size:.85rem;margin-top:.2rem;font-variant-numeric:tabular-nums}
.toolbar{display:flex;align-items:center;gap:.6rem;flex-wrap:wrap}

/* ---- cards: fill and shadow, never an outline ---- */
.card{background:var(--card);border-radius:.78rem;box-shadow:var(--shadow);
 padding:1rem 1.15rem;min-width:0;min-height:0;display:flex;flex-direction:column;
 overflow:hidden}
.card h2{margin:0 0 .1rem;font-size:.95rem;font-weight:600;letter-spacing:-.015em;
 color:var(--ink)}
.card .cap{font-size:.76rem;color:var(--ink-2);margin-bottom:.75rem}
.card .body{flex:1;min-height:0;min-width:0;display:flex;flex-direction:column;overflow:hidden}
.grid{display:grid;gap:1rem;min-height:0}
.rowhead{display:flex;align-items:baseline;justify-content:space-between;gap:1rem;
 flex:none;margin-bottom:.7rem}
.rowhead h2{margin:0}

/* ---- stat tiles ---- */
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(9rem,1fr));gap:1rem;flex:none}
.stat{background:var(--card);border-radius:.78rem;box-shadow:var(--shadow);padding:.8rem .95rem}
.stat .k{font-size:.75rem;color:var(--ink-2);font-weight:500;white-space:nowrap;
 overflow:hidden;text-overflow:ellipsis}
.stat .v{font-size:1.72rem;font-weight:600;letter-spacing:-.03em;line-height:1.15;
 font-variant-numeric:tabular-nums;margin-top:.1rem}
.stat .n{font-size:.74rem;color:var(--ink-3);white-space:nowrap;overflow:hidden;
 text-overflow:ellipsis}

/* ---- segmented control, the real one ---- */
.seg{display:inline-flex;background:var(--fill-2);border-radius:.5rem;padding:.12rem;gap:.1rem}
.seg button{appearance:none;border:0;background:none;color:var(--ink);font:inherit;
 font-size:.82rem;font-weight:500;padding:.24em .85em;border-radius:.4rem;cursor:pointer;
 white-space:nowrap;letter-spacing:-.01em}
.seg button[aria-pressed="true"]{background:var(--card);font-weight:590;box-shadow:var(--shadow)}
.hint{font-size:.78rem;color:var(--ink-2);font-variant-numeric:tabular-nums}

/* ---- grouped list, Settings style: hairlines inset, no outer border ---- */
.list{display:flex;flex-direction:column;flex:1;min-height:0;overflow-y:auto}
.list .r{display:grid;grid-template-columns:1.35rem minmax(0,1.35fr) minmax(0,2fr) auto;
 align-items:center;gap:.75rem;padding:.42rem 0;position:relative;min-width:0}
.list .r+.r::before{content:"";position:absolute;left:2.1rem;right:0;top:0;height:1px;
 background:var(--sep);transform:scaleY(.5)}
.list .swatch{width:.62rem;height:.62rem;border-radius:.2rem;justify-self:center}
.list .rank{font-size:.78rem;color:var(--ink-3);text-align:center;
 font-variant-numeric:tabular-nums}
.list .nm{font-size:.87rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.list .meter{height:.4rem;background:var(--fill-2);border-radius:.2rem;overflow:hidden}
.list .meter i{display:block;height:100%;border-radius:.2rem;background:var(--blue)}
.list .val{font-size:.85rem;font-weight:590;font-variant-numeric:tabular-nums;text-align:right;
 min-width:3.2em}
.list .pct{font-size:.76rem;color:var(--ink-3);font-variant-numeric:tabular-nums;
 min-width:2.8em;text-align:right}

/* ---- stacked composition bar ---- */
.stack{display:flex;height:2.1rem;border-radius:.42rem;overflow:hidden;gap:1.5px;flex:none}
.stack i{display:block;min-width:2px}
.stackkey{display:grid;grid-template-columns:repeat(auto-fit,minmax(8rem,1fr));
 gap:.35rem .9rem;margin-top:.85rem;flex:none}
.stackkey div{display:flex;align-items:center;gap:.45em;font-size:.8rem;color:var(--ink-2);
 min-width:0}
.stackkey i{width:.55em;height:.55em;border-radius:.16em;flex:none}
.stackkey span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.stackkey b{margin-left:auto;color:var(--ink);font-weight:590;font-variant-numeric:tabular-nums}

/* ---- charts ---- */
.chart{position:relative;flex:1;min-height:0;display:flex}
.chart svg{display:block}
.gl{stroke:var(--sep);stroke-width:1}
.al{fill:var(--ink-3)}
.legend{display:flex;flex-wrap:wrap;gap:.3em 1.05em;margin-top:.7em;flex:none}
.legend span{display:inline-flex;align-items:center;gap:.4em;font-size:.79rem;color:var(--ink-2);
 white-space:nowrap}
.legend i{width:.62em;height:.62em;border-radius:.16em;flex:none}
.tip{position:absolute;pointer-events:none;background:var(--card);border-radius:.5rem;
 padding:.5em .7em;font-size:.8rem;color:var(--ink);box-shadow:0 6px 20px #00000026,0 0 0 .5px #0000001a;
 white-space:nowrap;opacity:0;transition:opacity .12s;z-index:5}
.tip .tt{font-weight:600;margin-bottom:.35em;display:flex;align-items:center;gap:.5em}
.tip .tr{display:flex;align-items:center;gap:.45em;font-size:.78rem;color:var(--ink-2);
 line-height:1.5;white-space:nowrap}
.tip .tr i{width:.55em;height:.55em;border-radius:.16em;flex:none}
.tip .tr b{margin-left:auto;padding-left:.9em;font-variant-numeric:tabular-nums;color:var(--ink)}
.kind{font-size:.68em;font-weight:600;letter-spacing:.03em;text-transform:uppercase;
 padding:.1em .45em;border-radius:.25em;background:var(--fill-2);color:var(--ink-2)}

.dbars{display:flex;flex-direction:column;flex:1;min-height:0;justify-content:space-around;gap:.2rem}
.dbrow{display:grid;grid-template-columns:minmax(4rem,9rem) 1fr minmax(2.6rem,auto);
 align-items:center;gap:.85em;min-height:0}
.dblab{font-size:.84rem;color:var(--ink-2);text-align:right;overflow:hidden;
 text-overflow:ellipsis;white-space:nowrap}
.dbtrack{position:relative;height:1.35em;background:var(--fill-2);border-radius:.3rem}
.dbzero{position:absolute;left:50%;top:-.2em;bottom:-.2em;width:1px;background:var(--ink-3)}
.dbfill{position:absolute;top:0;bottom:0;border-radius:.3rem;min-width:2px}
.dbfill.pos{background:var(--green)}
.dbfill.neg{background:var(--red)}
.dbval{font-size:.83rem;font-weight:590;font-variant-numeric:tabular-nums;text-align:right;
 color:var(--ink-3)}
.dbval.up{color:var(--green)}
.dbval.down{color:var(--red)}

.pie{flex:1;min-height:0;display:flex;align-items:center;gap:1.5rem}
.pie svg{flex:none;display:block}
.pielegend{flex:1;min-width:0;display:grid;gap:.45rem 1.4rem;align-content:center;
 grid-template-columns:repeat(auto-fit,minmax(13rem,1fr))}
.pielegend div{display:flex;align-items:center;gap:.5em;font-size:.83rem;color:var(--ink-2);
 min-width:0}
.pielegend i{width:.6em;height:.6em;border-radius:.16em;flex:none}
.pielegend span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pielegend b{margin-left:auto;font-weight:590;color:var(--ink);font-variant-numeric:tabular-nums}
.pielegend em{font-style:normal;color:var(--ink-3);font-variant-numeric:tabular-nums;
 min-width:2.6em;text-align:right}

/* ---- playlists page ---- */
.plgrid{display:grid;gap:1rem;align-content:start;
 grid-template-columns:repeat(auto-fit,minmax(min(38rem,100%),1fr))}
.plgroup{background:var(--card);border-radius:.78rem;box-shadow:var(--shadow);padding:.85rem 1rem;min-width:0}
.fh{display:flex;justify-content:space-between;align-items:baseline;gap:.5em;
 margin-bottom:.5rem}
.fh b{font-size:.9rem;font-weight:600;letter-spacing:-.015em}
.fh em{font-style:normal;font-size:.76rem;color:var(--ink-3);font-variant-numeric:tabular-nums}
.tag{font-size:.66rem;font-weight:600;letter-spacing:.02em;padding:.06em .4em;border-radius:.28em;
 background:var(--fill-2);color:var(--ink-3);margin-left:.45em;vertical-align:.08em}
.plgroup ul{margin:0;padding:0;list-style:none}
.plgroup li{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.5fr) auto;
 align-items:center;gap:.9em;font-size:.85rem;color:var(--ink-2);padding:.34rem 0;position:relative}
.plgroup li .m{height:.34rem;background:var(--fill-2);border-radius:.17rem;overflow:hidden}
.plgroup li .m i{display:block;height:100%;background:var(--blue);border-radius:.17rem}
.plgroup li+li::before{content:"";position:absolute;left:0;right:0;top:0;height:1px;
 background:var(--sep);transform:scaleY(.5)}
.plgroup li span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.plgroup li b{font-weight:500;color:var(--ink);font-variant-numeric:tabular-nums;flex:none}

.deltas{display:grid;grid-template-columns:repeat(auto-fit,minmax(8rem,1fr));gap:1rem}
.delta{background:var(--card);border-radius:.78rem;box-shadow:var(--shadow);padding:.8rem .95rem}
.delta b{display:block;font-size:1.5rem;font-weight:600;letter-spacing:-.03em;
 font-variant-numeric:tabular-nums;line-height:1.15}
.delta span{font-size:.76rem;color:var(--ink-2)}
.delta b.up{color:var(--green)}
.delta b.down{color:var(--red)}
.note{color:var(--ink-2);font-size:.8rem;margin:.6em 0 0;line-height:1.4;flex:none}
.empty{display:flex;align-items:center;justify-content:center;flex:1;color:var(--ink-3);
 font-size:.85rem;text-align:center;padding:1rem}
:focus-visible{outline:2.5px solid var(--blue);outline-offset:2px;border-radius:.3rem}
</style>

<div class="app">
<aside class="sidebar">
  <div class="brand"><svg class="mark" viewBox="0 0 1024 1024" aria-hidden="true"><rect width="1024" height="1024" rx="224" fill="#17171b"/><circle cx="470" cy="554" r="372" fill="#d8d5c8" opacity=".10"/><circle cx="470" cy="554" r="318" fill="none" stroke="#d8d5c8" stroke-opacity=".34" stroke-width="26"/><circle cx="470" cy="554" r="240" fill="none" stroke="#d8d5c8" stroke-opacity=".52" stroke-width="30"/><circle cx="470" cy="554" r="162" fill="none" stroke="#d8d5c8" stroke-opacity=".74" stroke-width="34"/><circle cx="470" cy="554" r="74" fill="#d8d5c8" fill-opacity=".92"/><circle cx="470" cy="554" r="20" fill="#17171b"/><line x1="880" y1="144" x2="671" y2="345" stroke="#17171b" stroke-width="74" stroke-linecap="round"/><line x1="880" y1="144" x2="671" y2="345" stroke="#e0342f" stroke-width="30" stroke-linecap="round"/><circle cx="671" cy="345" r="58" fill="#17171b"/><circle cx="671" cy="345" r="44" fill="#e0342f"/><circle cx="671" cy="345" r="15" fill="#17171b"/><circle cx="880" cy="144" r="52" fill="#17171b"/><circle cx="880" cy="144" r="38" fill="#d8d5c8" fill-opacity=".72"/></svg><b>Needle</b></div>
  <nav id="nav"></nav>
  <div class="sidefoot" id="sidefoot"></div>
</aside>
<main class="content" id="content">
  <div class="pagehead">
    <div><h1 id="pageTitle"></h1><div class="pagesub" id="pageSub"></div></div>
    <div class="toolbar" id="toolbar"></div>
  </div>
  <div id="pageBody" style="display:contents"></div>
</main>
</div>
<script id="payload" type="application/json">__DATA__</script>
<script>
const D = JSON.parse(document.getElementById('payload').textContent);
const f = n => n.toLocaleString();
const SER=['var(--blue)','var(--orange)','var(--green)','var(--purple)','var(--pink)',
           'var(--teal)','var(--indigo)','var(--red)'];
const el = (h)=>{const d=document.createElement('div'); d.innerHTML=h; return d;};

// ---- zones, resolved through every name they have ever had --------------
const ZONE_ORDER = D.zoneOrder, ZONE_ALIASES = D.zoneAliases;
const zkey = n => (n||'').replace(/^\s*\d+\s*[.\-)]?\s*/,'').trim();
function zoneVal(r,k){
  if(k==='Total') return r.tracks;
  const z=r.zones||{}, norm={};
  for(const nm in z) norm[zkey(nm)]=z[nm];
  for(const nm of (ZONE_ALIASES[k]||[k])) if(norm[nm]!=null) return norm[nm];
  return 0;
}
// One reading per day: the scheduled run, else that day's earliest.
function markAnchors(H2){
  const byDay=new Map();
  H2.forEach(r=>{const d=r.t.slice(0,8); (byDay.get(d)||byDay.set(d,[]).get(d)).push(r);});
  const a=new Set();
  byDay.forEach(rs=>{const s=rs.find(r=>r.src==='scheduled'); a.add((s||rs[0]).t);});
  return H2.map(r=>({...r, anchor:a.has(r.t)}));
}
const H = markAnchors(D.history||[]);
const daily = H2 => H2.filter(r=>r.anchor);
const RANGE_DAYS={day:1,week:7,month:31,year:365,all:null};
const parseStamp = t => new Date(+t.slice(0,4),+t.slice(4,6)-1,+t.slice(6,8),
                                 +t.slice(9,11),+t.slice(11,13),+t.slice(13,15));
function inRange(H2,range){
  const d=RANGE_DAYS[range];
  if(!d||!H2.length) return H2;
  const cut=parseStamp(H2[H2.length-1].t).getTime()-d*864e5;
  const kept=H2.filter(r=>parseStamp(r.t).getTime()>=cut);
  return kept.length?kept:H2.slice(-1);
}
function labelFor(H2){
  const days=new Set(H2.map(r=>r.t.slice(0,8))).size;
  const span=H2.length>1?(parseStamp(H2[H2.length-1].t)-parseStamp(H2[0].t))/864e5:0;
  return H2.map(r=>{const t=r.t;
    if(days<=1)  return `${t.slice(9,11)}:${t.slice(11,13)}`;
    if(span<=90) return `${t.slice(6,8)}/${t.slice(4,6)}`;
    return `${t.slice(6,8)}/${t.slice(4,6)}/${t.slice(2,4)}`;});
}
const SCOPES={
  listening:{keys:()=>ZONE_ORDER, val:zoneVal, has:r=>!!r.zones, now:()=>D.zones, extra:'Total'},
  artists:  {keys:()=>D.topArtists||[], val:(r,k)=>(r.artists||{})[k]??0, has:r=>!!r.artists,
             now:()=>D.artistsNow||[]},
  genres:   {keys:()=>D.topGenres||[], val:(r,k)=>(r.genres||{})[k]??0, has:r=>!!r.genres,
             now:()=>D.genresNow||[]},
  decades:  {keys:()=>D.topDecades||[], val:(r,k)=>(r.decades||{})[k]??0, has:r=>!!r.decades,
             now:()=>D.decadesNow||[]},
};

// ---- line chart, drawn to its measured pixel box (no distortion) --------
function multiLine(host, labels, series, opts){
  opts=opts||{};
  const n=labels.length;
  if(!n||!series.length){ host.innerHTML='<div class="empty">No history for this view yet.</div>'; return; }
  host.innerHTML='<div class="chart"><div class="tip"></div></div>'+
    `<div class="legend">${series.map(s=>`<span><i style="background:${s.color}"></i>${s.name}</span>`).join('')}</div>`;
  const box=host.querySelector('.chart');
  const W=Math.max(Math.round(box.clientWidth),320), Hh=Math.max(Math.round(box.clientHeight),120);
  const fs=parseFloat(getComputedStyle(document.documentElement).fontSize)||16;
  const ax=Math.round(fs*0.76);
  const all=series.flatMap(s=>s.vals), max=Math.max(...all,1);
  const PL=Math.round(ax*3.6), PR=Math.round(ax*1.4), PT=Math.round(ax*1.1), PB=Math.round(ax*2.2);
  const x=i=> PL + (n===1?(W-PL-PR)/2 : i*(W-PL-PR)/(n-1));
  const y=v=> PT + (Hh-PT-PB)*(1 - v/max);
  const ticks=[...new Set([0,Math.round(max/2),max])];
  const step=Math.max(1,Math.ceil(n/Math.max(3,Math.floor((W-PL-PR)/(ax*6)))));
  const svg=`<svg viewBox="0 0 ${W} ${Hh}" width="${W}" height="${Hh}" style="font-size:${ax}px" role="img" aria-label="${opts.label||'trend'}">
    ${ticks.map(t=>`<line class="gl" x1="${PL}" x2="${W-PR}" y1="${y(t)}" y2="${y(t)}"/>
      <text class="al" x="${PL-ax*0.6}" y="${y(t)+ax*0.36}" text-anchor="end">${t.toLocaleString()}</text>`).join('')}
    ${series.map(s=>{
      const d=s.vals.map((v,i)=>`${i?'L':'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
      return `<path d="${d}" fill="none" stroke="${s.color}" stroke-width="${(ax*0.17).toFixed(2)}"
                stroke-linejoin="round" stroke-linecap="round"/>` +
        (n<=60 ? s.vals.map((v,i)=>`<circle cx="${x(i).toFixed(1)}" cy="${y(v).toFixed(1)}"
             r="${(ax*0.24).toFixed(2)}" fill="${s.color}" stroke="var(--card)" stroke-width="${(ax*0.1).toFixed(2)}"/>`).join('') : '');
    }).join('')}
    ${labels.map((l,i)=> i%step===0 ? `<text class="al" x="${x(i).toFixed(1)}" y="${Hh-ax*0.7}"
        text-anchor="${i===0?'start':i===n-1?'end':'middle'}">${l}</text>`:'').join('')}
    ${labels.map((l,i)=>`<rect x="${(x(i)-(W-PL-PR)/Math.max(n-1,1)/2).toFixed(1)}" y="${PT}"
        width="${((W-PL-PR)/Math.max(n-1,1)).toFixed(1)}" height="${Hh-PT-PB}" fill="transparent" data-i="${i}"/>`).join('')}
   </svg>`;
  box.insertAdjacentHTML('afterbegin', svg);
  const tip=host.querySelector('.tip');
  box.querySelectorAll('rect[data-i]').forEach(r=>{
    r.addEventListener('mouseenter',()=>{
      const i=+r.dataset.i, kind=opts.kinds?opts.kinds[i]:null;
      tip.innerHTML=`<div class="tt">${labels[i]}${kind?`<span class="kind">${kind==='scheduled'?'daily':'manual'}</span>`:''}</div>`+
        series.map(s=>`<span class="tr"><i style="background:${s.color}"></i>${s.name}<b>${f(s.vals[i])}</b></span>`).join('');
      const bb=r.getBoundingClientRect(), pb=box.getBoundingClientRect(), tw=tip.offsetWidth||180;
      tip.style.left=Math.min(Math.max(bb.left-pb.left+bb.width/2-tw/2,4),Math.max(pb.width-tw-4,4))+'px';
      tip.style.top='6px'; tip.style.opacity=1;
    });
    r.addEventListener('mouseleave',()=>tip.style.opacity=0);
  });
}
const seriesFrom=(H2,keys,pick)=>keys.map((k,i)=>({name:k,color:SER[i%SER.length],vals:H2.map(r=>pick(r,k))}));

function drawChange(host, rows){
  if(!rows.length){ host.innerHTML='<div class="empty">Not enough history in this range yet.</div>'; return; }
  const max=Math.max(1,...rows.map(r=>Math.abs(r[1])));
  host.innerHTML=`<div class="dbars">${rows.map(([k,v])=>{
    const w=Math.abs(v)/max*50, side=v<0?`right:50%;width:${w}%`:`left:50%;width:${w}%`;
    return `<div class="dbrow"><span class="dblab">${k}</span>
      <span class="dbtrack"><span class="dbzero"></span>${v?`<span class="dbfill ${v<0?'neg':'pos'}" style="${side}"></span>`:''}</span>
      <span class="dbval ${v>0?'up':v<0?'down':''}">${v>0?'+':''}${v.toLocaleString()}</span></div>`;
  }).join('')}</div>`;
}

function drawShare(host, rows){
  rows=rows.filter(r=>r[1]>0);
  if(!rows.length){ host.innerHTML='<div class="empty">Nothing to show yet.</div>'; return; }
  rows=rows.slice().sort((a,b)=>b[1]-a[1]);   // largest first, or "Other"
  if(rows.length>9){ const head=rows.slice(0,8), rest=rows.slice(8).reduce((a,b)=>a+b[1],0);
                     rows=head.concat([['Other',rest]]); }   // swallows the biggest slices
  const total=rows.reduce((a,b)=>a+b[1],0)||1;
  host.innerHTML='<div class="pie"><div class="ring"></div><div class="pielegend"></div></div>';
  const box=host.querySelector('.pie');
  const S=Math.max(110,Math.min(box.clientHeight*0.96, box.clientWidth*0.38));
  const R=S/2, cx=R, cy=R, hole=R*0.58;
  let a0=-Math.PI/2, arcs='';
  rows.forEach((row,i)=>{
    const a1=a0+row[1]/total*Math.PI*2, big=(a1-a0)>Math.PI?1:0;
    const x0=cx+R*Math.cos(a0), y0=cy+R*Math.sin(a0), x1=cx+R*Math.cos(a1), y1=cy+R*Math.sin(a1);
    arcs += rows.length===1
      ? `<circle cx="${cx}" cy="${cy}" r="${R}" fill="${SER[i%SER.length]}"/>`
      : `<path d="M${cx},${cy} L${x0.toFixed(2)},${y0.toFixed(2)} A${R},${R} 0 ${big} 1 ${x1.toFixed(2)},${y1.toFixed(2)} Z" fill="${SER[i%SER.length]}"><title>${row[0]}: ${f(row[1])}</title></path>`;
    a0=a1;
  });
  host.querySelector('.ring').outerHTML=
    `<svg width="${S}" height="${S}" viewBox="0 0 ${S} ${S}" role="img" aria-label="share">${arcs}
       <circle cx="${cx}" cy="${cy}" r="${hole}" fill="var(--card)"/></svg>`;
  host.querySelector('.pielegend').innerHTML=rows.map((row,i)=>
    `<div><i style="background:${SER[i%SER.length]}"></i><span>${row[0]}</span><b>${f(row[1])}</b>`+
    `<em>${(row[1]/total*100).toFixed(0)}%</em></div>`).join('');
}

// ranked list with meters - the workhorse of every detail page
function rankedList(rows, colored, total){
  const max=Math.max(1,...rows.map(r=>r[1]));
  total = total || rows.reduce((a,b)=>a+b[1],0) || 1;
  return `<div class="list">${rows.map(([k,v],i)=>`<div class="r">
    ${colored?`<span class="swatch" style="background:${SER[i%SER.length]}"></span>`
             :`<span class="rank">${i+1}</span>`}
    <span class="nm">${k}</span>
    <span class="meter"><i style="width:${v/max*100}%;background:${colored?SER[i%SER.length]:'var(--blue)'}"></i></span>
    <span class="val">${f(v)}<span class="pct"> ${(v/total*100).toFixed(0)}%</span></span>
  </div>`).join('')}</div>`;
}
function stacked(rows){
  const total=rows.reduce((a,b)=>a+b[1],0)||1;
  return `<div class="stack">${rows.map((r,i)=>r[1]?
      `<i style="flex:${r[1]};background:${SER[i%SER.length]}" title="${r[0]}: ${f(r[1])}"></i>`:'').join('')}</div>
    <div class="stackkey">${rows.map((r,i)=>
      `<div><i style="background:${SER[i%SER.length]}"></i><span>${r[0]}</span><b>${f(r[1])}</b></div>`).join('')}</div>`;
}

// ---- navigation --------------------------------------------------------
const I={
 overview:'<path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z"/>',
 listening:'<path d="M3 12h3l3-7 3 14 3-9 2 2h4"/>',
 artists:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
 genres:'<path d="M3 5h11l7 7-9 9-9-9z"/><circle cx="8.5" cy="9.5" r="1.6"/>',
 decades:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
 playlists:'<path d="M4 6h16M4 12h16M4 18h10"/>',
 history:'<path d="M3 17l5-6 4 4 8-9"/><path d="M21 6v5h-5"/>',
};
const NAV=[
 ['Library',    [['overview','Overview'],['listening','Listening']]],
 ['Collection', [['artists','Artists'],['genres','Genres'],['decades','Decades']]],
 ['Detail',     [['playlists','Playlists'],['history','History']]],
];
const COUNTS={listening:()=>D.zones.length, artists:()=>(D.artistsNow||[]).length,
  genres:()=>(D.genresNow||[]).length, decades:()=>(D.decadesNow||[]).length,
  playlists:()=>D.totals.playlists, history:()=>H.length};
document.getElementById('nav').innerHTML = NAV.map(([sec,rows])=>
  `<div class="navsec">${sec}</div>`+rows.map(([id,label])=>
    `<button class="navrow" data-page="${id}" type="button">
       <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"
            stroke-linecap="round" stroke-linejoin="round">${I[id]}</svg>
       ${label}${COUNTS[id]?`<span class="n">${f(COUNTS[id]())}</span>`:''}</button>`).join('')).join('');
document.getElementById('sidefoot').innerHTML =
  `${f(D.totals.tracks)} tracks<br>Updated ${D.generated}`;

const t=D.totals;
const zoneRows = ()=>D.zones;
const seg=(id,opts,cur)=>`<div class="seg" id="${id}">${opts.map(([v,l])=>
  `<button type="button" data-g="${v}" aria-pressed="${v===cur}">${l}</button>`).join('')}</div>`;
function wireSeg(id,cb){
  const b=document.getElementById(id); if(!b) return;
  b.querySelectorAll('button').forEach(x=>x.addEventListener('click',()=>{
    b.querySelectorAll('button').forEach(y=>y.setAttribute('aria-pressed',y===x));
    cb(x.dataset.g);
  }));
}
const RANGES=[['day','Day'],['week','Week'],['month','Month'],['year','Year'],['all','All']];
const VIEWS=[['change','Change'],['share','Share'],['trend','Trend']];

// ---- pages -------------------------------------------------------------
let curPage='overview', curView='trend', curRange='week';
const PAGEDEF={
 overview:{title:'Overview', sub:()=>`${f(t.tracks)} tracks · ${f(t.plays)} plays · ${t.playlists} playlists`},
 listening:{title:'Listening', sub:()=>'Every track sits in exactly one zone', scope:'listening'},
 artists:  {title:'Artists',   sub:()=>`${(D.artistsNow||[]).length} artist playlists`, scope:'artists'},
 genres:   {title:'Genres',    sub:()=>'By track genre across the library', scope:'genres'},
 decades:  {title:'Decades',   sub:()=>'By release year across the library', scope:'decades'},
 playlists:{title:'Playlists', sub:()=>`${t.playlists} playlists in ${t.folders} folders`},
 history:  {title:'History',   sub:()=>`${H.length} readings since tracking began`},
};

function renderOverview(b){
  const stat=(k,v,n)=>`<div class="stat"><div class="k">${k}</div><div class="v">${v}</div><div class="n">${n}</div></div>`;
  const zR=(D.zones.find(z=>z[0]==='Repertoire')||[0,0])[1];
  b.innerHTML =
   `<div class="stats">
      ${stat('Tracks',f(t.tracks),`${f(t.everPlayed)} ever played`)}
      ${stat('Plays',f(t.plays),`${t.perTrack} per track`)}
      ${stat('Repertoire',f(zR),`${(zR/t.tracks*100).toFixed(1)}% of library`)}
      ${stat('Played this week',f(t.played7),`${f(t.played30)} in 30 days`)}
    </div>
    <div class="grid" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);flex:1;min-height:0">
      <div class="card"><h2>Listening</h2><div class="cap">How the library is distributed right now</div>
        <div class="body"><div id="ovStack" style="flex:none"></div>
          <div id="ovZones" style="flex:1;min-height:0;margin-top:1rem;display:flex"></div></div></div>
      <div class="card"><h2>Top artists</h2><div class="cap">By total plays</div>
        <div class="body" id="ovArtists"></div></div>
    </div>
    <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.35fr);flex:1.05;min-height:0">
      <div class="card"><h2>Movement</h2><div class="cap" id="ovMoveCap"></div>
        <div class="body" id="ovMove"></div></div>
      <div class="card"><h2>Trend</h2><div class="cap">One reading per day</div>
        <div class="body" id="ovTrend"></div></div>
    </div>`;
  document.getElementById('ovStack').innerHTML = stacked(zoneRows());
  document.getElementById('ovZones').innerHTML =
    rankedList(zoneRows(), true, t.tracks);
  document.getElementById('ovArtists').innerHTML =
    rankedList((D.artistsByPlays||[]).slice(0,8).map(a=>[a[0],a[1]]), false, t.plays);
  const Hd=daily(H).filter(SCOPES.listening.has), Hr=inRange(Hd,'week');
  const cap=document.getElementById('ovMoveCap');
  if(Hr.length>1){
    const a=Hr[0], z=Hr[Hr.length-1], d=v=>`${v.slice(6,8)}/${v.slice(4,6)}`;
    cap.textContent=`${d(a.t)} → ${d(z.t)}`;
    drawChange(document.getElementById('ovMove'),
      ZONE_ORDER.map(k=>[k, zoneVal(z,k)-zoneVal(a,k)]).sort((x,y)=>Math.abs(y[1])-Math.abs(x[1])));
  } else { cap.textContent='Needs a second day'; 
    document.getElementById('ovMove').innerHTML='<div class="empty">Movement appears once Needle has run on two separate days.</div>'; }
  drawTrend(document.getElementById('ovTrend'),'listening','week');
}

function drawTrend(host, scope, range){
  const S=SCOPES[scope], Hd=daily(H).filter(S.has);
  if(!Hd.length){ host.innerHTML='<div class="empty">No daily snapshots for this view yet.</div>'; return; }
  const Hr=inRange(Hd,range), keys=S.extra?[...S.keys(),S.extra]:S.keys();
  const series=seriesFrom(Hr,keys,S.val).filter(s=>s.vals.some(v=>v>0));
  multiLine(host,labelFor(Hr),series,{label:scope+' trend',kinds:Hr.map(r=>r.src||'manual')});
}

function renderScope(b, scope){
  b.innerHTML =
   `<div class="card" style="flex:1.35;min-height:0"><div class="body" id="scChart"></div></div>
    <div class="card" style="flex:1;min-height:0">
      <div class="rowhead"><h2>Standing</h2><span class="hint">share of ${f(t.tracks)} tracks</span></div>
      <div class="body" id="scList"></div></div>`;
  // share is always of the whole library - a top-12 subtotal would overstate
  // every row, and for artists the lists overlap so their sum means nothing
  document.getElementById('scList').innerHTML =
    rankedList(SCOPES[scope].now().slice(0,12).map(r=>[r[0],r[1]]), true, t.tracks);
  drawScopeChart(scope);
}
function drawScopeChart(scope){
  const host=document.getElementById('scChart'); if(!host) return;
  const S=SCOPES[scope], note=document.getElementById('scNote');
  const rb=document.getElementById('scRange');
  if(rb) rb.style.visibility = curView==='share' ? 'hidden' : 'visible';
  if(curView==='share'){ if(note) note.textContent=''; drawShare(host,S.now().map(r=>[r[0],r[1]])); return; }
  const Hd=daily(H).filter(S.has);
  if(!Hd.length){ host.innerHTML='<div class="empty">No daily snapshots for this view yet.</div>'; return; }
  const Hr=inRange(Hd,curRange);
  if(curView==='change'){
    const a=Hr[0], z=Hr[Hr.length-1], d=v=>`${v.slice(6,8)}/${v.slice(4,6)}`;
    if(note) note.textContent = Hr.length<2?'needs a second day':`${d(a.t)} → ${d(z.t)}`;
    drawChange(host, S.keys().map(k=>[k, S.val(z,k)-S.val(a,k)]).sort((x,y)=>Math.abs(y[1])-Math.abs(x[1])));
    return;
  }
  if(note){ const days=new Set(Hr.map(r=>r.t.slice(0,8))).size;
    note.textContent=`${days} daily reading${days===1?'':'s'}`; }
  drawTrend(host, scope, curRange);
}

function renderPlaylists(b){
  const order=D.folderOrder||Object.keys(D.folders);
  b.innerHTML=`<div class="plgrid">${order.map(fn=>
    `<div class="plgroup"><div class="fh"><b>${fn}</b><em>${D.folders[fn].length} playlists · ${
       f(D.folders[fn].reduce((a,c)=>a+c[1],0))} tracks</em></div>
     <ul>${(()=>{const mx=Math.max(1,...D.folders[fn].map(x=>x[1]));
       return D.folders[fn].map(([n,c,sm])=>
        `<li><span>${n}${sm?'':'<span class="tag">Manual</span>'}</span>`+
        `<span class="m"><i style="width:${c/mx*100}%"></i></span><b>${f(c)}</b></li>`).join('');
     })()}</ul></div>`).join('')}</div>`;
}

function renderHistory(b){
  const d=(a,z)=>{const n=z-a; return (n>0?'+':'')+n.toLocaleString();};
  let cards='<div class="empty">Needs two snapshots.</div>';
  if(H.length>1){
    const a=H[0], z=H[H.length-1], days=new Set(H.map(r=>r.t.slice(0,8))).size;
    const cell=(v,l,c)=>`<div class="delta"><b class="${c||''}">${v}</b><span>${l}</span></div>`;
    cards=`<div class="deltas">
      ${cell(f(H.length),'Readings')}${cell(days,'Days covered')}
      ${cell(d(a.plays,z.plays),'Plays',z.plays>a.plays?'up':'')}
      ${cell(d(a.everPlayed,z.everPlayed),'Newly played',z.everPlayed>a.everPlayed?'up':'')}
      ${cell(d(zoneVal(a,'Repertoire'),zoneVal(z,'Repertoire')),'Repertoire')}
      ${cell(d(a.tracks,z.tracks),'Library')}</div>`;
  }
  b.innerHTML=cards+`<div class="card" style="flex:1;min-height:0">
     <div class="rowhead"><h2>Every zone, all time</h2><span class="hint">one reading per day</span></div>
     <div class="body" id="hTrend"></div></div>`;
  drawTrend(document.getElementById('hTrend'),'listening','all');
}

// ---- router ------------------------------------------------------------
function go(page){
  curPage=page;
  const def=PAGEDEF[page], b=document.getElementById('pageBody');
  document.querySelectorAll('.navrow').forEach(n=>
    n.setAttribute('aria-current', n.dataset.page===page?'page':'false'));
  document.getElementById('pageTitle').textContent=def.title;
  document.getElementById('pageSub').textContent=def.sub();
  const tb=document.getElementById('toolbar');
  tb.innerHTML = def.scope
    ? `<span class="hint" id="scNote"></span>${seg('scView',VIEWS,curView)}
       <span id="scRange">${seg('scRangeSeg',RANGES,curRange)}</span>` : '';
  if(def.scope){
    renderScope(b,def.scope); fitType();
    drawScopeChart(def.scope);
    wireSeg('scView', v=>{curView=v; drawScopeChart(def.scope);});
    wireSeg('scRangeSeg', r=>{curRange=r; drawScopeChart(def.scope);});
  } else if(page==='overview'){ renderOverview(b); fitType(); renderOverview(b);
  } else if(page==='playlists'){ renderPlaylists(b); fitType();
  } else { renderHistory(b); fitType(); renderHistory(b); }
}
document.getElementById('nav').addEventListener('click',e=>{
  const b=e.target.closest('.navrow'); if(b) go(b.dataset.page);
});

/* ---- solve for the largest type that fits, then step back 30% ---------
   Panels clip rather than scroll, so overflow is measurable. The content
   column is the only scroller, and only as a last resort.
   -------------------------------------------------------------------- */
/* Type is derived from the window, not from whichever page happens to be
   open. Solving per page made the whole interface change size as you
   navigated - Overview at 13px, History at 18px - which reads as a glitch.
   One size, stable everywhere; pages that need more room scroll instead. */
function fitType(){
  const w=window.innerWidth/113, h=window.innerHeight/72;
  const px=Math.max(10.5, Math.min(w, h, 20));
  document.documentElement.style.fontSize=px.toFixed(2)+'px';
}
go('overview');
let rz; addEventListener('resize',()=>{clearTimeout(rz); rz=setTimeout(()=>go(curPage),140);});
</script>
"""

def payload(data):
    """Swift-facing view of the same numbers.

    The HTML template consumes tuples because JS does not care; Codable very
    much does. Rather than duplicate the aggregation in two languages, both
    renderers read what build() produced - this only reshapes it into named
    fields so it decodes cleanly.
    """
    pair = lambda xs: [{"name": str(a), "count": int(b)} for a, b in xs]
    return {
        "stamp": data["stamp"], "generated": data["generated"],
        "totals": data["totals"],
        "zones": pair(data["zones"]),
        "genres": pair(data["genresAllNow"]),
        "decades": pair(data["decadesNow"]),
        "artists": pair(data["artistsAllNow"]),
        "artistPlaylists": pair(data["artistsNow"]),
        "artistsByPlays": [{"name": a, "plays": p, "tracks": c}
                           for a, p, c in data["artistsByPlays"]],
        "folders": [{"name": f,
                     "playlists": [{"name": n, "count": c, "smart": bool(sm)}
                                   for n, c, sm in data["folders"][f]]}
                    for f in data["folderOrder"]],
        # The per-artist dictionaries are how the weekly recap is computed here;
        # the app never reads them, and shipping them made the payload 7x bigger.
        "history": [{k: v for k, v in r.items()
                     if k not in ("artistPlays", "artistMinutes")}
                    for r in data["history"]],
        "zoneOrder": data["zoneOrder"], "zoneAliases": data["zoneAliases"],
        "topGenres": data["topGenres"], "topDecades": data["topDecades"],
        "topArtists": data["topArtists"],
        "compositions": data["compositions"],
    }

def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    stamp = args[0] if args else newest()
    data = build(stamp)
    pj = os.path.join(APP_SUPPORT, "payload.json")
    tmp = pj + ".partial"
    with open(tmp, "w") as fh: json.dump(payload(data), fh)
    os.replace(tmp, pj)
    out = os.path.join(APP_SUPPORT, "dashboard.html")
    open(out, "w").write(TEMPLATE.replace("__DATA__", json.dumps(data)))
    print(f"dashboard built from snapshot {stamp}")
    print(f"   {data['totals']['tracks']} tracks | {data['totals']['playlists']} playlists")
    print(f"   -> {out}")
    print(f"   -> {pj}")
    if "--open" in sys.argv: subprocess.run(["open", out])

if __name__ == "__main__":
    main()
